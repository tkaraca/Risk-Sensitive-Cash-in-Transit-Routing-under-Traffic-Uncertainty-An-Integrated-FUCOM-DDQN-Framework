# REV16 Minimal Train/Test Package

This package contains only the files required to train and test the REV16
cash-in-transit routing model from scratch.

## Required downloads

Download both archives and extract them into the same directory:

1. `01_REV16_CODE.zip`
2. `02_REV16_DATA.zip`

After extraction, the project directory must contain:

```text
github_minimal_rev16/
  vrp_cit_besiktas_HIERARCHICAL_CIT_REV16_QPRIMARY_EMERGENCY_FINETUNE.py
  requirements.txt
  cache_np/
    distance.npy
    risk.npy
    velocity_std.npy
    Saat8ort.npy
    Saat10ort.npy
    Saat12ort.npy
    Saat14ort.npy
    Saat16ort.npy
    Saat18ort.npy
```

## Setup

Python 3.10 or 3.11 is recommended.

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Train and test

Run from inside the `github_minimal_rev16` directory:

```powershell
python vrp_cit_besiktas_HIERARCHICAL_CIT_REV16_QPRIMARY_EMERGENCY_FINETUNE.py
```

No pretrained `.h5` model is included. Training starts without pretrained
weights and the script performs its own configured training/test workflow.

The original Excel workbooks are not required because the sanitized NumPy
matrices are supplied in `cache_np/`.
