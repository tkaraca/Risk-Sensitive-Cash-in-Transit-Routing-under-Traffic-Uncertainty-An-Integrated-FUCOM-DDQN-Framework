import time
from collections import deque, namedtuple
import heapq
import random
import os
import sys
import csv
import json
import atexit
import pickle
import tempfile
from pathlib import Path
import hashlib
import datetime
from typing import Optional

import argparse

import numpy as np
import tensorflow as tf
import pandas as pd

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# TF GPU bellek yönetimi: mevcutsa "memory growth" aç.
# (GPU varsa TensorFlow'un tüm belleği baştan kapmasını engeller.)
try:
    for _gpu in tf.config.list_physical_devices("GPU"):
        try:
            tf.config.experimental.set_memory_growth(_gpu, True)
        except Exception:
            pass
except Exception:
    pass

# myutils: eğitim yardımcıları (batch sampling vs.)
# Eğer kullanıcı ortamında myutils.py varsa onu kullanır.
# Yoksa bu script kendi minimal fallback'ini devreye alır.
try:
    import myutils as utils  # type: ignore
except Exception:
    class _FallbackUtils:
        """Minimal myutils alternatifi (script tek başına çalışsın diye)."""

        def __init__(self, batch_size: int = 128):
            self.BATCH_SIZE = int(batch_size)

        def check_update_conditions(self, t: int, num_steps_for_update: int, memory_buffer) -> bool:
            if len(memory_buffer) < self.BATCH_SIZE:
                return False
            if num_steps_for_update <= 0:
                return True
            return (t % int(num_steps_for_update)) == 0

        def get_experiences(self, memory_buffer):
            experiences = random.sample(memory_buffer, k=self.BATCH_SIZE)
            states = np.vstack([e.state for e in experiences]).astype(np.float32)
            actions = np.array([e.action for e in experiences], dtype=np.int32)
            rewards = np.array([e.reward for e in experiences], dtype=np.float32)
            next_states = np.vstack([e.next_state for e in experiences]).astype(np.float32)
            done_vals = np.array([e.done for e in experiences], dtype=np.float32)
            return (states, actions, rewards, next_states, done_vals)

    utils = _FallbackUtils(batch_size=128)

# Replay batch size: external myutils varsa oradaki değeri, yoksa fallback'i kullan.
BATCH_SIZE = int(getattr(utils, "BATCH_SIZE", 128))

from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, Input
from tensorflow.keras.losses import MSE
from tensorflow.keras.optimizers import Adam

"""vrp_cit_besiktas.py

Amaç fonksiyonu.
    reward = w1 * reward_fuel + w2 * reward_duration + reward_location + w3 * reward_unsecure + w4 * reward_distance

Bu dosya v11 tabanlıdır ve aşağıdaki ek iyileştirmelerle güncellenmiştir.
1. Secure wait mantığı hedef odaklıdır. Demand erken ise tek sefer secure zone'a gidilir. Secure'da pencere açılana kadar beklenir.
2. Target lock. Araç bir demand hedefi seçtiğinde teslim edene kadar hedefi korur. Böylece hedef zıplama ve loop azalır.
3. Action masking. Top3 hedefin tamamı erken ise aksiyon 0,1,2 geçici olarak devre dışı kalır. Sadece secure wait uygulanır.
4. Loop, backtrack ve revisit penaltıları güçlendirildi. Loop tespitinde ek ceza uygulanır.
5. Early redirect sayacı episode başında sıfırlanır. Loglar gerçek episode içi değerleri gösterir.
6. İsteğe bağlı deterministik mini test suite eklendi. Seed sabitlenir. Ortalama KPI raporu alınır.

Not.
Bu dosya, cit_train_with_resume_ADJUSTED_YENİDENDÜZENLENMİŞ.py içindeki shortest path ve ceza yaklaşımını,
CIT güvenlik kuralı ile birleştirir.
"""

# ============================================================
# Versioning
# ============================================================
VERSION = os.environ.get("CIT_VERSION_OVERRIDE", "v14_21_hierarchical_cit_rev16_qprimary_emergency_finetune")
# Unreachable demand handling and terminal condition.
DROP_UNREACHABLE_DEMANDS = True  # unreachable demand node'lari listeden cikar.
DONE_WHEN_ALL_REQUIRED_DELIVERED = True  # reachable talepler bittiginde episode biter.
DONE_REQUIRES_RETURN_TO_DEPOT = False    # sadece DONE_WHEN_ALL_REQUIRED_DELIVERED=False ise anlamli.
DONE_REQUIRES_SECURE_END = False         # sadece DONE_WHEN_ALL_REQUIRED_DELIVERED=False ise anlamli.

# ============================================================
# Global config
# ============================================================
CANDIDATE_TOPK = 5
MAX_ACTIONS = CANDIDATE_TOPK + 1  # 0..K-1 candidate slotları, K = secure wait.
A_SECURE_WAIT = CANDIDATE_TOPK

# Candidate-centric state / action scoring
CANDIDATE_FEATURES_PER_SLOT = 24
FLEET_FEATURE_DIM = 16

# Hierarchical CIT observation/reward layer.
# The base Rev5.5 reward is kept intact; this layer adds guideline-driven,
# Markov-checkable subgoal shaping on top of it.
HIER_CIT_ACTIVE = True
HIER_OBS_DIM = 18
HIER_SOLVED_REWARD = 675.0
HIER_ALL_RETURNED_REWARD = 250.0
HIER_RETURN_AFTER_SOLVE_REWARD = 95.0
HIER_DELIVERY_SUBGOAL_REWARD = 72.0
HIER_ONTIME_DELIVERY_REWARD = 52.0
HIER_REMAINING_REDUCTION_REWARD = 35.0
HIER_TARGET_PROGRESS_GAIN = 18.0
HIER_SECURE_HOLD_REWARD = 4.0
HIER_SECURE_APPROACH_REWARD = 3.0
HIER_RESOURCE_STEP_PENALTY = -0.08
HIER_RESOURCE_MINUTE_PENALTY = -0.018
HIER_RESOURCE_KM_PENALTY = -0.020
HIER_NO_SUPPORT_ACTION_PENALTY = -1.20
HIER_LATE_ACTION_PENALTY = -6.5
HIER_SERVICE_OVER_MINUTE_PENALTY = -0.11
HIER_RETURN_OVER_MINUTE_PENALTY = -0.17
HIER_TRACE_HIGH_REWARDS = True
HIER_TRACE_THRESHOLD = 120.0

# REV11: hierarchy carries operational progress only. Every soft preference
# remains in the single weighted reward/candidate-cost function.
HIER_OPERATIONAL_ONLY = bool(int(os.environ.get("CIT_HIER_OPERATIONAL_ONLY", "1")))
if HIER_OPERATIONAL_ONLY:
    HIER_ONTIME_DELIVERY_REWARD = 0.0
    HIER_SECURE_HOLD_REWARD = 0.0
    HIER_SECURE_APPROACH_REWARD = 0.0
    HIER_RESOURCE_STEP_PENALTY = 0.0
    HIER_RESOURCE_MINUTE_PENALTY = 0.0
    HIER_RESOURCE_KM_PENALTY = 0.0
    HIER_LATE_ACTION_PENALTY = 0.0
    HIER_SERVICE_OVER_MINUTE_PENALTY = 0.0
    HIER_RETURN_OVER_MINUTE_PENALTY = 0.0

# Optional gated curriculum used by REV7.  A phase is advanced only after the
# deterministic suite repeatedly clears its feasibility gate; episode count
# alone can never unlock distance/risk optimisation.
GATED_CURRICULUM_ACTIVE = bool(int(os.environ.get("CIT_GATED_CURRICULUM", "0")))
# REV9 is warm-started from an independently verified operational checkpoint.
# One successful held-out suite is therefore sufficient to enter the
# delivery-time-window phase.  The TW -> optimisation gate still additionally
# requires the configured mean-miss threshold.
CURRICULUM_GATE_STREAK = int(os.environ.get("CIT_CURRICULUM_GATE_STREAK", "1"))
CURRICULUM_FEASIBLE_RATIO = float(os.environ.get("CIT_CURRICULUM_FEASIBLE_RATIO", "0.90"))
CURRICULUM_TW_MEAN_MAX = float(os.environ.get("CIT_CURRICULUM_TW_MEAN_MAX", "2.0"))


def curriculum_reward_scales(phase: str) -> dict:
    """Return hierarchy scales; upper goals dominate until their gate is met."""
    if not GATED_CURRICULUM_ACTIVE:
        return {k: 1.0 for k in ("resource", "delivery", "ontime", "solve", "return", "late")}
    if phase == "feasibility":
        return {
            "resource": 0.20, "delivery": 2.00, "ontime": 0.35,
            "solve": 2.50, "return": 2.25, "late": 0.50,
        }
    if phase == "time_window":
        return {
            "resource": 0.45, "delivery": 1.35, "ontime": 2.25,
            "solve": 1.75, "return": 1.60, "late": 2.25,
        }
    return {
        "resource": 1.25, "delivery": 1.00, "ontime": 1.25,
        "solve": 1.25, "return": 1.25, "late": 1.35,
    }

# Rev5 multi-objective scalarization
OBJECTIVE_WEIGHT_ORDER = (
    "undelivered",
    "early",
    "late",
    "service_over",
    "return_over",
    "secure",
    "distance",
    "duration",
    "risk",
    "loop",
    "reservation",
    "makespan",
)
OBJECTIVE_WEIGHT_DIM = len(OBJECTIVE_WEIGHT_ORDER)
SCALAR_COST_CLIP = 35.0
PARALLEL_DISPATCH_TIME_BUCKET_MIN = 20.0
SYNC_LEGACY_REWARD_WEIGHTS_FROM_OBJECTIVES = True

# Scalarization normalization / clipping.
# Rev5.1: objective terimleri aynı mertebede kalsın; ham dakika/kilometre/risk terimleri
# scorer'ı boğmasın. Cost terimleri zaten çoğunlukla normalize üretilir, burada son clip uygulanır.
OBJECTIVE_TERM_CAPS = {
    "undelivered": 1.50,
    "early": 1.50,
    "late": 1.75,
    "service_over": 1.75,
    "return_over": 2.00,
    "secure": 1.25,
    "distance": 1.60,
    "duration": 1.60,
    "risk": 1.25,
    "loop": 1.25,
    "reservation": 1.25,
    "makespan": 1.60,
}

# Progress-first scalarization.
CANDIDATE_PROGRESS_CREDIT_OK = 0.55
CANDIDATE_PROGRESS_CREDIT_RESCUE = 0.22
CANDIDATE_UNDELIVERED_EARLY = 0.55
CANDIDATE_UNDELIVERED_LATE = 0.20
CANDIDATE_UNDELIVERED_SERVICE_OVER = 0.18
CANDIDATE_UNDELIVERED_RETURN_OVER = 0.25
WAIT_UNDELIVERED_SCALE = 1.20
WAIT_OK_EXISTS_EXTRA = 0.90
WAIT_RESCUE_EXISTS_EXTRA = 0.35
DISPATCH_PRIORITY_PROGRESS_BONUS = 0.22
FINISH_PRESSURE_START_RATIO = 0.60
FINISH_PRESSURE_GAIN = 0.90

# Q + heuristic birleşimi.
# Rev5.1: heuristic bias erken aşamada daha zayıf; epsilon düştükçe güçlenir.
ACTION_SCORE_BIAS_SCALE_START = 0.95
ACTION_SCORE_BIAS_SCALE_END = 2.20
ACTION_SCORE_Q_SCALE_START = 0.85
ACTION_SCORE_Q_SCALE_END = 0.55
ACTION_SCORE_CONFIDENCE_MARGIN = 0.20
ACTION_SCORE_DELIVER_NOW_BONUS = 0.43
ACTION_SCORE_DELIVER_RESCUE_BONUS = 0.16
ACTION_SCORE_WAIT_WHEN_DELIVERABLE_PENALTY = 0.65
ACTION_SCORE_WAIT_WHEN_RESCUEABLE_PENALTY = 0.28
HEURISTIC_FALLBACK_ACTIVE = True
ACTION_SCORE_HEURISTIC_ONLY_EPISODES = 160
ACTION_SCORE_RESIDUAL_RAMP_EPISODES = 600
ACTION_SCORE_BIAS_SCALE_WARMUP = 3.20
ACTION_SCORE_Q_SCALE_WARMUP = 0.05
ACTION_SCORE_HEURISTIC_OVERRIDE_MARGIN = 0.30
WAIT_NOT_SECURE_PROGRESS_PENALTY = 0.55
WAIT_NOT_SECURE_WHEN_OK_EXTRA = 0.30
LOOP_COST_RECENT_BONUS = 0.28
LOOP_COST_STREAK_GAIN = 0.11
LOOP_COST_GLOBAL_LOOP_BONUS = 0.22

# Rev5.3 stabilization / best-model selection.
FINISH_BIAS_REMAINING_UNITS = 2
FINISH_DELIVER_NOW_EXTRA = 0.31
FINISH_DELIVER_RESCUE_EXTRA = 0.14
FINISH_WAIT_EXTRA = 0.48
FINISH_UNDELIVERED_EXTRA = 0.33
FINISH_RESERVATION_EXTRA = 0.18

ROGUE_RECOVERY_ACTIVE = True
ROGUE_NO_PROGRESS_THRESHOLD = int(os.environ.get("CIT_ROGUE_NO_PROGRESS_THRESHOLD", "24"))
ROGUE_SECURE_TRAVEL_THRESHOLD = int(os.environ.get("CIT_ROGUE_SECURE_TRAVEL_THRESHOLD", "220"))
ROGUE_LOOP_FLAG_THRESHOLD = int(os.environ.get("CIT_ROGUE_LOOP_FLAG_THRESHOLD", "24"))
ROGUE_WAIT_OVERRIDE_MARGIN = 0.12

BEST_CHECKPOINTS_ACTIVE = bool(int(os.environ.get("CIT_BEST_CHECKPOINTS_ACTIVE", "1")))
LR_DECAY_ACTIVE = bool(int(os.environ.get("CIT_LR_DECAY_ACTIVE", "1")))
LR_DECAY_FACTOR = 0.50
LR_DECAY_PATIENCE_EVALS = 8
LR_MIN = 1e-6
EARLY_STOP_ACTIVE = bool(int(os.environ.get("CIT_EARLY_STOP_ACTIVE", "1")))
EARLY_STOP_PATIENCE_EVALS = 25
EARLY_STOP_MIN_EPISODE = 1200

# Rev5.5 stabilization: terminal repair + deterministic deploy scorer.
TERMINAL_REPAIR_ACTIVE = True
TERMINAL_REPAIR_REMAINING_UNITS = 3
TERMINAL_REPAIR_VEHICLE_TIME_BUCKET_MIN = 150.0
TERMINAL_REPAIR_DELIVER_NOW_BONUS = 0.42
TERMINAL_REPAIR_DELIVER_RESCUE_BONUS = 0.20
TERMINAL_REPAIR_WAIT_PENALTY = 0.60
TERMINAL_REPAIR_SCALAR_MARGIN = 0.20

DEPLOY_HEURISTIC_DOMINANT = True
DEPLOY_Q_SCALE = 0.15
DEPLOY_HEURISTIC_OVERRIDE_MARGIN = 0.10
DEPLOY_WAIT_DELIVERABLE_MARGIN = 0.12

# Evaluation-only ablation. Training always keeps the original REV15 policy.
EVAL_POLICY_MODE = os.environ.get("CIT_EVAL_POLICY_MODE", "rev15_hybrid").strip().lower()
EVAL_POLICY_MODES = {"heuristic_only", "rev15_hybrid", "q_primary_emergency", "q_only_masked"}
if EVAL_POLICY_MODE not in EVAL_POLICY_MODES:
    raise ValueError(f"Unknown CIT_EVAL_POLICY_MODE={EVAL_POLICY_MODE!r}; expected one of {sorted(EVAL_POLICY_MODES)}")
TRAIN_POLICY_MODE = os.environ.get("CIT_TRAIN_POLICY_MODE", "q_primary_emergency").strip().lower()
if TRAIN_POLICY_MODE not in {"rev15_hybrid", "q_primary_emergency"}:
    raise ValueError(f"Unknown CIT_TRAIN_POLICY_MODE={TRAIN_POLICY_MODE!r}")
DECISION_SOURCE_COUNTS = {
    "total": 0,
    "q_network": 0,
    "heuristic": 0,
    "hybrid": 0,
    "emergency": 0,
    "finish_protocol": 0,
    "recovery_emergency": 0,
    "shield_emergency": 0,
    "exploration": 0,
}


def _record_decision_source(source: str) -> None:
    DECISION_SOURCE_COUNTS["total"] = int(DECISION_SOURCE_COUNTS.get("total", 0)) + 1
    DECISION_SOURCE_COUNTS[source] = int(DECISION_SOURCE_COUNTS.get(source, 0)) + 1
    if source in {"finish_protocol", "recovery_emergency", "shield_emergency"}:
        DECISION_SOURCE_COUNTS["emergency"] = int(DECISION_SOURCE_COUNTS.get("emergency", 0)) + 1

# REV5 completion-first guardrails. Reward tuning alone did not prevent
# no_active and avoidable wait/loop failures, so these are policy constraints.
REV5_COMPLETION_GUARDS = True
REV5_MASK_WAIT_WHEN_OK_EXISTS = True
REV5_NO_ACTIVE_RECOVERY = True
REV5_MAX_REACTIVATIONS_PER_VEHICLE = 2

PHASE_UNDELIVERED_GAIN = 1.10
PHASE_UNDELIVERED_TIME_GAIN = 0.55
PHASE_UNDELIVERED_REMAINING_BOOST = 0.45

ROGUE_HARD_LOOP_THRESHOLD = 36
ROGUE_HARD_SECURE_THRESHOLD = 240
ROGUE_HARD_NO_PROGRESS = 22
ROGUE_FORCE_PROGRESS_STEPS = 3
ROGUE_FORCE_PROGRESS_WAIT_MARGIN = 0.05
ROGUE_CLEAR_LOCK_ON_RECOVERY = True

# Reservation / commit.
RESERVATION_COST_PENALTY = 1.10
LOCK_BREAK_IF_RESERVED = True
LOCK_BREAK_OK_MARGIN = 0.25
LOCK_BREAK_EARLY_OPEN_MIN = 45.0
LOCK_BREAK_SERVICE_OVER_MIN = 45.0

# Early davranışı. Rev2'de çok sert mask oluşup mAll/nF patlıyordu.
# Rev3'te erken adaylar varsayılan olarak "soft" cezalanır; sadece gerçekten çok erken
# ve wait açıkça daha iyi ise maskelenir.
EARLY_MASK_IN_NORMAL_MODE = True
EARLY_MASK_OPEN_MIN_STRICT = 75.0
EARLY_MASK_ONLY_IF_WAIT_BETTER = True
LATE_MASK_WHEN_OK_EXISTS = True

# Wait bias. Secure travel sömürüsünü azaltmak için wait bias daha kontrollü.
WAIT_BIAS_OK_EXISTS = -0.75
WAIT_BIAS_EARLY_BASE = 0.90
WAIT_BIAS_NOT_SECURE_DIST_PENALTY = 0.60

# Parallel multi-vehicle dispatch
PARALLEL_DISPATCH_ACTIVE = True

# Navigation graph config.
# Problem büyükse dense olabilir. Auto seçimi ile sparse graphlarda tüm edge'leri korur.
NAV_K_START = 12
NAV_K_STEP = 6
NAV_K_MAX = 60
SPARSE_DEG_THRESHOLD = 60  # Ortalama degree bu eşikten küçükse graph zaten sparse. Edge kırpma yapma.

# Secure wait config.
SECURE_WAIT_MIN = 5.0  # dakika. Secure zone'da action wait ile minimum bekleme.
WAIT_CHUNK_MAX = 60.0  # dakika. Tek wait adımında maksimum bekleme.

# Servis ve gün sonu. 0=08:00 varsayımı ile dakika cinsinden.
SERVICE_START_HOUR = 8.0
SERVICE_END_HOUR = 20.0
SERVICE_END_MIN = (SERVICE_END_HOUR - SERVICE_START_HOUR) * 60.0  # 720.0
RETURN_GRACE_MIN = 120.0  # 20:00 sonrası depot grace.
MAX_ROUTE_DURATION_MIN = SERVICE_END_MIN + RETURN_GRACE_MIN  # soft depot grace sonu.
RESCUE_EXTRA_EXTENSION_MIN = 180.0  # mutlak sert horizon öncesi ek rescue uzatma.
ABSOLUTE_MAX_ROUTE_DURATION_MIN = MAX_ROUTE_DURATION_MIN + RESCUE_EXTRA_EXTENSION_MIN
END_OF_DAY_PENALTY = -100.0

# Service end penalties. Servis kapanınca (20:00) kalan talepler için tek seferlik ceza.
SERVICE_END_BASE_PENALTY = -20.0
REMAINING_UNIT_PENALTY_SERVICE_END = -100.0  # rem_units/vehicle ile ölçeklenir.

# Overtime costs.
OVERTIME_PENALTY_PER_MIN = -0.80          # service end sonrası teslim/operasyon uzatma
RETURN_EXTENSION_PENALTY_PER_MIN = -1.25  # depot grace sonrası daha sert ceza

# Rescue mode / soft feasibility
RESCUE_MODE_ACTIVE = True
RESCUE_LOOKAHEAD_MIN = 150.0
ALLOW_LATE_DELIVERY_AFTER_SERVICE_END = True
ALLOW_EARLY_DELIVERY_IN_RESCUE = False  # early genelde bekleme ile çözülebilir; near-hard bırak.
EARLY_FORCE_WAIT = True

# Time window ölçüsü.
# Gap hesapları dakika bazlıdır. Reward shaping için "pencere birimi"ne normalize edilir.
WINDOW_SIZE_MIN = 120.0

# Logging.
# LOG_LEVEL. 0 hiç log yok. 1 episode özeti. 2 adım bazlı heartbeat.
LOG_LEVEL = 1
EP_LOG_EVERY = 10
STEP_LOG_EVERY = 1000
LOG_FIRST_N_EPISODES = 3
LOG_REMAINING_DEMANDS = True
LOG_REMAINING_DEMAND_TOPK = 12
BOOT_LOG = True

if BOOT_LOG:
    print(f"[BOOT] version={VERSION} start file={__file__} cwd={os.getcwd()} time={datetime.datetime.now().isoformat(timespec='seconds')}", flush=True)
    try:
        with open(__file__, 'rb') as _fp:
            _code_hash = hashlib.sha1(_fp.read()).hexdigest()[:12]
    except Exception:
        _code_hash = 'NA'
    print(f"[BOOT] code_hash={_code_hash} python={os.sys.version.split()[0]}", flush=True)
    print("[BOOT] loading excel matrices...", flush=True)

# Target lock
TARGET_LOCK_ACTIVE = True
TARGET_LOCK_MAX_STEPS = 1000  # ignored while hard target mode is active
TARGET_HARD_CONSTRAINT = bool(int(os.environ.get("CIT_TARGET_HARD_CONSTRAINT", "1")))
HOLD_ROUTE_HYSTERESIS_ACTIVE = bool(int(os.environ.get("CIT_HOLD_ROUTE_HYSTERESIS", "1")))
STRICT_DESCENT_NAV_ACTIVE = bool(int(os.environ.get("CIT_STRICT_DESCENT_NAV", "1")))
TARGET_SWITCH_PENALTY = -0.20

# Action masking
ACTION_MASKING = True

# Early hold ve redirect
EARLY_REDIRECT_PENALTY = -1.50
ARRIVAL_MARGIN_MIN = 0.0

# Loop ve "ilerleme yok" penaltıları
RECENT_WINDOW = 8
RECENT_REVISIT_PENALTY = -0.60
BACKTRACK_PENALTY = -0.80
LOOP_PENALTY = -1.00

NO_PROGRESS_PENALTY = -0.75
WAIT_WHEN_OK_TARGET_PENALTY = -4.00  # Secure'da beklerken (hold yokken) feasible delivery varken cezalandır.
WAIT_WHEN_OK_TARGET_MAXCHECK = 999    # 'ok' hedef aramada bakılacak aday sayısı.
NP_STREAK_THRESHOLD = 10

STALL_LIMIT = 400  # progress streak limiti
STALL_PENALTY = -20.0

# Shield.
SHIELD_ACTIVE = True
SHIELD_KICKIN_STEPS = 60

# Loop tespiti.
TABU_RECENT = 16
LOOP_WINDOW = 32
LOOP_UNIQUE_MAX = 7

# Shield burst ve cooldown.
SHIELD_BURST_STEPS = 3
SHIELD_COOLDOWN_STEPS = 12
SHIELD_PROB_START = 0.60
SHIELD_PROB_END = 0.10
SHIELD_PROB_DECAY = 0.99995

# Guided exploration.
GUIDED_EXPLORATION = True
GUIDED_EXPLORE_PROB = 0.70

# Ödül ölçekleri
DELIVERY_REWARD = 100.0  # backward-compat referansı
DELIVERY_BASE_REWARD = 25.0
DELIVERY_ONTIME_BONUS = 75.0
DELIVERY_LATE_BONUS_FACTOR = 0.60
DELIVERY_SERVICE_EXT_BONUS_FACTOR = 0.35
RETURN_HOME_BONUS = 50.0
TIMEWINDOW_MISS_PENALTY = 18.0
EARLY_MISS_FACTOR = 2.00
LATE_MISS_FACTOR = 1.35

# Time window kuralı.
# Rev2'de early delivery near-hard, late/service-end ise kontrollü soft violation.
TIMEWINDOW_SOFT_MODE = True

# Yönetim kararı. Time window ihlal cezası ağırlığı.
# 0.0 yaparsan time window tamamen önemsiz olur.
W_TIMEWINDOW = 1.0

# ============================================================
# (TUNABLE) Multi-objective weights (w1..w4)
# ============================================================
# Amaç: reward fonksiyonunun içini sürekli değiştirmek yerine sadece ağırlıklarla oynamak.
#
# reward = reward_location
#          + w1 * reward_fuel
#          + w2 * reward_duration
#          + w3 * reward_unsecure
#          + w4 * reward_distance
#          + W_TIMEWINDOW * reward_timewindow
#          + extra_penalty
#
# Not: reward_location (teslimat/çözüm/dönüş) ana hedef; w'lar daha çok maliyet/ceza tarafını ayarlar.

# w1: yakıt (fuel) maliyeti ağırlığı
# w2: süre (duration) maliyeti ağırlığı
# w3: güvensiz (unsecure) bölge cezası ağırlığı
# w4: mesafe (distance) cezası ağırlığı
w1 = 1.0
w2 = 1.0
w3 = 1.0
w4 = 1.0

# Rev5 objective ağırlıkları.
# Not: karar mekanizması bu ağırlıkları doğrudan candidate scorer içinde kullanır.
# İstenirse legacy reward weights de otomatik olarak bu objective ağırlıklarından türetilir.
LAMBDA_UNDELIVERED = 1.35
LAMBDA_EARLY = 1.50
LAMBDA_LATE = 1.75
LAMBDA_SERVICE_OVER = 1.00
LAMBDA_RETURN_OVER = 1.00
LAMBDA_SECURE = 0.50
LAMBDA_DISTANCE = 1.00
LAMBDA_DURATION = 0.50
LAMBDA_RISK = 0.25
LAMBDA_LOOP = 1.25
LAMBDA_RESERVATION = 0.25
LAMBDA_MAKESPAN = 0.75

def objective_weight_dict() -> dict:
    return {
        "undelivered": float(LAMBDA_UNDELIVERED),
        "early": float(LAMBDA_EARLY),
        "late": float(LAMBDA_LATE),
        "service_over": float(LAMBDA_SERVICE_OVER),
        "return_over": float(LAMBDA_RETURN_OVER),
        "secure": float(LAMBDA_SECURE),
        "distance": float(LAMBDA_DISTANCE),
        "duration": float(LAMBDA_DURATION),
        "risk": float(LAMBDA_RISK),
        "loop": float(LAMBDA_LOOP),
        "reservation": float(LAMBDA_RESERVATION),
        "makespan": float(LAMBDA_MAKESPAN),
    }

def objective_weight_vector(dtype=np.float32) -> np.ndarray:
    wd = objective_weight_dict()
    # Encode relative preference intent as a bounded state vector. Reward
    # scalarization still uses the raw weights below.
    values = np.asarray([max(0.0, float(wd[k])) for k in OBJECTIVE_WEIGHT_ORDER], dtype=np.float64)
    denom = float(np.sum(values))
    if denom > 1e-12:
        values /= denom
    return values.astype(dtype, copy=False)

# Domain references make one meaningful unit of every soft objective comparable.
# log1p keeps ordering and sensitivity while preventing long-tailed metrics from
# dominating the scalar objective. A raw value equal to its reference maps to 1.
OBJECTIVE_REFERENCE_SCALES = {
    "undelivered": 1.0 / 34.0,   # one missing delivery
    "early": 3.0 / 34.0,         # roughly three early misses per route set
    "late": 3.0 / 34.0,          # roughly three late misses per route set
    "service_over": 0.75,         # 90 minutes / 120-minute window
    "return_over": 0.50,          # 60 minutes / 120-minute window
    "secure": 0.10,
    "distance": 1.20,             # 120 km / 100 km
    "duration": 0.60,
    "risk": 0.75,                 # risk already divided by matrix P95
    "loop": 0.60,
    "reservation": 0.10,
    "makespan": 0.80,
}
OBJECTIVE_NORMALIZED_CAP = 2.5


def _signed_log1p_ratio(value: float, reference: float) -> float:
    sign = -1.0 if float(value) < 0.0 else 1.0
    ratio = abs(float(value)) / max(1e-9, float(reference))
    return float(sign * np.log1p(ratio) / np.log(2.0))


def normalize_cost_terms_dict(cost_terms: dict) -> dict:
    out = {}
    for key in OBJECTIVE_WEIGHT_ORDER:
        val = float(cost_terms.get(key, 0.0))
        ref = float(OBJECTIVE_REFERENCE_SCALES.get(key, 1.0))
        transformed = _signed_log1p_ratio(val, ref)
        out[key] = float(np.clip(transformed, -OBJECTIVE_NORMALIZED_CAP, OBJECTIVE_NORMALIZED_CAP))
    return out


def weighted_objective_contributions(cost_terms: dict, weights: Optional[dict] = None) -> dict:
    """Return auditable per-objective contributions used by scalarization."""
    if weights is None:
        weights = objective_weight_dict()
    norm_terms = normalize_cost_terms_dict(cost_terms)
    return {key: float(weights.get(key, 0.0)) * float(norm_terms[key]) for key in OBJECTIVE_WEIGHT_ORDER}


def scalarize_cost_terms(cost_terms: dict, weights: Optional[dict] = None) -> float:
    if weights is None:
        weights = objective_weight_dict()
    total = 0.0
    norm_terms = normalize_cost_terms_dict(cost_terms)
    for key in OBJECTIVE_WEIGHT_ORDER:
        total += float(weights.get(key, 0.0)) * float(norm_terms.get(key, 0.0))
    return float(total)

def sync_legacy_reward_weights_from_objectives() -> None:
    global w1, w2, w3, w4, W_TIMEWINDOW
    w1 = float(max(0.05, 0.60 * float(LAMBDA_DISTANCE) + 0.40 * float(LAMBDA_DURATION)))
    w2 = float(max(0.05, float(LAMBDA_DURATION)))
    w3 = float(max(0.05, 0.60 * float(LAMBDA_SECURE) + 0.40 * float(LAMBDA_RISK)))
    w4 = float(max(0.05, 0.85 * float(LAMBDA_DISTANCE) + 0.15 * float(LAMBDA_MAKESPAN)))
    W_TIMEWINDOW = float(max(0.05, 0.55 * float(LAMBDA_EARLY) + 0.45 * float(LAMBDA_LATE)))

def objective_weights_log_string() -> str:
    wd = objective_weight_dict()
    return " ".join(f"{k}={wd[k]:.2f}" for k in OBJECTIVE_WEIGHT_ORDER)

# Varsayılan legacy reward weights'i objective ağırlıklarıyla senkronize et.
if SYNC_LEGACY_REWARD_WEIGHTS_FROM_OBJECTIVES:
    sync_legacy_reward_weights_from_objectives()

# REV11 preference-conditioned profiles. Operational completion is invariant;
# only soft-objective preferences vary between training episodes.
PREFERENCE_CONDITIONED_ACTIVE = bool(int(os.environ.get("CIT_PREFERENCE_CONDITIONED", "1")))
PREFERENCE_PROFILE_WEIGHTS = {
    "balanced_final_sample_0025": {"undelivered": 1.35, "early": 1.310957266561935, "late": 1.5294501443222572, "service_over": 1.0, "return_over": 1.0, "secure": 0.24272651680116644, "distance": 2.2901364475008097, "duration": 0.24945321741816937, "risk": 0.7236073739149758, "loop": 1.25, "reservation": 0.25, "makespan": 0.37417982612725403},
    "tw_final_sample_0007": {"undelivered": 1.35, "early": 2.5711003818803593, "late": 2.9996171121937527, "service_over": 1.0, "return_over": 1.0, "secure": 0.2378387361340723, "distance": 2.0666331925397574, "duration": 0.8751631174359007, "risk": 0.3298844548264038, "loop": 1.25, "reservation": 0.25, "makespan": 1.312744676153851},
    "balanced": {"undelivered": 1.35, "early": 1.50, "late": 1.75, "service_over": 1.00, "return_over": 1.00, "secure": 0.50, "distance": 1.00, "duration": 0.50, "risk": 0.25, "loop": 1.25, "reservation": 0.25, "makespan": 0.75},
    "tw_priority": {"undelivered": 1.35, "early": 2.75, "late": 3.25, "service_over": 1.25, "return_over": 1.00, "secure": 0.35, "distance": 0.55, "duration": 0.40, "risk": 0.20, "loop": 1.10, "reservation": 0.25, "makespan": 0.55},
    "distance_priority": {"undelivered": 1.35, "early": 1.15, "late": 1.40, "service_over": 0.90, "return_over": 0.90, "secure": 0.30, "distance": 2.75, "duration": 0.65, "risk": 0.20, "loop": 1.30, "reservation": 0.25, "makespan": 0.65},
    "risk_priority": {"undelivered": 1.35, "early": 1.20, "late": 1.45, "service_over": 0.90, "return_over": 0.90, "secure": 1.10, "distance": 0.65, "duration": 0.45, "risk": 2.75, "loop": 1.10, "reservation": 0.25, "makespan": 0.55},
    "duration_priority": {"undelivered": 1.35, "early": 1.25, "late": 1.55, "service_over": 1.20, "return_over": 1.20, "secure": 0.30, "distance": 0.75, "duration": 2.50, "risk": 0.20, "loop": 1.15, "reservation": 0.25, "makespan": 1.75},
    "secure_priority": {"undelivered": 1.35, "early": 1.25, "late": 1.50, "service_over": 0.90, "return_over": 0.90, "secure": 2.75, "distance": 0.65, "duration": 0.45, "risk": 1.50, "loop": 1.10, "reservation": 0.25, "makespan": 0.55},
    "tw_distance": {"undelivered": 1.35, "early": 2.25, "late": 2.65, "service_over": 1.10, "return_over": 1.00, "secure": 0.30, "distance": 2.20, "duration": 0.50, "risk": 0.20, "loop": 1.20, "reservation": 0.25, "makespan": 0.65},
    "tw_risk": {"undelivered": 1.35, "early": 2.20, "late": 2.60, "service_over": 1.10, "return_over": 1.00, "secure": 0.75, "distance": 0.55, "duration": 0.40, "risk": 2.20, "loop": 1.10, "reservation": 0.25, "makespan": 0.55},
    "distance_risk": {"undelivered": 1.35, "early": 1.15, "late": 1.40, "service_over": 0.90, "return_over": 0.90, "secure": 0.75, "distance": 2.20, "duration": 0.50, "risk": 2.20, "loop": 1.20, "reservation": 0.25, "makespan": 0.60},
    "distance_secure": {"undelivered": 1.35, "early": 1.15, "late": 1.40, "service_over": 0.90, "return_over": 0.90, "secure": 2.20, "distance": 2.20, "duration": 0.50, "risk": 1.10, "loop": 1.20, "reservation": 0.25, "makespan": 0.60},
}
PREFERENCE_TRAINING_SCHEDULE = (
    "balanced_final_sample_0025", "balanced_final_sample_0025", "balanced_final_sample_0025",
    "tw_final_sample_0007", "tw_final_sample_0007", "tw_final_sample_0007",
    "balanced", "tw_priority", "distance_priority", "risk_priority", "duration_priority",
    "tw_distance", "tw_risk", "distance_risk", "distance_secure",
)
BASELINE_ONLY_EPISODES = int(os.environ.get("CIT_BASELINE_ONLY_EPISODES", "0"))
PREFERENCE_JITTER_ACTIVE = bool(int(os.environ.get("CIT_PREFERENCE_JITTER", "1")))
PREFERENCE_JITTER_FRACTION = float(os.environ.get("CIT_PREFERENCE_JITTER_FRACTION", "0.15"))
PARETO_EVAL_PERIOD = int(os.environ.get("CIT_PARETO_EVAL_PERIOD", "100"))
SOFT_REWARD_SCALE = float(os.environ.get("CIT_SOFT_REWARD_SCALE", "50.0"))
SOFT_EXPECTED_EPISODE_STEPS = float(os.environ.get("CIT_SOFT_EXPECTED_EPISODE_STEPS", "2000"))
ACTIVE_PREFERENCE_PROFILE = "balanced"


def apply_preference_profile(profile_name: str, jitter: bool = False) -> dict:
    global LAMBDA_UNDELIVERED, LAMBDA_EARLY, LAMBDA_LATE, LAMBDA_SERVICE_OVER
    global LAMBDA_RETURN_OVER, LAMBDA_SECURE, LAMBDA_DISTANCE, LAMBDA_DURATION
    global LAMBDA_RISK, LAMBDA_LOOP, LAMBDA_RESERVATION, LAMBDA_MAKESPAN
    global ACTIVE_PREFERENCE_PROFILE
    if profile_name not in PREFERENCE_PROFILE_WEIGHTS:
        raise KeyError(f"Unknown preference profile: {profile_name}")
    values = dict(PREFERENCE_PROFILE_WEIGHTS[profile_name])
    if jitter and PREFERENCE_JITTER_ACTIVE:
        soft_keys = [key for key in OBJECTIVE_WEIGHT_ORDER if key != "undelivered"]
        base_total = float(sum(max(0.0, float(values[key])) for key in soft_keys))
        frac = max(0.0, min(0.25, float(PREFERENCE_JITTER_FRACTION)))
        for key in soft_keys:
            values[key] = float(values[key]) * float(np.random.uniform(1.0 - frac, 1.0 + frac))
        jitter_total = float(sum(max(0.0, float(values[key])) for key in soft_keys))
        if base_total > 1e-12 and jitter_total > 1e-12:
            scale = base_total / jitter_total
            for key in soft_keys:
                values[key] = float(values[key]) * scale
    LAMBDA_UNDELIVERED = 1.35
    LAMBDA_EARLY = float(values["early"])
    LAMBDA_LATE = float(values["late"])
    LAMBDA_SERVICE_OVER = float(values["service_over"])
    LAMBDA_RETURN_OVER = float(values["return_over"])
    LAMBDA_SECURE = float(values["secure"])
    LAMBDA_DISTANCE = float(values["distance"])
    LAMBDA_DURATION = float(values["duration"])
    LAMBDA_RISK = float(values["risk"])
    LAMBDA_LOOP = float(values["loop"])
    LAMBDA_RESERVATION = float(values["reservation"])
    LAMBDA_MAKESPAN = float(values["makespan"])
    ACTIVE_PREFERENCE_PROFILE = str(profile_name)
    if SYNC_LEGACY_REWARD_WEIGHTS_FROM_OBJECTIVES:
        sync_legacy_reward_weights_from_objectives()
    return objective_weight_dict()


def sample_training_preference() -> tuple[str, dict]:
    idx = int(np.random.randint(0, len(PREFERENCE_TRAINING_SCHEDULE)))
    name = str(PREFERENCE_TRAINING_SCHEDULE[idx])
    return name, apply_preference_profile(name, jitter=True)


if PREFERENCE_CONDITIONED_ACTIVE:
    apply_preference_profile("balanced", jitter=False)

# Global seed (reproducibility). İstersen CLI ile override edebilirsin.
GLOBAL_SEED = 0



# ============================================================
# RUN LOGGING (console tee + CSV) - opsiyonel
# ============================================================

RUN_DIR: Optional[Path] = None
CSV_LOG_EVERY: int = 1
DUMP_ROUTES_EVERY: int = 0
CONSOLE_LOG_ENABLED: bool = True
_CONSOLE_FH = None


class _Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except Exception:
                pass
        for s in self.streams:
            try:
                s.flush()
            except Exception:
                pass

    def flush(self):
        for s in self.streams:
            try:
                s.flush()
            except Exception:
                pass


def _sanitize_run_name(name: str) -> str:
    name = (name or "").strip()
    if not name:
        return ""
    out = []
    for ch in name:
        if ch.isalnum() or ch in "._-":
            out.append(ch)
        else:
            out.append("_")
    s = "".join(out).strip("_")
    return s or "run"


def _make_unique_run_dir(base_dir: str, run_name: str) -> Path:
    base = Path(base_dir).expanduser()
    base.mkdir(parents=True, exist_ok=True)

    if not run_name:
        run_name = datetime.datetime.now().strftime("run_%Y%m%d_%H%M%S")
    run_name = _sanitize_run_name(run_name) or "run"

    run_dir = base / run_name
    if not run_dir.exists():
        run_dir.mkdir(parents=True, exist_ok=True)
        return run_dir

    # Eğer aynı isim varsa suffix ekleyelim
    for k in range(1, 1000):
        cand = base / f"{run_name}_{k:03d}"
        if not cand.exists():
            cand.mkdir(parents=True, exist_ok=True)
            return cand

    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def _setup_console_tee(run_dir: Path):
    global _CONSOLE_FH
    try:
        log_path = run_dir / "console.log"
        _CONSOLE_FH = open(log_path, "w", encoding="utf-8")
        sys.stdout = _Tee(sys.stdout, _CONSOLE_FH)
        sys.stderr = _Tee(sys.stderr, _CONSOLE_FH)
        atexit.register(lambda: _CONSOLE_FH and _CONSOLE_FH.close())
        print(f"[RUN] console.log -> {log_path}", flush=True)
    except Exception as e:
        # Burada print çalışır (en azından stdout'a)
        print(f"[RUN][WARN] Console log oluşturulamadı: {e}", flush=True)


class EpisodeCSVLogger:
    def __init__(self, path: Path, fieldnames):
        self.path = Path(path)
        self.fieldnames = list(fieldnames)
        self._fh = open(self.path, "w", newline="", encoding="utf-8")
        self._w = csv.DictWriter(self._fh, fieldnames=self.fieldnames)
        self._w.writeheader()
        self._fh.flush()
        atexit.register(self.close)

    def log(self, row: dict):
        if row is None:
            return
        safe = {k: row.get(k, "") for k in self.fieldnames}
        try:
            self._w.writerow(safe)
            self._fh.flush()
        except Exception:
            # Log yüzünden eğitim asla çökmesin
            pass

    def close(self):
        try:
            if self._fh:
                self._fh.close()
        except Exception:
            pass


def _apply_cli_overrides_if_main() -> None:
    """Komut satırından (CLI) hızlı ayar yapmak için.

    Örnek:
        python script.py --w1 1.0 --w2 0.08 --w3 2.0 --w4 0.15 --w_tw 0.6 --return_grace_min 180

    Not: Bu override'lar env/model oluşturulmadan önce çalışmalı.
    """

    # Bu dosya import edilirse arg parse etmek istemeyiz.
    if __name__ != "__main__":
        return

    global w1, w2, w3, w4, W_TIMEWINDOW
    global LAMBDA_UNDELIVERED, LAMBDA_EARLY, LAMBDA_LATE, LAMBDA_SERVICE_OVER, LAMBDA_RETURN_OVER
    global LAMBDA_SECURE, LAMBDA_DISTANCE, LAMBDA_DURATION, LAMBDA_RISK, LAMBDA_LOOP, LAMBDA_RESERVATION, LAMBDA_MAKESPAN
    global SYNC_LEGACY_REWARD_WEIGHTS_FROM_OBJECTIVES
    global SERVICE_END_MIN, RETURN_GRACE_MIN, MAX_ROUTE_DURATION_MIN
    global GLOBAL_SEED
    global RUN_DIR, CSV_LOG_EVERY, DUMP_ROUTES_EVERY, CONSOLE_LOG_ENABLED

    parser = argparse.ArgumentParser(add_help=True)
    parser.add_argument("--w1", type=float, default=w1, help="Fuel penalty weight")
    parser.add_argument("--w2", type=float, default=w2, help="Duration penalty weight")
    parser.add_argument("--w3", type=float, default=w3, help="Unsecure penalty weight")
    parser.add_argument("--w4", type=float, default=w4, help="Distance penalty weight")
    parser.add_argument("--w_tw", type=float, default=W_TIMEWINDOW, help="Time-window penalty weight")
    parser.add_argument("--lambda_undelivered", type=float, default=LAMBDA_UNDELIVERED, help="Undelivered unit objective weight")
    parser.add_argument("--lambda_early", type=float, default=LAMBDA_EARLY, help="Early time-window objective weight")
    parser.add_argument("--lambda_late", type=float, default=LAMBDA_LATE, help="Late time-window objective weight")
    parser.add_argument("--lambda_service_over", type=float, default=LAMBDA_SERVICE_OVER, help="Service-end overrun objective weight")
    parser.add_argument("--lambda_return_over", type=float, default=LAMBDA_RETURN_OVER, help="Return-grace overrun objective weight")
    parser.add_argument("--lambda_secure", type=float, default=LAMBDA_SECURE, help="Secure policy objective weight")
    parser.add_argument("--lambda_distance", type=float, default=LAMBDA_DISTANCE, help="Distance objective weight")
    parser.add_argument("--lambda_duration", type=float, default=LAMBDA_DURATION, help="Duration objective weight")
    parser.add_argument("--lambda_risk", type=float, default=LAMBDA_RISK, help="Risk objective weight")
    parser.add_argument("--lambda_loop", type=float, default=LAMBDA_LOOP, help="Loop/backtrack objective weight")
    parser.add_argument("--lambda_reservation", type=float, default=LAMBDA_RESERVATION, help="Reservation conflict objective weight")
    parser.add_argument("--lambda_makespan", type=float, default=LAMBDA_MAKESPAN, help="Fleet makespan objective weight")
    parser.add_argument("--sync_reward_weights", type=int, default=1, help="1: objective lambdalarından legacy reward weight'leri türet")
    parser.add_argument("--service_end_min", type=float, default=SERVICE_END_MIN,
                        help="Delivery kapanış dakikası (shift başlangıcına göre). Default=720")
    parser.add_argument("--return_grace_min", type=float, default=RETURN_GRACE_MIN,
                        help="Delivery sonrası dönüş toleransı (dk). Default=120")
    parser.add_argument("--seed", type=int, default=GLOBAL_SEED, help="Global RNG seed")

    # --- Run logging seçenekleri ---
    parser.add_argument("--log_dir", type=str, default="run_logs", help="Run log klasörü (varsayılan: run_logs)")
    parser.add_argument("--run_name", type=str, default="", help="Log klasör adı (boşsa timestamp)")
    parser.add_argument("--console_log", type=int, default=1,
                        help="1: stdout/stderr console.log'a yazılır (tee). 0: kapalı")
    parser.add_argument("--csv_log_every", type=int, default=1,
                        help="CSV episode log per N episode. 0: kapalı")
    parser.add_argument("--dump_routes_every", type=int, default=0,
                        help="0: kapalı, N: her N ep route_dump.json yaz")

    # Notebook/IDE gibi ortamlarda bilinmeyen arg'lar olabilir -> parse_known_args.
    args, _unknown = parser.parse_known_args()

    # --- objective ağırlıkları ---
    LAMBDA_UNDELIVERED = float(args.lambda_undelivered)
    LAMBDA_EARLY = float(args.lambda_early)
    LAMBDA_LATE = float(args.lambda_late)
    LAMBDA_SERVICE_OVER = float(args.lambda_service_over)
    LAMBDA_RETURN_OVER = float(args.lambda_return_over)
    LAMBDA_SECURE = float(args.lambda_secure)
    LAMBDA_DISTANCE = float(args.lambda_distance)
    LAMBDA_DURATION = float(args.lambda_duration)
    LAMBDA_RISK = float(args.lambda_risk)
    LAMBDA_LOOP = float(args.lambda_loop)
    LAMBDA_RESERVATION = float(args.lambda_reservation)
    LAMBDA_MAKESPAN = float(args.lambda_makespan)
    SYNC_LEGACY_REWARD_WEIGHTS_FROM_OBJECTIVES = bool(int(args.sync_reward_weights))

    # --- legacy reward ağırlıkları ---
    w1 = float(args.w1)
    w2 = float(args.w2)
    w3 = float(args.w3)
    w4 = float(args.w4)
    W_TIMEWINDOW = float(args.w_tw)
    if SYNC_LEGACY_REWARD_WEIGHTS_FROM_OBJECTIVES:
        sync_legacy_reward_weights_from_objectives()

    # --- shift / EOD ---
    SERVICE_END_MIN = float(args.service_end_min)
    RETURN_GRACE_MIN = float(args.return_grace_min)
    MAX_ROUTE_DURATION_MIN = SERVICE_END_MIN + RETURN_GRACE_MIN

    # --- seed ---
    GLOBAL_SEED = int(args.seed)

    # --- logging globals ---
    CONSOLE_LOG_ENABLED = bool(int(args.console_log))
    CSV_LOG_EVERY = max(0, int(args.csv_log_every))
    DUMP_ROUTES_EVERY = max(0, int(args.dump_routes_every))

    want_logs = CONSOLE_LOG_ENABLED or (CSV_LOG_EVERY > 0) or (DUMP_ROUTES_EVERY > 0)
    if want_logs:
        try:
            RUN_DIR = _make_unique_run_dir(args.log_dir, args.run_name)

            if CONSOLE_LOG_ENABLED:
                _setup_console_tee(RUN_DIR)

            # CLI args snapshot
            try:
                with open(RUN_DIR / "cli_args.json", "w", encoding="utf-8") as f:
                    json.dump(vars(args), f, ensure_ascii=False, indent=2)
            except Exception:
                pass

            print(f"[RUN] RUN_DIR = {RUN_DIR}", flush=True)
        except Exception as e:
            RUN_DIR = None
            print(f"[RUN][WARN] RUN_DIR oluşturulamadı: {e}", flush=True)


# CLI override'ları training başlamadan uygula.
_apply_cli_overrides_if_main()

# Reproducibility
random.seed(GLOBAL_SEED)
np.random.seed(GLOBAL_SEED)
try:
    tf.random.set_seed(GLOBAL_SEED)
except Exception:
    pass

# Ranking ve distance shaping de W_TIMEWINDOW ile ölçeklenir.

# Tamamlandıktan sonra depoya dönüş.
RETURN_AFTER_SOLVE_BONUS = 200.0
ALL_VEHICLES_RETURN_BONUS = 500.0
POST_SOLVE_STEP_PENALTY = -0.5
NOT_RETURNED_EOD_PENALTY = -200.0

# Time window gap shaping
EARLY_GAP_FACTOR = 1.00
LATE_GAP_FACTOR = 1.75
LATE_GAP_EXTRA = 5.0

# Reward clipping
REWARD_CLIP = 3000.0
REWARD_DISTANCE_CLIP = 5.0
INVALID_COST_THRES = 1e5
UNREACHABLE_PENALTY = -2.0

# Distance shaping
DIST_SCALE_PERCENTILE = 95
BETA_TW_GAP = 1.00

# Feasibility gating and completion pressure
SKIP_LATE_DEMANDS_IN_RANKING = False
MASK_LATE_DEMAND_ACTIONS = False
MASK_EARLY_DEMAND_ACTIONS = False
PREFER_OK_TARGETS_IN_RANKING = False

SOLVED_BONUS = 1000.0
REMAINING_UNIT_PENALTY_EOD = -200.0
REMAINING_UNIT_PENALTY_STALL = -30.0 # Stall ile araç ölürken kalan her unit için ceza (araç sayısına bölünür).
EOD_UNUSED_CAPACITY_PENALTY_PER_UNIT = -5.0  # EOD iken araçta kalan kapasite için ek ceza.

INF = float("inf")

# Ortalama hız. Time window bazlı. Data load sonrası doldurulur.
AVG_SPEED_TW = []


def tw_index_from_time(t_min: float) -> int:
    """Dakika cinsinden süreyi time window index'ine çevir."""
    idx = 0
    for i, start in enumerate(time_windows):
        if float(t_min) >= float(start):
            idx = int(i)
        else:
            break
    return int(idx)


def estimate_travel_minutes_from_dist(dist_m: float, tw_idx: int) -> float:
    """Shortest path mesafesinden kaba ETA dakikası. Velocity matrislerinin ortalaması kullanılır."""
    if dist_m <= 0 or (not np.isfinite(dist_m)):
        return 0.0
    if len(AVG_SPEED_TW) == 0:
        speed = 30.0
    else:
        tw = int(np.clip(int(tw_idx), 0, len(AVG_SPEED_TW) - 1))
        speed = float(AVG_SPEED_TW[tw])
        if speed <= 1e-6:
            speed = 30.0
    return float(dist_m / (speed * 1000.0 / 60.0))


def next_allowed_start_time(t_arrive_min: float, allowed_windows):
    """ETA erken ise, bir sonraki izinli pencere başlangıcını (dakika) döndür. Yoksa None.

    allowed_windows formatları (karışık olabilir):
      - index listesi: [0,2,3]  -> time_windows[0], time_windows[2], ...
      - dakika başlangıçları: [0,120,240] -> direkt dakika
      - interval listesi: [(0,120), (240,360)] veya [[0,120],[240,360]]
      - bozuk/nested format: [[3]] gibi tek elemanlı listeler

    Bu fonksiyon sadece "bir sonraki" pencere başlangıcını döndürmek için kullanılır.
    """
    if allowed_windows is None or len(allowed_windows) == 0:
        return None

    starts: list[float] = []
    for w in allowed_windows:
        if w is None:
            continue

        # [[3]] gibi nested tek elemanlı listeleri unwrap et
        if isinstance(w, (list, tuple, np.ndarray)):
            if len(w) == 0:
                continue
            if len(w) == 1:
                w = w[0]
            else:
                # (start,end) interval formatı
                try:
                    starts.append(float(w[0]))
                    continue
                except Exception:
                    # parse edemezsek aşağıda scalar olarak dene
                    pass

        # Scalar parse
        try:
            v = float(w)
        except Exception:
            continue

        # index mi dakika mı?
        if abs(v - round(v)) < 1e-9:
            iv = int(round(v))
            if 0 <= iv < len(time_windows):
                starts.append(float(time_windows[iv]))
            else:
                starts.append(float(v))
        else:
            starts.append(float(v))

    if not starts:
        return None

    starts = sorted(set(starts))
    t = float(t_arrive_min)
    for s in starts:
        if t < float(s) - 1e-9:
            return float(s)
    return None


def allowed_window_intervals(allowed_windows, window_size_min: float = WINDOW_SIZE_MIN):
    """allowed window tanımlarını (start,end) dakika aralıklarına çevir."""
    if allowed_windows is None or len(allowed_windows) == 0:
        return []

    ws = float(window_size_min) if float(window_size_min) > 1e-9 else 1.0
    intervals = []

    def _interval_from_token(tok):
        if tok is None:
            return None
        if isinstance(tok, (list, tuple, np.ndarray)):
            if len(tok) == 0:
                return None
            if len(tok) == 1:
                return _interval_from_token(tok[0])
            try:
                s = float(tok[0])
                e = float(tok[1])
                if e <= s:
                    e = s + ws
                return (s, e)
            except Exception:
                return None
        try:
            v = float(tok)
        except Exception:
            return None
        if abs(v - round(v)) < 1e-9:
            iv = int(round(v))
            if 0 <= iv < len(time_windows):
                s = float(time_windows[iv])
                if iv + 1 < len(time_windows):
                    e = float(time_windows[iv + 1])
                    if e <= s:
                        e = s + ws
                else:
                    e = s + ws
                return (s, e)
        s = float(v)
        return (s, s + ws)

    for tok in allowed_windows:
        iv = _interval_from_token(tok)
        if iv is not None:
            intervals.append((float(iv[0]), float(iv[1])))

    intervals = sorted(set(intervals))
    return intervals


# ============================================================
# Graph helpers
# ============================================================
def build_nav_neighbors(dst: np.ndarray, k: Optional[int]):
    """
    Navigation graph neighbor list.
    dst[u,v] > 0 ise edge var sayılır.
    k None ise tüm edge'leri alır.
    k verilirse en kısa k edge seçilir.

    Dense matrislerde np.argsort pahalı olur. np.argpartition ile top-k seçilip
    sonra deterministik olsun diye küçük bir sort yapılır.
    """
    n = int(dst.shape[0])
    neigh = []
    for u in range(n):
        row = dst[u]
        idx = np.where(row > 0)[0]
        if idx.size:
            idx = idx[idx != u]
        if idx.size and (k is not None) and (idx.size > int(k)):
            row_vals = row[idx]
            kk = int(k)
            part = np.argpartition(row_vals, kk - 1)[:kk]
            idx = idx[part]
            # deterministic order
            idx = idx[np.argsort(row[idx])]
        neigh.append(idx.astype(np.int32))
    return neigh

def build_reverse_graph(dst: np.ndarray, neigh):
    n = int(dst.shape[0])
    G_rev = [[] for _ in range(n)]
    for u in range(n):
        for v in neigh[u]:
            w = float(dst[u, int(v)])
            if w > 0:
                G_rev[int(v)].append((u, w))
    return G_rev


def bfs_reachable(neigh, src: int):
    n = len(neigh)
    seen = np.zeros(n, dtype=np.bool_)
    stack = [int(src)]
    seen[int(src)] = True
    while stack:
        u = int(stack.pop())
        for v in neigh[u]:
            vv = int(v)
            if not seen[vv]:
                seen[vv] = True
                stack.append(vv)
    return seen


def dijkstra_all_nodes(G, src: int):
    """
    Reverse-graph üzerinde tek kaynaklı Dijkstra.

    ÖNEMLİ.
    Eski sürümde dist float32 idi ve 'd != dist[u]' kontrolü bazı büyük ağırlık kombinasyonlarında
    düğümlerin işlenmesini atlayıp INF sonuçlara yol açabiliyordu.
    Burada dist float64 ve 'd > dist[u]' kontrolü ile bu sorun engellendi.
    """
    n = len(G)
    dist = np.full(n, INF, dtype=np.float64)
    dist[int(src)] = 0.0
    pq = [(0.0, int(src))]
    while pq:
        d, u = heapq.heappop(pq)
        if d > float(dist[u]) + 1e-9:
            continue
        for v, w in G[u]:
            nd = d + float(w)
            if nd < float(dist[v]):
                dist[v] = nd
                heapq.heappush(pq, (nd, int(v)))
    return dist



def dijkstra_multi_source(G, sources):
    """
    Multi-source Dijkstra.
    En yakın secure zone mesafesi gibi çoklu kaynak senaryolarında kullanılır.

    float32 + eşitlik kontrolü yerine float64 + toleranslı '>' kontrolü kullanılır.
    """
    n = len(G)
    dist = np.full(n, INF, dtype=np.float64)
    pq = []
    for s in sources:
        ss = int(s)
        if 0 <= ss < n:
            if float(dist[ss]) > 0.0:
                dist[ss] = 0.0
                heapq.heappush(pq, (0.0, ss))

    while pq:
        d, u = heapq.heappop(pq)
        if d > float(dist[u]) + 1e-9:
            continue
        for v, w in G[u]:
            nd = d + float(w)
            if nd < float(dist[v]):
                dist[v] = nd
                heapq.heappush(pq, (nd, int(v)))
    return dist



def time_window_gap_units(arrival_min: float, allowed_windows, window_size_min: float = WINDOW_SIZE_MIN):
    """Pencere dışı kalma miktarı (gap) ve durumu döndür.

    Bu fonksiyon, eski sürümlerdeki "[start,end]" pencereleri ile yeni sürümdeki
    "index" pencerelerini aynı anda destekleyecek şekilde *robust* tasarlandı.

    allowed_windows formatları (karışık olabilir):
      - index listesi: [0,2,3]  -> time_windows[0]..time_windows[3]
      - dakika başlangıçları: [0,120,240] (index değilse dakika kabul edilir)
      - interval listesi: [(0,120),(240,360)] veya [[0,120],[240,360]]
      - bozuk/nested format: [[3]] gibi tek elemanlı listeler

    Çıktı:
      gap_units: window_size_min biriminde normalize edilmiş fark (0 => pencere içinde)
      status: "ok" | "early" | "late"

    Not: gap_units, reward shaping içinde daha stabil olsun diye normalize edilir.
    """
    if allowed_windows is None or len(allowed_windows) == 0:
        return 0.0, "ok"

    a = float(arrival_min)
    ws = float(window_size_min) if float(window_size_min) > 1e-9 else 1.0

    best_gap: float | None = None
    best_status: str | None = None

    def _interval_from_token(tok):
        """Tek bir token'dan (start,end) dakika aralığı çıkar. Çıkarılamazsa None."""
        if tok is None:
            return None

        # Nested list/tuple: [[3]] gibi
        if isinstance(tok, (list, tuple, np.ndarray)):
            if len(tok) == 0:
                return None
            if len(tok) == 1:
                return _interval_from_token(tok[0])
            # [start,end]
            try:
                s = float(tok[0])
                e = float(tok[1])
                if e <= s:
                    e = s + ws
                return s, e
            except Exception:
                return None

        # Scalar parse
        try:
            v = float(tok)
        except Exception:
            return None

        # Integer-like ise önce index olarak yorumlamayı dene
        if abs(v - round(v)) < 1e-9:
            iv = int(round(v))
            if 0 <= iv < len(time_windows):
                s = float(time_windows[iv])
                # bir sonraki pencere başlangıcı varsa onu bitiş kabul et
                if iv + 1 < len(time_windows):
                    e = float(time_windows[iv + 1])
                    if e <= s:
                        e = s + ws
                else:
                    e = s + ws
                return s, e
            # index değilse dakika başlangıcı kabul et
            s = float(v)
            e = s + ws
            return s, e

        # Non-integer float: dakika başlangıcı kabul et
        s = float(v)
        e = s + ws
        return s, e

    for tw in allowed_windows:
        iv = _interval_from_token(tw)
        if iv is None:
            continue
        start, end = iv

        if a < float(start) - 1e-9:
            gap = (float(start) - a) / ws
            status = "early"
        elif a > float(end) + 1e-9:
            gap = (a - float(end)) / ws
            status = "late"
        else:
            gap = 0.0
            status = "ok"

        if best_gap is None or gap < best_gap:
            best_gap = float(gap)
            best_status = str(status)
            if best_gap <= 0.0:
                break

    if best_gap is None:
        # Hiç parse edilemeyen garip bir allowed_windows geldi.
        # Sert fail yerine kısıt yokmuş gibi davran.
        return 0.0, "ok"

    return float(best_gap), str(best_status)

def compute_loss(experiences, gamma, q_network, target_q_network):
    states, actions, rewards, next_states, done_vals, next_action_masks = experiences

    # REV6 masked Double DQN:
    # - online network selects the next valid action;
    # - target network evaluates that selected action;
    # - invalid candidate slots can never inflate the bootstrap target.
    q_next_online = q_network(next_states)
    q_next_masked = tf.where(
        tf.cast(next_action_masks, tf.bool),
        q_next_online,
        tf.fill(tf.shape(q_next_online), tf.cast(-1e9, q_next_online.dtype)),
    )
    next_actions = tf.argmax(q_next_masked, axis=-1, output_type=tf.int32)
    q_next_target_all = target_q_network(next_states)
    next_qsa = tf.gather_nd(
        q_next_target_all,
        tf.stack([tf.range(tf.shape(q_next_target_all)[0]), next_actions], axis=1),
    )

    y_targets = tf.stop_gradient(rewards + (gamma * next_qsa * (1.0 - done_vals)))

    q_values_all = q_network(states)
    q_values = tf.gather_nd(
        q_values_all,
        tf.stack([tf.range(tf.shape(q_values_all)[0]), tf.cast(actions, tf.int32)], axis=1)
    )

    # Keras MSE burada örnek-bazlı vektör döndürür. Öğrenme ve log için skalarlaştır.
    loss = tf.reduce_mean(MSE(y_targets, q_values))
    return loss


@tf.function
def agent_learn(experiences, gamma):
    with tf.GradientTape() as tape:
        loss = compute_loss(experiences, gamma, q_network, target_q_network)
    gradients = tape.gradient(loss, q_network.trainable_variables)
    optimizer.apply_gradients(zip(gradients, q_network.trainable_variables))
    return loss


# ============================================================
# Environment
# ============================================================
class Environment:
    def __init__(self, dst, velocity, velocity_noise, demands, delivery_windows_by_node,
                 n_vehicles, vehicle_capacities, depot=0,
                 secure_zones=None):
        self.dst = dst
        self.velocity = velocity
        self.velocity_noise = velocity_noise
        self.n_locations = int(dst.shape[0])

        self.depot = int(depot)

        self.demands_init = [(int(node), int(amount)) for node, amount in demands]
        self.demands = {int(node): int(amount) for node, amount in demands}

        # Demand totals (before any dropping).
        self.total_full_units = int(sum(int(a) for _n, a in self.demands_init))
        self.dropped_demands_init = []
        self.dropped_units = 0
        self.total_required_units = int(self.total_full_units)

        self.delivery_windows_by_node = delivery_windows_by_node

        self.n_vehicles = int(n_vehicles)
        self.vehicle_capacities = list(vehicle_capacities)

        self.secure_zones = set(int(z) for z in (secure_zones or set()) if 0 <= int(z) < self.n_locations)
        # Depot güvenli kabul edilir. Waiting depot'ta da serbest.
        self.secure_zones.add(int(self.depot))

        # Distance scale
        pos = dst[dst > 0]
        self.d_scale = float(np.percentile(pos, DIST_SCALE_PERCENTILE)) if pos.size else 1.0
        try:
            pos_r = security_risc[security_risc > 0]
            self.risk_scale = float(np.percentile(pos_r, 95)) if pos_r.size else 1.0
        except Exception:
            self.risk_scale = 1.0

        # Build navigation graph.
        self.nav_k, self.nav_neigh, self.G_rev, self.reach_mask = self._build_navigation_graph()
        self._drop_unreachable_demands_if_needed()

        # Shortest path cache for demands and depot
        nodes_to_cache = sorted(set([self.depot] + [n for n, _ in self.demands_init]))
        self.sp_cache = {}
        for node in nodes_to_cache:
            self.sp_cache[int(node)] = dijkstra_all_nodes(self.G_rev, int(node))

        # SP sanity. Depot -> demand mesafesi INF ise graph veya Dijkstra hesaplarında sorun var.
        if self.demands_init:
            sample_nodes = [int(n) for n, _a in self.demands_init[:5]]
            bad = []
            for dn in sample_nodes:
                arr = self.sp_cache.get(int(dn))
                if arr is None:
                    bad.append(int(dn))
                    continue
                dd = float(arr[int(self.depot)])
                if not np.isfinite(dd):
                    bad.append(int(dn))
            if bad:
                print(f"[SANITY][WARN] depot->demand shortest path INF. sample_bad={bad}. NAV graph veya mesafe matrisi sorunlu olabilir.", flush=True)

        # Multi-source shortest path to nearest secure zone
        if self.secure_zones:
            self.dist_to_secure = dijkstra_multi_source(self.G_rev, list(self.secure_zones))
        else:
            self.dist_to_secure = np.full(self.n_locations, INF, dtype=np.float32)

        # State holders
        self.location = self.depot
        self.one_hot_location = self.one_hot_encode(self.location, self.n_locations)
        self.one_hot_demands = self.one_hot_encode_demands()


        # Episode durumları. Reset ile sıfırlanır.
        self.all_delivered = False
        self.returned_vehicle_ids = set()
        self.vehicles_ref = []

    def _build_navigation_graph(self):
        n = int(self.n_locations)
        deg = np.sum(self.dst > 0, axis=1).astype(np.int32)
        mean_deg = float(np.mean(deg)) if deg.size else 0.0

        demand_nodes = [int(node) for node, _ in self.demands_init]
        demand_nodes = [d for d in demand_nodes if 0 <= d < n]

        # Sparse graph. Edge kırpma yapma.
        if mean_deg <= float(SPARSE_DEG_THRESHOLD):
            neigh = build_nav_neighbors(self.dst, None)
            reach = bfs_reachable(neigh, self.depot)
            G_rev = build_reverse_graph(self.dst, neigh)
            self._print_nav_sanity(neigh, reach, demand_nodes, nav_k=None, mean_deg=mean_deg)
            return None, neigh, G_rev, reach

        # Dense graph. KNN ile başlayıp reachability sağlanana kadar K artır.
        nav_k = int(NAV_K_START)
        while True:
            neigh = build_nav_neighbors(self.dst, nav_k)
            reach = bfs_reachable(neigh, self.depot)
            G_rev = build_reverse_graph(self.dst, neigh)
            self._print_nav_sanity(neigh, reach, demand_nodes, nav_k=nav_k, mean_deg=mean_deg)

            if all(bool(reach[d]) for d in demand_nodes):
                return nav_k, neigh, G_rev, reach

            if nav_k >= int(NAV_K_MAX):
                print(
                    f"[SANITY][WARN] NAV graph hala kopuk. nav_k={nav_k} ile bile tüm demand'lar erişilebilir değil. "
                    f"Bu instance bu graph tanımı ile çözülemez. Distance matrisi veya NAV_K ayarını kontrol et.",
                    flush=True
                )
                return nav_k, neigh, G_rev, reach

            nav_k += int(NAV_K_STEP)

    def _print_nav_sanity(self, neigh, reach, demand_nodes, nav_k, mean_deg):
        degrees = [len(neigh[i]) for i in range(min(200, len(neigh)))]
        deg_min = int(np.min(degrees)) if degrees else 0
        deg_max = int(np.max(degrees)) if degrees else 0
        deg_mean_sample = float(np.mean(degrees)) if degrees else 0.0
        reachable_nodes = int(np.sum(reach))
        unreachable_demands = [d for d in demand_nodes if not bool(reach[d])]
        msg = (
            f"[SANITY] NAV graph nav_k={nav_k} mean_deg_raw={mean_deg:.1f} "
            f"deg(min/mean/max)~={deg_min}/{deg_mean_sample:.2f}/{deg_max} "
            f"reachable_nodes={reachable_nodes}/{len(neigh)} "
            f"unreachable_demands={len(unreachable_demands)}"
        )
        print(msg, flush=True)
        if unreachable_demands:
            print(f"[SANITY][WARN] unreachable demand sample={unreachable_demands[:10]}", flush=True)


    def _drop_unreachable_demands_if_needed(self):
        """
        Eğer navigation graph üzerinde depot'tan erişilemeyen demand node varsa,
        onları demand listesinden çıkarır.
        Bu bir "çözüm" değil, infeasible işleri açıkça düşürme stratejisidir.
        """
        # total_full_units zaten __init__ başında hesaplandı.
        if not DROP_UNREACHABLE_DEMANDS:
            self.total_required_units = int(sum(int(a) for _n, a in self.demands_init))
            return

        kept = []
        dropped = []
        for node, amount in self.demands_init:
            n = int(node)
            a = int(amount)
            ok = (0 <= n < self.n_locations) and bool(self.reach_mask[n])
            if ok:
                kept.append((n, a))
            else:
                dropped.append((n, a))

        if dropped:
            self.dropped_demands_init = dropped
            self.dropped_units = int(sum(int(a) for _n, a in dropped))
            self.demands_init = kept
            self.demands = {int(n): int(a) for n, a in kept}

            sample_nodes = [int(n) for n, _a in dropped[:10]]
            print(
                f"[SANITY][DROP] unreachable demands dropped. nodes={len(dropped)} units={self.dropped_units} sample={sample_nodes}",
                flush=True
            )

        self.total_required_units = int(sum(int(a) for _n, a in self.demands_init))

    def one_hot_encode(self, index, size):
        v = np.zeros(size, dtype=np.float32)
        v[int(index)] = 1.0
        return v

    def one_hot_encode_time_window(self, time_window, current_time_window):
        v = np.zeros(len(time_window), dtype=np.float32)
        v[int(current_time_window)] = 1.0
        return v

    def one_hot_encode_demands(self):
        v = np.zeros(self.n_locations, dtype=np.float32)
        for node in self.demands:
            v[int(node)] = 1.0
        return v

    def remaining_units(self) -> int:
        """Kalan toplam teslimat adedi."""
        return int(sum(int(v) for v in self.demands.values()))

    def register_vehicles(self, vehicles):
        self.vehicles_ref = list(vehicles or [])

    def active_vehicle_count(self) -> int:
        if not getattr(self, "vehicles_ref", None):
            return int(self.n_vehicles)
        return int(sum(1 for vv in self.vehicles_ref if (not getattr(vv, "done_vehicle", False))))

    def estimate_eta_to_node(self, from_node: int, to_node: int, cur_time_min: float) -> float:
        dist = self._dist_to(int(from_node), int(to_node))
        if not np.isfinite(dist):
            return INF
        cur_tw = tw_index_from_time(float(cur_time_min))
        travel = estimate_travel_minutes_from_dist(dist, int(cur_tw))
        return float(cur_time_min) + float(travel)

    def _reservation_map(self, exclude_vehicle_id: int | None = None) -> dict:
        out = {}
        for vv in getattr(self, "vehicles_ref", []):
            if exclude_vehicle_id is not None and int(vv.vehicle_id) == int(exclude_vehicle_id):
                continue
            if getattr(vv, "done_vehicle", False):
                continue
            lt = int(getattr(vv, "locked_target", -1))
            if lt == -1:
                continue
            if lt not in self.demands:
                continue
            eta = self.estimate_eta_to_node(vv.current_location, lt, vv.total_duration)
            prev = out.get(int(lt))
            if prev is None or eta < prev[0]:
                out[int(lt)] = (float(eta), int(vv.vehicle_id))
        return out

    def _dist_to_secure_norm(self, node: int) -> float:
        try:
            d = float(self.dist_to_secure[int(node)])
        except Exception:
            d = INF
        if not np.isfinite(d):
            return 1.0
        return float(np.clip(d / max(1e-6, self.d_scale), 0.0, 1.0))

    def effective_objective_weights(self, vehicle=None) -> dict:
        weights = objective_weight_dict()
        phase = str(getattr(self, "curriculum_phase", "optimization"))
        if GATED_CURRICULUM_ACTIVE and phase == "feasibility":
            # Distance/duration/risk must not buy a failure of the primary goal.
            weights["undelivered"] *= 4.0
            weights["return_over"] *= 2.5
            weights["secure"] *= 1.8
            for key in ("distance", "duration", "risk", "loop", "makespan"):
                weights[key] *= 0.20
        elif GATED_CURRICULUM_ACTIVE and phase == "time_window":
            weights["undelivered"] *= 3.0
            weights["early"] *= 2.5
            weights["late"] *= 2.5
            weights["return_over"] *= 2.0
            for key in ("distance", "duration", "risk", "makespan"):
                weights[key] *= 0.40
        rem_units = int(self.remaining_units())
        if rem_units <= 0:
            return weights
        rem_ratio = float(rem_units) / max(1.0, float(self.total_required_units))
        progress_ratio = 1.0 - rem_ratio
        cur_time = 0.0
        if vehicle is not None:
            cur_time = float(getattr(vehicle, "total_duration", 0.0))
        else:
            try:
                cur_time = float(max([float(getattr(vv, "total_duration", 0.0)) for vv in getattr(self, "vehicles_ref", [])] + [0.0]))
            except Exception:
                cur_time = 0.0
        time_ratio = float(np.clip(cur_time / max(1.0, float(ABSOLUTE_MAX_ROUTE_DURATION_MIN)), 0.0, 1.0))
        finish_extra = max(0.0, progress_ratio - float(FINISH_PRESSURE_START_RATIO)) / max(1e-6, 1.0 - float(FINISH_PRESSURE_START_RATIO))
        undelivered_mult = 1.0 + float(PHASE_UNDELIVERED_GAIN) * float(finish_extra)
        undelivered_mult += float(PHASE_UNDELIVERED_TIME_GAIN) * max(0.0, time_ratio - 0.55)
        if rem_units <= int(TERMINAL_REPAIR_REMAINING_UNITS):
            undelivered_mult += float(PHASE_UNDELIVERED_REMAINING_BOOST)
            weights["reservation"] *= 1.0 + 0.35 * float(PHASE_UNDELIVERED_REMAINING_BOOST)
            weights["loop"] *= 1.0 + 0.20 * float(PHASE_UNDELIVERED_REMAINING_BOOST)
        weights["undelivered"] *= float(max(1.0, undelivered_mult))
        return weights

    def scalarize_cost_terms(self, cost_terms: dict, vehicle=None) -> float:
        return float(scalarize_cost_terms(cost_terms, weights=self.effective_objective_weights(vehicle)))

    def _edge_risk_proxy(self, from_node: int, to_node: int) -> float:
        arr = self.sp_cache.get(int(to_node))
        hop = self.next_hop_towards(int(from_node), arr) if arr is not None else None
        if hop is None:
            return 1.0
        try:
            risk = float(security_risc[int(from_node), int(hop)])
        except Exception:
            risk = 0.0
        scale = max(1e-6, float(getattr(self, "risk_scale", 1.0)))
        return float(np.clip(max(0.0, risk) / scale, 0.0, 1.25))

    def candidate_cost_terms(self, vehicle, det: dict) -> dict:
        cur = int(vehicle.current_location)
        node = int(det.get("node", -1))
        status = str(det.get("status", "none"))
        _visited = getattr(vehicle, "visited_locations", None)
        if _visited is None:
            _visited = [int(cur)]
        try:
            _visited = list(_visited)
        except Exception:
            _visited = [int(cur)]
        if len(_visited) == 0:
            _visited = [int(cur)]
        recent = _visited[-RECENT_WINDOW:] if len(_visited) >= RECENT_WINDOW else _visited

        makespan_before = max([float(vv.total_duration) for vv in getattr(self, "vehicles_ref", [])] + [float(vehicle.total_duration)])
        eta = float(det.get("eta", vehicle.total_duration))
        makespan_after = max(makespan_before, eta)
        makespan_delta = max(0.0, float(makespan_after) - float(makespan_before)) / max(1.0, WINDOW_SIZE_MIN)

        secure_cost = 0.0
        if status == "early":
            secure_cost += 0.22 * float(self._dist_to_secure_norm(cur))
        if (node not in self.secure_zones) and (node != self.depot):
            secure_cost += 0.10 * float(self._dist_to_secure_norm(node))

        early_norm = float(det.get("minutes_to_open", 0.0)) / max(1.0, WINDOW_SIZE_MIN)
        late_norm = float(det.get("late_gap_min", 0.0)) / max(1.0, WINDOW_SIZE_MIN)
        service_over_norm = float(det.get("service_over_min", 0.0)) / max(1.0, WINDOW_SIZE_MIN)
        return_over_norm = float(det.get("return_over_min", 0.0)) / max(1.0, WINDOW_SIZE_MIN)
        duration_norm = float(det.get("travel_min", 0.0)) / max(1.0, WINDOW_SIZE_MIN)
        distance_norm = float(np.clip(det.get("dist_norm", 0.0), 0.0, OBJECTIVE_TERM_CAPS["distance"]))
        risk_norm = float(self._edge_risk_proxy(cur, node))

        deliver_now = bool(det.get("deliver_now", 0.0) > 0.5)
        deliver_rescue = bool(det.get("deliver_rescue", 0.0) > 0.5)
        demand_ratio = float(det.get("demand_units", 0.0)) / max(1.0, float(self.total_required_units))
        rem_units_now = int(self.remaining_units())
        finish_mode = rem_units_now <= int(FINISH_BIAS_REMAINING_UNITS)
        finish_ratio = 1.0 - (float(rem_units_now) / max(1.0, float(self.total_required_units)))
        finish_pressure = 1.0 + float(FINISH_PRESSURE_GAIN) * max(0.0, finish_ratio - float(FINISH_PRESSURE_START_RATIO)) / max(1e-6, 1.0 - float(FINISH_PRESSURE_START_RATIO))

        undelivered_cost = 0.0
        if status == "early":
            undelivered_cost += float(CANDIDATE_UNDELIVERED_EARLY) + 0.35 * float(min(1.5, early_norm))
        if status == "late":
            undelivered_cost += float(CANDIDATE_UNDELIVERED_LATE) * float(min(1.5, late_norm + 0.5))
        if service_over_norm > 0.0:
            undelivered_cost += float(CANDIDATE_UNDELIVERED_SERVICE_OVER) * float(min(1.75, service_over_norm + 0.25))
        if return_over_norm > 0.0:
            undelivered_cost += float(CANDIDATE_UNDELIVERED_RETURN_OVER) * float(min(2.0, return_over_norm + 0.25))

        progress_credit = 0.0
        if deliver_now:
            progress_credit += float(CANDIDATE_PROGRESS_CREDIT_OK) * float(finish_pressure)
            progress_credit += 0.20 * min(0.50, demand_ratio * 4.0)
            if finish_mode:
                progress_credit += float(FINISH_DELIVER_NOW_EXTRA)
        elif deliver_rescue:
            progress_credit += float(CANDIDATE_PROGRESS_CREDIT_RESCUE) * float(finish_pressure)
            if finish_mode:
                progress_credit += float(FINISH_DELIVER_RESCUE_EXTRA)
        elif finish_mode:
            undelivered_cost += float(FINISH_UNDELIVERED_EXTRA) * float(finish_pressure)

        reservation_cost = float(det.get("reserved", 0.0)) * (1.0 if float(det.get("reservation_advantage", 0.0)) > 0.0 else 0.50)
        if finish_mode and float(det.get("reserved", 0.0)) > 0.0:
            reservation_cost += float(FINISH_RESERVATION_EXTRA)
        if deliver_now and float(det.get("reservation_advantage", 0.0)) <= 0.0:
            reservation_cost *= 0.50

        loop_cost = 1.0 if int(node) in recent else 0.0
        if loop_cost > 0.0:
            loop_cost += float(LOOP_COST_RECENT_BONUS)
            loop_cost += float(LOOP_COST_STREAK_GAIN) * min(2.0, float(getattr(vehicle, "no_progress_streak", 0)) / 4.0)
            if (not deliver_now) and (not deliver_rescue):
                loop_cost += 0.10
        if self.is_looping(_visited):
            loop_cost += float(LOOP_COST_GLOBAL_LOOP_BONUS)

        costs = {
            "undelivered": float(np.clip(undelivered_cost - progress_credit, -1.25, OBJECTIVE_TERM_CAPS["undelivered"])),
            "early": float(np.clip(early_norm if status == "early" else 0.0, 0.0, OBJECTIVE_TERM_CAPS["early"])),
            "late": float(np.clip(late_norm if status == "late" else 0.0, 0.0, OBJECTIVE_TERM_CAPS["late"])),
            "service_over": float(np.clip(service_over_norm, 0.0, OBJECTIVE_TERM_CAPS["service_over"])),
            "return_over": float(np.clip(return_over_norm, 0.0, OBJECTIVE_TERM_CAPS["return_over"])),
            "secure": float(np.clip(secure_cost, 0.0, OBJECTIVE_TERM_CAPS["secure"])),
            "distance": float(distance_norm),
            "duration": float(np.clip(duration_norm, 0.0, OBJECTIVE_TERM_CAPS["duration"])),
            "risk": float(np.clip(risk_norm, 0.0, OBJECTIVE_TERM_CAPS["risk"])),
            "loop": float(np.clip(loop_cost, 0.0, OBJECTIVE_TERM_CAPS["loop"])),
            "reservation": float(np.clip(reservation_cost, 0.0, OBJECTIVE_TERM_CAPS["reservation"])),
            "makespan": float(np.clip(makespan_delta, 0.0, OBJECTIVE_TERM_CAPS["makespan"])),
        }
        return costs

    def wait_cost_terms(self, vehicle, candidate_details=None) -> dict:
        details = list(candidate_details or [])
        cur_time = float(vehicle.total_duration)
        at_secure = bool(int(vehicle.current_location) in self.secure_zones)
        rem_units_ratio = float(self.remaining_units()) / max(1.0, float(self.total_required_units))
        early_opens = [float(d.get("minutes_to_open", 0.0)) for d in details if str(d.get("status", "")) == "early"]
        wait_min = float(np.clip(min(early_opens) if early_opens else float(SECURE_WAIT_MIN), float(SECURE_WAIT_MIN), float(WAIT_CHUNK_MAX)))
        service_over = max(0.0, (float(cur_time) + float(wait_min)) - float(SERVICE_END_MIN)) / max(1.0, WINDOW_SIZE_MIN)
        return_over = max(0.0, (float(cur_time) + float(wait_min)) - float(MAX_ROUTE_DURATION_MIN)) / max(1.0, WINDOW_SIZE_MIN)
        deliverable_now_exists = any(bool(d.get("deliver_now", 0.0) > 0.5) for d in details)
        deliverable_rescue_exists = any(bool(d.get("deliver_rescue", 0.0) > 0.5) for d in details)
        rem_units_now = int(self.remaining_units())
        finish_mode = rem_units_now <= int(FINISH_BIAS_REMAINING_UNITS)
        finish_ratio = 1.0 - (float(rem_units_now) / max(1.0, float(self.total_required_units)))
        finish_pressure = 1.0 + float(FINISH_PRESSURE_GAIN) * max(0.0, finish_ratio - float(FINISH_PRESSURE_START_RATIO)) / max(1e-6, 1.0 - float(FINISH_PRESSURE_START_RATIO))

        undelivered = float(WAIT_UNDELIVERED_SCALE) * float(rem_units_ratio) * float(wait_min) / max(1.0, WINDOW_SIZE_MIN)
        if deliverable_now_exists:
            undelivered += float(WAIT_OK_EXISTS_EXTRA) * float(rem_units_ratio) * float(finish_pressure)
        elif deliverable_rescue_exists:
            undelivered += float(WAIT_RESCUE_EXISTS_EXTRA) * float(rem_units_ratio) * float(finish_pressure)
        if not at_secure:
            undelivered += float(WAIT_NOT_SECURE_PROGRESS_PENALTY) * float(self._dist_to_secure_norm(int(vehicle.current_location))) * max(0.40, float(rem_units_ratio))
            if deliverable_now_exists:
                undelivered += float(WAIT_NOT_SECURE_WHEN_OK_EXTRA) * float(finish_pressure)
        if finish_mode:
            undelivered += float(FINISH_WAIT_EXTRA) * float(finish_pressure)
            if deliverable_now_exists:
                undelivered += 0.35 * float(FINISH_WAIT_EXTRA)
            elif deliverable_rescue_exists:
                undelivered += 0.18 * float(FINISH_WAIT_EXTRA)

        cost = {
            "undelivered": float(np.clip(undelivered, 0.0, OBJECTIVE_TERM_CAPS["undelivered"])),
            "early": 0.0,
            "late": 0.0,
            "service_over": float(np.clip(service_over, 0.0, OBJECTIVE_TERM_CAPS["service_over"])),
            "return_over": float(np.clip(return_over, 0.0, OBJECTIVE_TERM_CAPS["return_over"])),
            "secure": 0.0 if at_secure else float(np.clip(self._dist_to_secure_norm(int(vehicle.current_location)), 0.0, OBJECTIVE_TERM_CAPS["secure"])),
            "distance": 0.10 * float(self._dist_to_secure_norm(int(vehicle.current_location))) if not at_secure else 0.0,
            "duration": float(np.clip(float(wait_min) / max(1.0, WINDOW_SIZE_MIN), 0.0, OBJECTIVE_TERM_CAPS["duration"])),
            "risk": 0.0 if at_secure else 0.20 * float(np.clip(self._dist_to_secure_norm(int(vehicle.current_location)), 0.0, OBJECTIVE_TERM_CAPS["risk"])),
            "loop": 0.05 if not at_secure else 0.0,
            "reservation": 0.10 * float(len(self._reservation_map())) / max(1.0, float(self.total_required_units)),
            "makespan": float(np.clip(float(wait_min) / max(1.0, WINDOW_SIZE_MIN), 0.0, OBJECTIVE_TERM_CAPS["makespan"])),
        }
        return cost

    def vehicle_dispatch_priority(self, vehicle) -> float:
        details = self.get_candidate_details(vehicle, topk=max(1, CANDIDATE_TOPK))
        best_cost = float(details[0].get("scalar_cost", 0.0)) if details else float(self.scalarize_cost_terms(self.wait_cost_terms(vehicle, details), vehicle=vehicle))
        t_norm = float(vehicle.total_duration) / max(1.0, ABSOLUTE_MAX_ROUTE_DURATION_MIN)
        cap_norm = float(vehicle.capacity) / max(1.0, max(self.vehicle_capacities))
        progress_bonus = 0.0
        if any(bool(d.get("deliver_now", 0.0) > 0.5) for d in details):
            progress_bonus += float(DISPATCH_PRIORITY_PROGRESS_BONUS)
        elif any(bool(d.get("deliver_rescue", 0.0) > 0.5) for d in details):
            progress_bonus += 0.5 * float(DISPATCH_PRIORITY_PROGRESS_BONUS)
        return float(t_norm + 0.30 * best_cost - 0.10 * cap_norm - progress_bonus)

    def rescue_mode(self, vehicle, candidate_details=None) -> bool:
        if not RESCUE_MODE_ACTIVE:
            return False
        cur_time = float(vehicle.total_duration)
        rem_units = int(self.remaining_units())
        if rem_units <= 0:
            return False
        if cur_time > float(SERVICE_END_MIN) + 1e-9:
            return True

        if candidate_details is None:
            candidate_details = self.get_candidate_details(vehicle, topk=CANDIDATE_TOPK)

        ok_exists = any(str(d.get("status", "")) == "ok" for d in candidate_details)
        late_exists = any(str(d.get("status", "")) == "late" for d in candidate_details)
        if (not ok_exists) and late_exists and cur_time >= float(SERVICE_END_MIN - RESCUE_LOOKAHEAD_MIN):
            return True

        active_count = max(1, self.active_vehicle_count())
        avg_units_per_active = float(rem_units) / float(active_count)
        if cur_time >= float(SERVICE_END_MIN - RESCUE_LOOKAHEAD_MIN):
            if avg_units_per_active > max(1.0, 0.75 * float(max(1, vehicle.capacity))):
                return True

        return False

    def allow_early_delivery(self, vehicle, node: int, eta_est: float) -> bool:
        if not ALLOW_EARLY_DELIVERY_IN_RESCUE:
            return False
        return bool(self.rescue_mode(vehicle))

    def get_candidate_details(self, vehicle, topk: int = CANDIDATE_TOPK):
        cur = int(vehicle.current_location)
        cur_time = float(vehicle.total_duration)
        cur_tw = tw_index_from_time(cur_time)
        reservations = self._reservation_map(exclude_vehicle_id=int(vehicle.vehicle_id))
        rescue = self.rescue_mode(vehicle, candidate_details=[])

        details = []
        for d in self.demands.keys():
            dd = int(d)
            dist = self._dist_to(cur, dd)
            if not np.isfinite(dist):
                continue

            travel_min = estimate_travel_minutes_from_dist(dist, int(cur_tw))
            eta = float(cur_time) + float(travel_min)
            allowed = self.delivery_windows_by_node.get(dd, [])
            gap_units, status = time_window_gap_units(eta, allowed)
            intervals = allowed_window_intervals(allowed)

            minutes_to_open = 0.0
            minutes_to_close = 0.0
            early_gap_min = 0.0
            late_gap_min = 0.0

            if intervals:
                if status == "early":
                    future_starts = [float(s) for s, _e in intervals if float(s) >= float(eta) - 1e-9]
                    if future_starts:
                        minutes_to_open = max(0.0, float(min(future_starts)) - float(eta))
                        early_gap_min = float(minutes_to_open)
                elif status == "ok":
                    valid_ends = [float(e) for s, e in intervals if float(s) - 1e-9 <= float(eta) <= float(e) + 1e-9]
                    if valid_ends:
                        minutes_to_close = max(0.0, float(min(valid_ends)) - float(eta))
                elif status == "late":
                    late_gap_min = float(gap_units) * float(WINDOW_SIZE_MIN)

            service_over_min = max(0.0, float(eta) - float(SERVICE_END_MIN))
            eta_home = float(eta) + float(estimate_travel_minutes_from_dist(self._dist_to(dd, self.depot), tw_index_from_time(eta)))
            return_over_min = max(0.0, float(eta_home) - float(MAX_ROUTE_DURATION_MIN))

            reserved = int(dd in reservations)
            reserved_eta = reservations.get(dd, (INF, -1))[0]
            reservation_advantage = 1.0 if (reserved and float(reserved_eta) <= float(eta) + 1e-6) else 0.0
            lock_bonus = 1.0 if int(getattr(vehicle, "locked_target", -1)) == int(dd) else 0.0

            dist_norm = float(dist / max(1e-6, self.d_scale))
            eta_norm = float(eta / max(1.0, ABSOLUTE_MAX_ROUTE_DURATION_MIN))
            deliver_now = 0.0
            deliver_rescue = 0.0
            if str(status) == "ok" and float(eta) <= float(ABSOLUTE_MAX_ROUTE_DURATION_MIN) + 1e-9:
                deliver_now = 1.0
            elif str(status) == "late" and float(eta) <= float(ABSOLUTE_MAX_ROUTE_DURATION_MIN) + 1e-9:
                deliver_rescue = 1.0

            base_det = {
                "node": int(dd),
                "dist": float(dist),
                "dist_norm": float(dist_norm),
                "travel_min": float(travel_min),
                "eta": float(eta),
                "eta_norm": float(eta_norm),
                "gap_units": float(gap_units),
                "status": str(status),
                "minutes_to_open": float(minutes_to_open),
                "minutes_to_close": float(minutes_to_close),
                "early_gap_min": float(early_gap_min),
                "late_gap_min": float(late_gap_min),
                "service_over_min": float(service_over_min),
                "return_over_min": float(return_over_min),
                "reserved": int(reserved),
                "reservation_advantage": float(reservation_advantage),
                "demand_units": int(self.demands.get(dd, 0)),
                "lock_bonus": float(lock_bonus),
                "rescue_mode": float(rescue),
                "deliver_now": float(deliver_now),
                "deliver_rescue": float(deliver_rescue),
            }
            cost_terms = self.candidate_cost_terms(vehicle, base_det)
            scalar_cost = float(np.clip(self.scalarize_cost_terms(cost_terms, vehicle=vehicle), -float(SCALAR_COST_CLIP), float(SCALAR_COST_CLIP)))
            if float(lock_bonus) > 0.0:
                scalar_cost -= 0.18
            if bool(base_det.get("deliver_now", 0.0) > 0.5):
                scalar_cost -= 0.10
            base_det["cost_terms"] = {k: float(cost_terms.get(k, 0.0)) for k in OBJECTIVE_WEIGHT_ORDER}
            base_det["scalar_cost"] = float(scalar_cost)
            base_det["score"] = float(scalar_cost)
            details.append(base_det)

        details.sort(key=lambda z: (float(z.get("scalar_cost", z.get("score", 1e9))), int(z["node"])))
        return details[:int(topk)]

    def _candidate_row_from_detail(self, det: dict) -> np.ndarray:
        if not det:
            return np.zeros(CANDIDATE_FEATURES_PER_SLOT, dtype=np.float32)
        status = str(det.get("status", "none"))
        ct = dict(det.get("cost_terms", {}) or {})
        return np.array([
            1.0,
            float(det.get("scalar_cost", det.get("score", 0.0))) / max(1.0, SCALAR_COST_CLIP),
            float(det.get("dist_norm", 0.0)),
            float(det.get("eta_norm", 0.0)),
            float(det.get("travel_min", 0.0)) / max(1.0, ABSOLUTE_MAX_ROUTE_DURATION_MIN),
            float(det.get("minutes_to_open", 0.0)) / max(1.0, WINDOW_SIZE_MIN),
            float(det.get("minutes_to_close", 0.0)) / max(1.0, WINDOW_SIZE_MIN),
            float(det.get("early_gap_min", 0.0)) / max(1.0, WINDOW_SIZE_MIN),
            float(det.get("late_gap_min", 0.0)) / max(1.0, WINDOW_SIZE_MIN),
            float(det.get("service_over_min", 0.0)) / max(1.0, WINDOW_SIZE_MIN),
            float(det.get("return_over_min", 0.0)) / max(1.0, WINDOW_SIZE_MIN),
            1.0 if status == "early" else 0.0,
            1.0 if status == "ok" else 0.0,
            1.0 if status == "late" else 0.0,
            float(det.get("demand_units", 0.0)) / max(1.0, float(self.total_required_units)),
            float(det.get("reserved", 0.0)),
            float(det.get("reservation_advantage", 0.0)),
            float(ct.get("secure", 0.0)),
            float(ct.get("risk", 0.0)),
            float(ct.get("loop", 0.0)),
            float(ct.get("reservation", 0.0)),
            float(ct.get("makespan", 0.0)),
            float(ct.get("duration", 0.0)),
            float(det.get("rescue_mode", 0.0)),
        ], dtype=np.float32)

    def fuel_efficiency(self, speed):
        if speed <= 0:
            return 0.0
        if speed < 40:
            return 5.0 + 0.2 * speed
        if speed <= 90:
            return float(-0.02 * (speed - 60) ** 2 + 20)
        return float(max(5.0, 20.0 - 0.1 * (speed - 90)))

    def hierarchical_obs_vector(self, vehicle, candidate_details=None) -> np.ndarray:
        """Observation terms that explain the hierarchical CIT rewards."""
        if not HIER_CIT_ACTIVE:
            return np.zeros(HIER_OBS_DIM, dtype=np.float32)

        if candidate_details is None:
            candidate_details = self.get_candidate_details(vehicle, topk=CANDIDATE_TOPK)

        rem_units = float(self.remaining_units())
        delivered_units = float(max(0.0, float(self.total_required_units) - rem_units))
        cur_time = float(vehicle.total_duration)
        max_cap = max(1.0, float(max(self.vehicle_capacities)))
        cur = int(vehicle.current_location)
        at_secure = 1.0 if cur in self.secure_zones else 0.0

        ok_count = 0
        early_count = 0
        late_count = 0
        for det in candidate_details[:int(CANDIDATE_TOPK)]:
            st = str(det.get("status", "none"))
            ok_count += 1 if st == "ok" else 0
            early_count += 1 if st == "early" else 0
            late_count += 1 if st == "late" else 0

        best_scalar_cost = float(candidate_details[0].get("scalar_cost", 0.0)) if candidate_details else 0.0
        wait_scalar_cost = float(self.scalarize_cost_terms(self.wait_cost_terms(vehicle, candidate_details), vehicle=vehicle))
        target_cost = float(self.target_potential(vehicle, cur, cur_time))
        if (not np.isfinite(target_cost)) or target_cost >= INVALID_COST_THRES:
            target_cost = float(INVALID_COST_THRES)

        vec = np.array([
            rem_units / max(1.0, float(self.total_required_units)),
            delivered_units / max(1.0, float(self.total_required_units)),
            float(vehicle.capacity) / max_cap,
            cur_time / max(1.0, float(ABSOLUTE_MAX_ROUTE_DURATION_MIN)),
            max(0.0, float(SERVICE_END_MIN) - cur_time) / max(1.0, float(SERVICE_END_MIN)),
            max(0.0, float(MAX_ROUTE_DURATION_MIN) - cur_time) / max(1.0, float(MAX_ROUTE_DURATION_MIN)),
            float(np.clip(self._dist_to_secure_norm(cur), 0.0, 1.0)),
            at_secure,
            1.0 if int(getattr(vehicle, "locked_target", -1)) != -1 else 0.0,
            1.0 if bool(getattr(vehicle, "hold_active", False)) else 0.0,
            float(min(1.0, float(getattr(vehicle, "no_progress_streak", 0)) / max(1.0, float(STALL_LIMIT)))),
            float(np.clip(best_scalar_cost / max(1.0, SCALAR_COST_CLIP), -1.0, 1.0)),
            float(np.clip(wait_scalar_cost / max(1.0, SCALAR_COST_CLIP), -1.0, 1.0)),
            float(ok_count) / max(1.0, float(CANDIDATE_TOPK)),
            float(early_count) / max(1.0, float(CANDIDATE_TOPK)),
            float(late_count) / max(1.0, float(CANDIDATE_TOPK)),
            float(len(self.returned_vehicle_ids)) / max(1.0, float(self.n_vehicles)),
            float(self.active_vehicle_count()) / max(1.0, float(self.n_vehicles)),
        ], dtype=np.float32)
        return vec

    def get_state_from_external(self, vehicle):
        vehicle_capacity = float(vehicle.capacity)
        self.one_hot_location = self.one_hot_encode(vehicle.current_location, self.n_locations)
        self.one_hot_demands = self.one_hot_encode_demands()
        self.one_hot_time_window = self.one_hot_encode_time_window(time_windows, vehicle.current_time_window)

        cand = self.get_candidate_details(vehicle, topk=CANDIDATE_TOPK)
        cand_rows = [self._candidate_row_from_detail(cand[i]) if i < len(cand) else np.zeros(CANDIDATE_FEATURES_PER_SLOT, dtype=np.float32)
                     for i in range(int(CANDIDATE_TOPK))]
        cand_flat = np.concatenate(cand_rows, axis=0).astype(np.float32, copy=False) if cand_rows else np.zeros(CANDIDATE_TOPK * CANDIDATE_FEATURES_PER_SLOT, dtype=np.float32)

        other_times = []
        other_caps = []
        for vv in getattr(self, "vehicles_ref", []):
            if int(vv.vehicle_id) == int(vehicle.vehicle_id):
                continue
            other_times.append(float(vv.total_duration))
            other_caps.append(float(vv.capacity))

        rem_units = float(self.remaining_units())
        cur_time = float(vehicle.total_duration)
        makespan = max([float(vv.total_duration) for vv in getattr(self, "vehicles_ref", [])] + [cur_time])
        rescue = 1.0 if self.rescue_mode(vehicle, candidate_details=cand) else 0.0

        best_scalar_cost = float(cand[0].get("scalar_cost", 0.0)) if cand else float(self.scalarize_cost_terms(self.wait_cost_terms(vehicle, cand), vehicle=vehicle))
        wait_scalar_cost = float(self.scalarize_cost_terms(self.wait_cost_terms(vehicle, cand), vehicle=vehicle))
        fleet_vec = np.array([
            float(cur_time) / max(1.0, ABSOLUTE_MAX_ROUTE_DURATION_MIN),
            max(0.0, float(SERVICE_END_MIN) - float(cur_time)) / max(1.0, SERVICE_END_MIN),
            max(0.0, float(MAX_ROUTE_DURATION_MIN) - float(cur_time)) / max(1.0, MAX_ROUTE_DURATION_MIN),
            max(0.0, float(ABSOLUTE_MAX_ROUTE_DURATION_MIN) - float(cur_time)) / max(1.0, ABSOLUTE_MAX_ROUTE_DURATION_MIN),
            float(np.min(other_times)) / max(1.0, ABSOLUTE_MAX_ROUTE_DURATION_MIN) if other_times else 0.0,
            float(np.mean(other_times)) / max(1.0, ABSOLUTE_MAX_ROUTE_DURATION_MIN) if other_times else 0.0,
            float(np.max(other_times)) / max(1.0, ABSOLUTE_MAX_ROUTE_DURATION_MIN) if other_times else 0.0,
            float(makespan) / max(1.0, ABSOLUTE_MAX_ROUTE_DURATION_MIN),
            float(np.mean(other_caps)) / max(1.0, max(self.vehicle_capacities)) if other_caps else 0.0,
            float(self.active_vehicle_count()) / max(1.0, float(self.n_vehicles)),
            float(rem_units) / max(1.0, float(self.total_required_units)),
            float(vehicle_capacity) / max(1.0, max(self.vehicle_capacities)),
            float(len(self._reservation_map())) / max(1.0, float(self.total_required_units)),
            float(rescue),
            float(best_scalar_cost) / max(1.0, SCALAR_COST_CLIP),
            float(wait_scalar_cost) / max(1.0, SCALAR_COST_CLIP),
        ], dtype=np.float32)
        hier_vec = self.hierarchical_obs_vector(vehicle, candidate_details=cand)

        return np.concatenate(
            (objective_weight_vector(np.float32), [w1], [w2], [w3], [w4], [W_TIMEWINDOW],
             self.one_hot_location,
             [vehicle_capacity],
             self.one_hot_demands,
             self.one_hot_time_window,
             cand_flat,
             fleet_vec,
             hier_vec),
            dtype=np.float32
        )

    def is_looping(self, visited):
        if len(visited) < LOOP_WINDOW:
            return False
        uniq = len(set(visited[-LOOP_WINDOW:]))
        return uniq <= LOOP_UNIQUE_MAX

    def _dist_to(self, from_node: int, to_node: int) -> float:
        arr = self.sp_cache.get(int(to_node))
        if arr is None:
            return INF
        return float(arr[int(from_node)])

    def _gap_eff(self, gap: float, status: str) -> float:
        if float(W_TIMEWINDOW) <= 0.0:
            return 0.0
        if status == "early":
            return float(W_TIMEWINDOW * EARLY_GAP_FACTOR * gap)
        if status == "late":
            return float(W_TIMEWINDOW * LATE_GAP_FACTOR * (gap + LATE_GAP_EXTRA))
        return 0.0

    def best_target_cost(self, from_node: int, cur_time_min: float) -> float:
        # Cost. Mesafe + ETA üzerinden time window gap.
        cur_tw = tw_index_from_time(cur_time_min)

        if len(self.demands) == 0:
            d_home = self._dist_to(from_node, self.depot)
            if not np.isfinite(d_home):
                return 1e6
            return float(d_home / self.d_scale)

        best = 1e18
        for d in self.demands.keys():
            dist = self._dist_to(from_node, int(d))
            if not np.isfinite(dist):
                continue
            dist_norm = dist / self.d_scale

            eta = float(cur_time_min) + estimate_travel_minutes_from_dist(dist, cur_tw)
            gap, st = time_window_gap_units(eta, self.delivery_windows_by_node.get(int(d), []))

            cost = dist_norm + BETA_TW_GAP * self._gap_eff(gap, st)
            if cost < best:
                best = cost

        if best >= 1e17:
            return 1e6
        return float(best)

    def target_potential(self, vehicle, from_node: int, cur_time_min: float) -> float:
        """
        Potansiyel fonksiyonu. Reward_distance shaping burada hesaplanır.

        Locked target varsa shaping o hedefe göre yapılır.
        Locked target yoksa veya geçersizse en iyi hedef (min cost) kullanılır.

        cost = dist_norm + beta * gap_eff( gap(ETA) )
        """
        cur_tw = tw_index_from_time(cur_time_min)

        if len(self.demands) == 0:
            d_home = self._dist_to(from_node, self.depot)
            if not np.isfinite(d_home):
                return 1e6
            return float(d_home / self.d_scale)

        if TARGET_LOCK_ACTIVE and getattr(vehicle, "locked_target", -1) != -1 and (vehicle.capacity > 0):
            lt = int(vehicle.locked_target)
            if lt in self.demands:
                dist = self._dist_to(from_node, lt)
                if np.isfinite(dist):
                    eta = float(cur_time_min) + estimate_travel_minutes_from_dist(dist, cur_tw)
                    gap, st = time_window_gap_units(eta, self.delivery_windows_by_node.get(lt, []))
                    return float((dist / self.d_scale) + BETA_TW_GAP * self._gap_eff(gap, st))
        return self.best_target_cost(from_node, cur_time_min)

    def ranked_demand_targets(self, from_node: int, cur_time_min: float, skip_late: bool = False):
        """Eski API uyumluluğu için candidate detail skorlarını döndür."""
        dummy = type("_DummyVehicle", (), {
            "vehicle_id": -1,
            "current_location": int(from_node),
            "total_duration": float(cur_time_min),
            "current_time_window": int(tw_index_from_time(float(cur_time_min))),
            "capacity": 1,
            "locked_target": -1,
            "lock_steps": 0,
            "hold_active": False,
            "hold_target": -1,
            "done_vehicle": False,
            "visited_locations": [int(from_node)],
        })()
        details = self.get_candidate_details(dummy, topk=max(int(CANDIDATE_TOPK), len(self.demands)))
        out = []
        for det in details:
            if bool(skip_late) and str(det.get("status", "")) == "late":
                continue
            out.append((float(det["score"]), int(det["node"])))
        return out

    def pick_target_for_action(self, vehicle, action_index: int):
        """Candidate slot aksiyonunu gerçek hedef node'una çevir."""
        # Lock geçersiz olduysa temizle
        if TARGET_LOCK_ACTIVE and vehicle.locked_target != -1:
            lt = int(vehicle.locked_target)
            if (lt not in self.demands) or ((not TARGET_HARD_CONSTRAINT) and vehicle.lock_steps >= int(TARGET_LOCK_MAX_STEPS)) or (vehicle.capacity <= 0):
                vehicle.locked_target = -1
                vehicle.lock_steps = 0
                vehicle.hold_active = False
                vehicle.hold_target = -1

        if vehicle.capacity <= 0 or len(self.demands) == 0:
            return self.depot

        # Lock varsa, körü körüne taşımak yerine "daha iyi açık hedef" ve reservation durumunu kontrol et.
        if TARGET_LOCK_ACTIVE and TARGET_HARD_CONSTRAINT and vehicle.locked_target != -1:
            lt = int(vehicle.locked_target)
            if (lt in self.demands) and (vehicle.capacity > 0):
                if bool(vehicle.hold_active) and int(vehicle.hold_target) != int(lt):
                    vehicle.hold_active = False
                    vehicle.hold_target = -1
                dist = self._dist_to(int(vehicle.current_location), lt)
                if np.isfinite(dist):
                    return int(lt)
            vehicle.locked_target = -1
            vehicle.lock_steps = 0
            vehicle.hold_active = False
            vehicle.hold_target = -1

        if TARGET_LOCK_ACTIVE and vehicle.locked_target != -1:
            lt = int(vehicle.locked_target)
            if (lt in self.demands) and (TARGET_HARD_CONSTRAINT or vehicle.lock_steps < int(TARGET_LOCK_MAX_STEPS)):
                dist = self._dist_to(int(vehicle.current_location), lt)
                if np.isfinite(dist):
                    details_probe = self.get_candidate_details(vehicle, topk=max(int(CANDIDATE_TOPK), 12))
                    det_map = {int(d["node"]): d for d in details_probe}
                    lock_det = det_map.get(int(lt))

                    release_lock = False
                    if lock_det is not None:
                        ok_details = [d for d in details_probe if str(d.get("status", "")) == "ok"]
                        best_ok = ok_details[0] if ok_details else None

                        if LOCK_BREAK_IF_RESERVED and float(lock_det.get("reservation_advantage", 0.0)) > 0.0:
                            release_lock = True

                        if (not release_lock) and best_ok is not None:
                            if (str(lock_det.get("status", "")) == "early") and (float(lock_det.get("minutes_to_open", 0.0)) > float(LOCK_BREAK_EARLY_OPEN_MIN)):
                                if float(best_ok.get("score", 1e9)) + float(LOCK_BREAK_OK_MARGIN) < float(lock_det.get("score", 1e9)):
                                    release_lock = True

                            if (float(lock_det.get("service_over_min", 0.0)) > float(LOCK_BREAK_SERVICE_OVER_MIN)) or (float(lock_det.get("return_over_min", 0.0)) > float(LOCK_BREAK_SERVICE_OVER_MIN)):
                                if float(best_ok.get("score", 1e9)) + float(LOCK_BREAK_OK_MARGIN) < float(lock_det.get("score", 1e9)):
                                    release_lock = True

                    if not release_lock:
                        return int(lt)

                vehicle.locked_target = -1
                vehicle.lock_steps = 0
                vehicle.hold_active = False
                vehicle.hold_target = -1

        details = self.get_candidate_details(vehicle, topk=CANDIDATE_TOPK)
        if not details:
            return self.depot

        rank = int(action_index)
        if rank >= len(details):
            rank = 0
        target = int(details[rank]["node"])

        if TARGET_LOCK_ACTIVE:
            prev = int(vehicle.locked_target) if vehicle.locked_target != -1 else -1
            if prev != -1 and prev != target:
                vehicle.target_switches += 1
                vehicle.switch_penalty_due += float(TARGET_SWITCH_PENALTY)
            vehicle.locked_target = int(target)
            vehicle.lock_steps = 0
            vehicle.hold_active = False
            vehicle.hold_target = -1

        return int(target)

    def action_mask(self, vehicle) -> np.ndarray:
        """Candidate slot maskesi.
        Rev3: Early hedefleri sert kapatmak yerine çoğunlukla score ile cezalandır.
        Sadece çok erken + secure wait açıkça daha iyi ise mask uygula.
        """
        mask = np.zeros(int(MAX_ACTIONS), dtype=np.bool_)
        vehicle.mask_calls += 1
        details = self.get_candidate_details(vehicle, topk=CANDIDATE_TOPK)
        rescue = self.rescue_mode(vehicle, candidate_details=details)
        ok_exists = any(str(d.get("status", "")) == "ok" for d in details)
        dist_secure_norm = self._dist_to_secure_norm(int(vehicle.current_location))
        at_secure = bool(int(vehicle.current_location) in self.secure_zones)

        # REV14 hard action gate: one canonical move action follows the committed target.
        # Secure wait remains legal only while that target is early.
        if TARGET_LOCK_ACTIVE and TARGET_HARD_CONSTRAINT and getattr(vehicle, "locked_target", -1) != -1:
            lt = int(vehicle.locked_target)
            if (lt in self.demands) and (vehicle.capacity > 0):
                dist_lt = self._dist_to(int(vehicle.current_location), lt)
                if np.isfinite(dist_lt):
                    eta_lt = float(vehicle.total_duration) + estimate_travel_minutes_from_dist(dist_lt, int(vehicle.current_time_window))
                    _gap_lt, status_lt = time_window_gap_units(eta_lt, self.delivery_windows_by_node.get(lt, []))
                    mask[0] = True
                    mask[int(A_SECURE_WAIT)] = bool(str(status_lt) == "early")
                    return mask

        wait_scalar = float(self.scalarize_cost_terms(self.wait_cost_terms(vehicle, details), vehicle=vehicle))

        for i in range(min(int(CANDIDATE_TOPK), len(details))):
            det = details[i]
            st = str(det.get("status", "none"))
            allow = True

            if EARLY_MASK_IN_NORMAL_MODE and (not rescue) and st == "early":
                open_min = float(det.get("minutes_to_open", 0.0))
                cand_scalar = float(det.get("scalar_cost", det.get("score", 1e9)))
                should_mask = False
                if open_min > float(EARLY_MASK_OPEN_MIN_STRICT):
                    should_mask = True
                if EARLY_MASK_ONLY_IF_WAIT_BETTER:
                    if (wait_scalar + 0.10) < cand_scalar and open_min > 10.0:
                        should_mask = True
                    if (not at_secure) and (dist_secure_norm > 0.55):
                        should_mask = False
                if should_mask:
                    allow = False
                    vehicle.mask_early += 1

            if LATE_MASK_WHEN_OK_EXISTS and ok_exists and st == "late":
                allow = False
                vehicle.mask_late += 1

            mask[i] = bool(allow)

        mask[int(A_SECURE_WAIT)] = True

        # On-time demand is available: waiting is invalid unless this vehicle
        # is deliberately holding for a locked target.
        if (
            REV5_COMPLETION_GUARDS
            and REV5_MASK_WAIT_WHEN_OK_EXISTS
            and ok_exists
            and (not bool(getattr(vehicle, "hold_active", False)))
            and np.any(mask[:int(CANDIDATE_TOPK)])
        ):
            mask[int(A_SECURE_WAIT)] = False

        if not np.any(mask[:-1]) and len(details) > 0:
            vehicle.mask_all_blocked += 1
            vehicle.no_feasible_steps += 1
            reopen_idx = int(np.argmin(np.asarray([float(d.get("scalar_cost", d.get("score", 1e9))) for d in details], dtype=np.float64)))
            mask[reopen_idx] = True

        return mask

    def action_score_bias(self, vehicle) -> np.ndarray:
        """Q değerlerine eklenecek heuristic bias.
        Rev5: bias doğrudan scalarized candidate cost'tan türetilir; ağ residual düzeltme öğrenir.
        """
        details = self.get_candidate_details(vehicle, topk=CANDIDATE_TOPK)
        rescue = self.rescue_mode(vehicle, candidate_details=details)
        ok_exists = any(str(d.get("status", "")) == "ok" for d in details)
        early_exists = any(str(d.get("status", "")) == "early" for d in details)
        deliver_now_exists = any(bool(d.get("deliver_now", 0.0) > 0.5) for d in details)
        deliver_rescue_exists = any(bool(d.get("deliver_rescue", 0.0) > 0.5) for d in details)
        finish_mode = int(self.remaining_units()) <= int(FINISH_BIAS_REMAINING_UNITS)

        bias = np.full(int(MAX_ACTIONS), -0.20, dtype=np.float32)
        for i in range(min(int(CANDIDATE_TOPK), len(details))):
            det = details[i]
            st = str(det.get("status", "none"))
            scalar_cost = float(det.get("scalar_cost", det.get("score", 0.0)))
            score = -float(scalar_cost)
            if bool(det.get("deliver_now", 0.0) > 0.5):
                score += float(ACTION_SCORE_DELIVER_NOW_BONUS)
                score += 0.10 * float(det.get("minutes_to_close", 0.0)) / max(1.0, WINDOW_SIZE_MIN)
            elif bool(det.get("deliver_rescue", 0.0) > 0.5):
                score += float(ACTION_SCORE_DELIVER_RESCUE_BONUS)
            elif st == "late" and rescue:
                score += 0.08
            elif st == "early" and (not rescue):
                score -= 0.08
            if float(det.get("lock_bonus", 0.0)) > 0.0:
                score += 0.12
            if finish_mode:
                if bool(det.get("deliver_now", 0.0) > 0.5):
                    score += float(FINISH_DELIVER_NOW_EXTRA)
                elif bool(det.get("deliver_rescue", 0.0) > 0.5):
                    score += float(FINISH_DELIVER_RESCUE_EXTRA)
                elif st == "early":
                    score -= 0.10
            bias[i] = float(score)

        wait_scalar = float(self.scalarize_cost_terms(self.wait_cost_terms(vehicle, details), vehicle=vehicle))
        wait_score = -float(wait_scalar)
        if len(details) == 0:
            wait_score += 0.25
        elif deliver_now_exists:
            wait_score -= float(ACTION_SCORE_WAIT_WHEN_DELIVERABLE_PENALTY)
        elif deliver_rescue_exists:
            wait_score -= float(ACTION_SCORE_WAIT_WHEN_RESCUEABLE_PENALTY)
        elif ok_exists:
            wait_score -= 0.15
        elif early_exists and (not rescue):
            wait_score += 0.12
        if finish_mode:
            if deliver_now_exists:
                wait_score -= float(FINISH_WAIT_EXTRA)
            elif deliver_rescue_exists:
                wait_score -= 0.55 * float(FINISH_WAIT_EXTRA)
        bias[int(A_SECURE_WAIT)] = float(wait_score)
        return bias

    def next_hop_towards(self, cur: int, dist_to_target: np.ndarray):
        """Choose a deterministic strictly-descending shortest-path hop."""
        if dist_to_target is None:
            return None
        cur = int(cur)
        cur_dist = float(dist_to_target[cur])
        if not np.isfinite(cur_dist):
            return None
        neigh = self.nav_neigh[cur]
        if neigh.size == 0:
            return None

        best_v = None
        best_val = float("inf")
        descent_tol = max(1e-9, 1e-10 * max(1.0, abs(cur_dist)))
        for v in neigh:
            vv = int(v)
            dv = float(dist_to_target[vv])
            if not np.isfinite(dv):
                continue
            w = float(self.dst[cur, vv])
            if w <= 0.0:
                continue
            if STRICT_DESCENT_NAV_ACTIVE and not (dv < cur_dist - descent_tol):
                continue
            val = w + dv
            if (val < best_val - 1e-9) or (abs(val - best_val) <= 1e-9 and (best_v is None or vv < best_v)):
                best_val = val
                best_v = vv
        return int(best_v) if best_v is not None else None

    def _default_wait_chunk(self, cur_time_min: float, cur_tw: int) -> float:
        """Secure zone'da bekleme için varsayılan chunk.

        Varsayılan strateji. Bir sonraki time window sınırına kadar bekle.
        """
        cur_time = float(cur_time_min)
        tw = int(cur_tw)
        if (tw + 1) < len(time_windows):
            boundary = float(time_windows[tw + 1])
            return float(np.clip(boundary - cur_time, float(SECURE_WAIT_MIN), float(WAIT_CHUNK_MAX)))
        return float(SECURE_WAIT_MIN)


    def step(self, vehicle, action_index: int):
        done = False
        vehicle.done_vehicle = False

        reward_location = 0.0
        reward_duration = 0.0
        reward_fuel = 0.0
        reward_unsecure = 0.0
        reward_distance = 0.0
        reward_timewindow = 0.0
        extra_penalty = 0.0
        reward_hierarchy = 0.0

        cur = int(vehicle.current_location)
        vehicle.total_steps += 1
        rem_units_before = int(self.remaining_units())
        dist_secure_before = float(self._dist_to_secure_norm(cur))
        fleet_makespan_before = max([float(v.total_duration) for v in getattr(self, "vehicles_ref", [])] + [float(vehicle.total_duration)])
        delivery_status = "none"
        delivery_gap_units = 0.0
        solved_just_now = False
        returned_after_solve_now = False
        all_returned_done_now = False

        # Loop metrikleri
        history = vehicle.visited_locations
        prev_prev = history[-2] if len(history) >= 2 else None

        # Hedef maliyet (move öncesi)
        pot_prev = self.target_potential(vehicle, cur, float(vehicle.total_duration))

        # Target switch penalty, bir adım için uygulanır
        if getattr(vehicle, "switch_penalty_due", 0.0) != 0.0:
            extra_penalty += float(vehicle.switch_penalty_due)
            vehicle.switch_penalty_due = 0.0

        # Lock süresi dolduysa temizle
        if TARGET_LOCK_ACTIVE and (not TARGET_HARD_CONSTRAINT) and vehicle.locked_target != -1 and vehicle.lock_steps >= int(TARGET_LOCK_MAX_STEPS):
            vehicle.locked_target = -1
            vehicle.lock_steps = 0
            vehicle.hold_active = False
            vehicle.hold_target = -1

        # Action decode
        is_wait = False
        next_node = None
        wait_time_min = float(SECURE_WAIT_MIN)
        cur_time = float(vehicle.total_duration)
        cur_tw = int(vehicle.current_time_window)
        planned_target = None

        # Service end sonrası policy.
        # Rev2'de servis kapanışı hard-stop değil; rescue modda kontrollü yumuşak ihlal yapılabilir.
        service_closed = bool(float(cur_time) > float(SERVICE_END_MIN) + 1e-9)
        rescue_mode_now = bool(self.rescue_mode(vehicle))

        if service_closed and (not getattr(vehicle, "service_end_triggered", False)):
            vehicle.service_end_triggered = True
            rem_units_now = int(self.remaining_units())
            if rem_units_now > 0:
                extra_penalty += float(SERVICE_END_BASE_PENALTY)
                extra_penalty += float(REMAINING_UNIT_PENALTY_SERVICE_END) * float(LAMBDA_UNDELIVERED) * (float(rem_units_now) / max(1.0, float(self.n_vehicles)))

        forced_return_mode = False
        if service_closed:
            vehicle.service_closed_steps += 1
            if (len(self.demands) == 0) or (vehicle.capacity <= 0):
                forced_return_mode = True

        if forced_return_mode:
            planned_target = int(self.depot)

            if int(cur) == int(self.depot):
                is_wait = True
                next_node = int(cur)
                wait_time_min = 0.0
                vehicle.done_vehicle = True
            else:
                is_wait = False
                dist_to_target = self.sp_cache.get(int(planned_target))
                next_node = self.next_hop_towards(cur, dist_to_target)
                if next_node is None:
                    is_wait = True
                    next_node = int(cur)
                    wait_time_min = float(SECURE_WAIT_MIN)
                    extra_penalty += float(UNREACHABLE_PENALTY)
                    vehicle.unreachable_steps += 1
                else:
                    vehicle.forced_return_steps += 1

        elif int(action_index) == int(A_SECURE_WAIT):
            # Secure wait action.
            # Semantik.
            # - Secure zone'da ise bekle.
            # - Secure zone'da değilse en yakın secure zone'a git.
            # - Eğer locked target yoksa en iyi feasible hedefi seçip lock et. (macro)

            candidate = None
            if vehicle.capacity > 0 and len(self.demands) > 0:
                # Mevcut lock'u doğrula.
                if TARGET_LOCK_ACTIVE and vehicle.locked_target != -1:
                    lt = int(vehicle.locked_target)
                    if (lt in self.demands) and (TARGET_HARD_CONSTRAINT or vehicle.lock_steps < int(TARGET_LOCK_MAX_STEPS)):
                        dist_lt = self._dist_to(cur, lt)
                        if np.isfinite(dist_lt):
                            candidate = int(lt)
                    if candidate is None:
                        vehicle.locked_target = -1
                        vehicle.lock_steps = 0
                        vehicle.hold_active = False
                        vehicle.hold_target = -1

                if candidate is None:
                    ranked = self.ranked_demand_targets(cur, cur_time, skip_late=bool(SKIP_LATE_DEMANDS_IN_RANKING))
                    if ranked:
                        candidate = int(ranked[0][1])
                        # İlk kez lock ediyorsak switch cezası verme.
                        if TARGET_LOCK_ACTIVE and vehicle.locked_target == -1:
                            vehicle.locked_target = int(candidate)
                            vehicle.lock_steps = 0
                            vehicle.hold_active = False
                            vehicle.hold_target = -1

                # Candidate'a göre hold flag ayarla. (early ise secure'da bekleyeceğiz)
                if candidate is not None:
                    dist_c = self._dist_to(cur, int(candidate))
                    if np.isfinite(dist_c):
                        eta_c = float(cur_time) + estimate_travel_minutes_from_dist(dist_c, int(cur_tw))
                        _g, st_c = time_window_gap_units(eta_c, self.delivery_windows_by_node.get(int(candidate), []))
                        if st_c == "early":
                            vehicle.hold_active = True
                            vehicle.hold_target = int(candidate)
                        else:
                            # ok veya late ise hold gerekmez. Hold'u temizle ki agent gereksiz beklemeyi sömürmesin.
                            vehicle.hold_active = False
                            vehicle.hold_target = -1

            if cur in self.secure_zones:
                is_wait = True
                next_node = int(cur)
                vehicle.secure_wait_steps += 1

                # Hold aktif ise hedefe göre bekle. Değilse time window boundary bekle.
                ht = int(vehicle.hold_target) if bool(vehicle.hold_active) else -1
                if ht != -1 and (ht in self.demands) and (vehicle.capacity > 0):
                    dist_ht = self._dist_to(int(cur), int(ht))
                    if np.isfinite(dist_ht):
                        eta_ht = float(cur_time) + estimate_travel_minutes_from_dist(dist_ht, int(cur_tw))
                        allowed = self.delivery_windows_by_node.get(int(ht), [])
                        _gap, st = time_window_gap_units(eta_ht, allowed)
                        if st == "early":
                            start_min = next_allowed_start_time(eta_ht, allowed)
                            if start_min is not None:
                                wait_delay = max(0.0, float(start_min) - float(eta_ht) + float(ARRIVAL_MARGIN_MIN))
                                wait_time_min = float(np.clip(wait_delay, float(SECURE_WAIT_MIN), float(WAIT_CHUNK_MAX)))
                            else:
                                wait_time_min = float(SECURE_WAIT_MIN)
                        else:
                            # Hold artık gerekli değil. (ok veya late)
                            vehicle.hold_active = False
                            vehicle.hold_target = -1
                            wait_time_min = float(self._default_wait_chunk(cur_time, cur_tw))
                    else:
                        wait_time_min = float(self._default_wait_chunk(cur_time, cur_tw))
                else:
                    wait_time_min = float(self._default_wait_chunk(cur_time, cur_tw))

                # Hold yokken feasible (ok) hedef varken secure'da beklemeyi cezalandır.
                # Aksi halde policy "hep bekle"yi öğrenip testte çöker.
                if (not bool(vehicle.hold_active)) and (vehicle.capacity > 0) and (len(self.demands) > 0):
                    ranked_ok = self.ranked_demand_targets(int(cur), float(cur_time), skip_late=bool(SKIP_LATE_DEMANDS_IN_RANKING))
                    ok_exists = False
                    for _sc, nn in ranked_ok[:int(WAIT_WHEN_OK_TARGET_MAXCHECK)]:
                        nn = int(nn)
                        dist_nn = self._dist_to(int(cur), nn)
                        if np.isfinite(dist_nn):
                            eta_nn = float(cur_time) + estimate_travel_minutes_from_dist(dist_nn, int(cur_tw))
                            _g2, st2 = time_window_gap_units(eta_nn, self.delivery_windows_by_node.get(int(nn), []))
                            if st2 == "ok":
                                ok_exists = True
                                break
                    if ok_exists:
                        extra_penalty += float(WAIT_WHEN_OK_TARGET_PENALTY)

            else:
                vehicle.secure_travel_steps += 1
                next_node = self.next_hop_towards(int(cur), self.dist_to_secure)
        else:
            # Demand targeting action
            planned_target = int(self.pick_target_for_action(vehicle, int(action_index)))

            # Depot'tayız ve hedef depot ise. WAIT
            if int(planned_target) == int(self.depot) and int(cur) == int(self.depot):
                is_wait = True
                next_node = int(cur)
                vehicle.secure_wait_steps += 1
                wait_time_min = float(self._default_wait_chunk(cur_time, cur_tw))
            else:
                maintain_hold_route = bool(
                    HOLD_ROUTE_HYSTERESIS_ACTIVE
                    and bool(vehicle.hold_active)
                    and int(vehicle.hold_target) == int(planned_target)
                    and int(cur) not in self.secure_zones
                )
                if maintain_hold_route:
                    # Once an early-target redirect starts, reach a secure zone
                    # before reconsidering target ETA. This prevents A<->B
                    # oscillation between the target and secure potentials.
                    vehicle.secure_travel_steps += 1
                    next_node = self.next_hop_towards(int(cur), self.dist_to_secure)
                else:
                    # Pre-check. Full path ETA ile erken ise secure'a kır ve pencerede bekle
                    if (planned_target in self.demands) and (vehicle.capacity > 0):
                        dist_total = self._dist_to(int(cur), int(planned_target))
                        if not np.isfinite(dist_total):
                            vehicle.unreachable_steps += 1
                            vehicle.done_vehicle = True
                            next_state = self.get_state_from_external(vehicle)
                            return next_state, float(UNREACHABLE_PENALTY), bool(done), bool(vehicle.done_vehicle)
    
                        eta_total = float(cur_time) + estimate_travel_minutes_from_dist(dist_total, int(cur_tw))
                        allowed = self.delivery_windows_by_node.get(int(planned_target), [])
                        _gap_total, st_total = time_window_gap_units(eta_total, allowed)
    
                        if EARLY_FORCE_WAIT and st_total == "early" and (not self.allow_early_delivery(vehicle, int(planned_target), float(eta_total))):
                            hold_just_started = (not bool(vehicle.hold_active)) or (int(vehicle.hold_target) != int(planned_target))
                            vehicle.hold_active = True
                            vehicle.hold_target = int(planned_target)
                            if hold_just_started:
                                vehicle.early_redirects += 1
                                extra_penalty += float(EARLY_REDIRECT_PENALTY)
    
                            if int(cur) in self.secure_zones:
                                is_wait = True
                                next_node = int(cur)
                                vehicle.secure_wait_steps += 1
    
                                start_min = next_allowed_start_time(eta_total, allowed)
                                if start_min is not None:
                                    wait_delay = max(0.0, float(start_min) - float(eta_total) + float(ARRIVAL_MARGIN_MIN))
                                    wait_time_min = float(np.clip(wait_delay, float(SECURE_WAIT_MIN), float(WAIT_CHUNK_MAX)))
                                else:
                                    wait_time_min = float(SECURE_WAIT_MIN)
                            else:
                                vehicle.secure_travel_steps += 1
                                next_node = self.next_hop_towards(int(cur), self.dist_to_secure)
                        else:
                            if bool(vehicle.hold_active) and int(vehicle.hold_target) == int(planned_target):
                                vehicle.hold_active = False
                                vehicle.hold_target = -1
    
                            dist_to_target = self.sp_cache.get(int(planned_target))
                            if dist_to_target is None:
                                dist_to_target = self.sp_cache.get(int(self.depot))
                            next_node = self.next_hop_towards(int(cur), dist_to_target)
                    else:
                        dist_to_target = self.sp_cache.get(int(planned_target))
                        if dist_to_target is None:
                            dist_to_target = self.sp_cache.get(int(self.depot))
                        next_node = self.next_hop_towards(int(cur), dist_to_target)
    
        if next_node is None:
            # Graph dead-end. Bu instance veya NAV graph tanımı problemli.
            vehicle.unreachable_steps += 1
            vehicle.done_vehicle = True
            next_state = self.get_state_from_external(vehicle)
            return next_state, float(UNREACHABLE_PENALTY), bool(done), bool(vehicle.done_vehicle)

        next_node = int(next_node)

        # Final gate applies only to the committed delivery target in hard mode.
        # Demand nodes crossed en route are transit nodes; they must not replace
        # hold_target or trigger an opportunistic delivery.
        hard_delivery_target_ok = bool(
            (not (TARGET_LOCK_ACTIVE and TARGET_HARD_CONSTRAINT))
            or (int(getattr(vehicle, "locked_target", -1)) != -1 and int(next_node) == int(vehicle.locked_target))
        )
        if (not is_wait) and hard_delivery_target_ok and (next_node in self.demands) and (vehicle.capacity > 0) and (float(vehicle.total_duration) <= float(SERVICE_END_MIN) + 1e-9):
            allowed = self.delivery_windows_by_node.get(int(next_node), [])
            if allowed is not None and len(allowed) > 0:
                dist_edge = float(self.dst[int(cur), int(next_node)])
                if dist_edge > 0.0:
                    base_v = float(self.velocity[int(vehicle.current_time_window), int(cur), int(next_node)])
                    v_est = max(5.0, base_v)
                    travel_min_est = float(dist_edge / (v_est * 1000.0 / 60.0))
                    eta_est = float(vehicle.total_duration) + float(travel_min_est)

                    _gap, _st = time_window_gap_units(eta_est, allowed)
                    if EARLY_FORCE_WAIT and _st == "early" and (not self.allow_early_delivery(vehicle, int(next_node), float(eta_est))):
                        hold_just_started = (not bool(vehicle.hold_active)) or (int(vehicle.hold_target) != int(next_node))
                        vehicle.hold_active = True
                        vehicle.hold_target = int(next_node)
                        if hold_just_started:
                            vehicle.early_redirects += 1
                            extra_penalty += float(EARLY_REDIRECT_PENALTY)

                        # Demand'a girmeyi iptal et. Secure zone'a git ve bekle.
                        if int(cur) in self.secure_zones:
                            is_wait = True
                            next_node = int(cur)
                            vehicle.secure_wait_steps += 1

                            start_min = next_allowed_start_time(eta_est, allowed)
                            if start_min is not None:
                                wait_delay = max(0.0, float(start_min) - float(eta_est) + float(ARRIVAL_MARGIN_MIN))
                                wait_time_min = float(np.clip(wait_delay, float(SECURE_WAIT_MIN), float(WAIT_CHUNK_MAX)))
                            else:
                                wait_time_min = float(SECURE_WAIT_MIN)
                        else:
                            vehicle.secure_travel_steps += 1
                            next_node = self.next_hop_towards(int(cur), self.dist_to_secure)

        # Backtrack ve revisit tespiti

        will_backtrack = (prev_prev is not None and (not is_wait) and next_node == int(prev_prev))
        recent_slice = history[-RECENT_WINDOW:] if len(history) >= RECENT_WINDOW else history
        recent_revisit = ((not is_wait) and (next_node in recent_slice))

        # Apply move or wait
        if is_wait:
            distance_traveled = 0.0
            consumed_fuel = 0.0
            reward_fuel = 0.0
            reward_unsecure = 0.0

            vehicle.total_duration += float(wait_time_min)
            reward_duration = -float(wait_time_min)

            # visited time updates
            vehicle.visited_locations.append(int(cur))
        else:
            distance_traveled = float(self.dst[cur, next_node])
            if distance_traveled <= 0:
                vehicle.unreachable_steps += 1
                vehicle.done_vehicle = True
                next_state = self.get_state_from_external(vehicle)
                return next_state, float(UNREACHABLE_PENALTY), bool(done), bool(vehicle.done_vehicle)

            vehicle.total_distance += distance_traveled
            vehicle.visited_locations.append(int(next_node))

            noise = np.random.normal(loc=0.0, scale=float(self.velocity_noise[cur, next_node]))
            base_v = float(self.velocity[int(vehicle.current_time_window), cur, next_node])
            instant_velocity = max(5.0, base_v + noise)

            consumed_fuel = (distance_traveled * 1e-3) / max(1e-6, self.fuel_efficiency(instant_velocity))
            vehicle.total_fuel += float(consumed_fuel)
            reward_fuel = -float(consumed_fuel)

            reward_unsecure = -float(security_risc[cur, next_node])

            node_to_node_duration = distance_traveled / (instant_velocity * 1000.0 / 60.0)
            reward_duration = -float(node_to_node_duration)
            vehicle.total_duration += float(node_to_node_duration)

            # Secure zone service time
            if (next_node in self.secure_zones) and (int(next_node) != int(self.depot)):
                vehicle.total_duration += float(secure_time)

            vehicle.current_location = int(next_node)


        # Overtime update. 20:00 sonrası geçen süreyi takip et ve opsiyonel ceza uygula.
        t_before = float(cur_time)
        t_after = float(vehicle.total_duration)
        prev_over = max(0.0, t_before - float(SERVICE_END_MIN))
        new_over = max(0.0, t_after - float(SERVICE_END_MIN))
        overtime_inc = max(0.0, new_over - prev_over)
        if overtime_inc > 0.0:
            vehicle.overtime_minutes += float(overtime_inc)
            # REV13: represented only in unified normalized soft objective.

        prev_return_over = max(0.0, t_before - float(MAX_ROUTE_DURATION_MIN))
        new_return_over = max(0.0, t_after - float(MAX_ROUTE_DURATION_MIN))
        return_over_inc = max(0.0, new_return_over - prev_return_over)
        if return_over_inc > 0.0:
            vehicle.return_extension_minutes += float(return_over_inc)
            # REV13: represented only in unified normalized soft objective.

        # Time window update
        for i in range(len(time_windows)):
            if vehicle.total_duration > time_windows[i]:
                vehicle.current_time_window = int(i)
            else:
                break

        vehicle.visited_time.append(float(vehicle.total_duration))
        vehicle.visited_time_window.append(int(vehicle.current_time_window))

        # Delivery logic. Waiting does not deliver.
        delivered_now = False
        if (not is_wait) and hard_delivery_target_ok and (next_node in self.demands) and (vehicle.capacity > 0) and (float(vehicle.total_duration) <= float(ABSOLUTE_MAX_ROUTE_DURATION_MIN) + 1e-9):
            allowed = self.delivery_windows_by_node.get(int(next_node), [])
            gap, st = time_window_gap_units(float(vehicle.total_duration), allowed)
            delivery_gap_units = float(max(0.0, gap))

            if allowed and (st != "ok") and (st != "none") and (float(W_TIMEWINDOW) > 0.0):
                factor = EARLY_MISS_FACTOR if st == "early" else (LATE_MISS_FACTOR if st == "late" else 1.0)
                tw_obj = float(LAMBDA_EARLY) if st == "early" else (float(LAMBDA_LATE) if st == "late" else 1.0)
                reward_timewindow += -float(TIMEWINDOW_MISS_PENALTY) * float(tw_obj) * float(factor) * float(1.0 + gap)
                vehicle.tw_misses += 1
                if st == "early":
                    vehicle.tw_misses_early += 1
                elif st == "late":
                    vehicle.tw_misses_late += 1

            can_deliver = True
            if allowed and (st == "early") and (not self.allow_early_delivery(vehicle, int(next_node), float(vehicle.total_duration))):
                can_deliver = False
            if (not ALLOW_LATE_DELIVERY_AFTER_SERVICE_END) and (float(vehicle.total_duration) > float(SERVICE_END_MIN) + 1e-9):
                can_deliver = False

            if can_deliver:
                vehicle.capacity -= 1
                self.demands[next_node] -= 1
                delivery_status = str(st)

                # Hard progress reward is preference invariant. TW quality is
                # represented only by the unified normalized soft objective.
                delivery_gain = float(DELIVERY_BASE_REWARD + DELIVERY_ONTIME_BONUS)

                reward_location += float(delivery_gain)
                delivered_now = True
                vehicle.deliveries_made += 1
                if self.demands[next_node] <= 0:
                    del self.demands[next_node]

        # Target lock maintenance ve hold temizliği
        if TARGET_LOCK_ACTIVE:
            if vehicle.locked_target != -1:
                lt = int(vehicle.locked_target)
                # Demand bitti veya kapasite bitti ise kilidi bırak
                if (lt not in self.demands) or (vehicle.capacity <= 0):
                    vehicle.locked_target = -1
                    vehicle.lock_steps = 0
                    vehicle.hold_active = False
                    vehicle.hold_target = -1
                else:
                    vehicle.lock_steps += 1
            else:
                vehicle.lock_steps = 0

        if bool(vehicle.hold_active) and (int(vehicle.hold_target) not in self.demands):
            vehicle.hold_active = False
            vehicle.hold_target = -1

        # Cost after
        cur2 = int(vehicle.current_location)
        pot_next = self.target_potential(vehicle, cur2, float(vehicle.total_duration))
        if (pot_prev >= INVALID_COST_THRES) or (pot_next >= INVALID_COST_THRES) or (not np.isfinite(pot_prev)) or (not np.isfinite(pot_next)):
            reward_distance = 0.0
            extra_penalty += float(UNREACHABLE_PENALTY)
            vehicle.unreachable_steps += 1
        else:
            reward_distance = float(np.clip(pot_prev - pot_next, -REWARD_DISTANCE_CLIP, REWARD_DISTANCE_CLIP))

        # Loop penalties, skip for wait
        if will_backtrack:
            # REV13: represented only in unified normalized soft objective.
            vehicle.backtracks += 1

        if recent_revisit and (next_node not in self.secure_zones):
            # REV13: represented only in unified normalized soft objective.
            vehicle.revisits += 1

        # Loop tespiti. Secure wait sırasında loop cezası uygulama.
        if (not is_wait) and self.is_looping(vehicle.visited_locations):
            # REV13: represented only in unified normalized soft objective.
            vehicle.loop_penalty_steps += 1

        tol = 1e-6
        planned_wait = bool(is_wait) and ((int(cur) in self.secure_zones) or (int(cur) == int(self.depot))) and bool(vehicle.hold_active)
        if (not delivered_now) and (reward_distance <= tol) and (not planned_wait):
            # REV13: represented only in unified normalized soft objective.
            vehicle.no_progress_streak += 1
        else:
            vehicle.no_progress_streak = 0

        # steps since delivery for shield trigger only
        if delivered_now:
            vehicle.steps_since_delivery = 0
        else:
            vehicle.steps_since_delivery += 1

        # Progress based stall termination
        if vehicle.no_progress_streak >= int(STALL_LIMIT):
            extra_penalty += float(STALL_PENALTY)
            # Kalan demand cezası. Episode sonu basıncı için.
            rem_units_now = int(sum(self.demands.values()))
            if rem_units_now > 0:
                extra_penalty += float(REMAINING_UNIT_PENALTY_STALL) * float(LAMBDA_UNDELIVERED) * (float(rem_units_now) / float(max(1, self.n_vehicles)))
            vehicle.done_vehicle = True
            vehicle.stall_terminations += 1


        # Hard end of day termination
        if vehicle.total_duration >= float(ABSOLUTE_MAX_ROUTE_DURATION_MIN):
            extra_penalty += float(END_OF_DAY_PENALTY)
            rem_units_now = int(sum(self.demands.values()))
            if rem_units_now > 0:
                extra_penalty += float(REMAINING_UNIT_PENALTY_EOD) * float(LAMBDA_UNDELIVERED) * (float(rem_units_now) / float(max(1, self.n_vehicles)))
                if vehicle.capacity > 0:
                    extra_penalty += float(EOD_UNUSED_CAPACITY_PENALTY_PER_UNIT) * float(vehicle.capacity)
            if (len(self.demands) == 0) and (int(vehicle.current_location) != int(self.depot)):
                extra_penalty += float(NOT_RETURNED_EOD_PENALTY)
            vehicle.done_vehicle = True
            vehicle.end_of_day_terminations += 1

        # Tamamlanma ve depoya dönüş mantığı.
        if (len(self.demands) == 0) and (not getattr(self, "all_delivered", False)):
            self.all_delivered = True
            solved_just_now = True
            reward_location += float(SOLVED_BONUS)

            # Tamamlandığında. bu aracın lock ve hold bilgisini temizle.
            if TARGET_LOCK_ACTIVE:
                vehicle.locked_target = -1
                vehicle.lock_steps = 0
                vehicle.hold_active = False
                vehicle.hold_target = -1

        # Depoya dönüş.
        if int(vehicle.current_location) == int(self.depot):
            if getattr(self, "all_delivered", False):
                # Talep bitti. kapasite kalsa bile depo ile episode'a katkı bitti sayılır.
                if int(vehicle.vehicle_id) not in self.returned_vehicle_ids:
                    self.returned_vehicle_ids.add(int(vehicle.vehicle_id))
                    returned_after_solve_now = True
                    reward_location += float(RETURN_AFTER_SOLVE_BONUS)
                vehicle.done_vehicle = True
            else:
                # Talep bitmediyse sadece kapasitesi biten araç depoda kapanır.
                if vehicle.capacity == 0:
                    if int(vehicle.vehicle_id) not in self.returned_vehicle_ids:
                        self.returned_vehicle_ids.add(int(vehicle.vehicle_id))
                    vehicle.done_vehicle = True
                    reward_location += float(RETURN_HOME_BONUS)

        # Talep bittikten sonra depot dışında oyalanma cezası.
        if getattr(self, "all_delivered", False) and (int(vehicle.current_location) != int(self.depot)):
            if float(POST_SOLVE_STEP_PENALTY) != 0.0:
                extra_penalty += float(POST_SOLVE_STEP_PENALTY)

        # Global done. Tüm talepler teslim ve tüm araçlar depoya döndü.
        if getattr(self, "all_delivered", False) and (len(self.returned_vehicle_ids) >= int(self.n_vehicles)):
            done = True
            all_returned_done_now = True
            reward_location += float(ALL_VEHICLES_RETURN_BONUS)

        # Hierarchical CIT shaping.
        # R1-R10: solve > upper subgoals > lower subgoals; unsupported actions get no reward.
        # M1-M2: every term below is tied to this step's state/action/effect, and the
        # related observations are appended in hierarchical_obs_vector().
        if HIER_CIT_ACTIVE:
            hier_scale = curriculum_reward_scales(
                str(getattr(self, "curriculum_phase", "optimization"))
            )
            rem_units_after = int(self.remaining_units())
            duration_inc = max(0.0, float(vehicle.total_duration) - float(cur_time))
            distance_km = float(distance_traveled) / 1000.0
            progress_delta = max(0.0, float(reward_distance))
            supported_action = bool(delivered_now or progress_delta > 1e-6 or returned_after_solve_now or solved_just_now)

            # REV13: represented only in unified normalized soft objective.
            # REV13: represented only in unified normalized soft objective.
            # REV13: represented only in unified normalized soft objective.

            if rem_units_after < rem_units_before:
                reward_hierarchy += float(hier_scale["delivery"]) * float(HIER_REMAINING_REDUCTION_REWARD) * float(rem_units_before - rem_units_after)
                supported_action = True

            if delivered_now:
                reward_hierarchy += float(hier_scale["delivery"]) * float(HIER_DELIVERY_SUBGOAL_REWARD)
                if str(delivery_status) == "ok" and float(vehicle.total_duration) <= float(SERVICE_END_MIN) + 1e-9:
                    pass  # REV13 unified J_soft
                supported_action = True

            if progress_delta > 1e-6:
                reward_hierarchy += float(HIER_TARGET_PROGRESS_GAIN) * float(1.0 - np.exp(-progress_delta))
                supported_action = True

            if bool(is_wait) and (int(cur) in self.secure_zones) and bool(getattr(vehicle, "hold_active", False)):
                pass  # REV13 unified J_soft
                supported_action = True
            elif (not bool(is_wait)) and (next_node in self.secure_zones):
                dist_secure_after = float(self._dist_to_secure_norm(int(next_node)))
                if dist_secure_after + 1e-9 < dist_secure_before:
                    pass  # REV13 unified J_soft
                    supported_action = True

            if solved_just_now:
                time_eff = max(0.0, 1.0 - float(vehicle.total_duration) / max(1.0, float(ABSOLUTE_MAX_ROUTE_DURATION_MIN)))
                reward_hierarchy += float(hier_scale["solve"]) * float(HIER_SOLVED_REWARD) * float(1.0 + 0.25 * time_eff)
                supported_action = True

            if returned_after_solve_now:
                reward_hierarchy += float(hier_scale["return"]) * float(HIER_RETURN_AFTER_SOLVE_REWARD)
                supported_action = True

            if all_returned_done_now:
                reward_hierarchy += float(hier_scale["return"]) * float(HIER_ALL_RETURNED_REWARD)
                supported_action = True

            if str(delivery_status) == "late":
                pass  # REV13 unified J_soft
            if overtime_inc > 0.0:
                pass  # REV13 unified J_soft
            if return_over_inc > 0.0:
                pass  # REV13 unified J_soft
            if not supported_action:
                reward_hierarchy += float(HIER_NO_SUPPORT_ACTION_PENALTY)

            if HIER_TRACE_HIGH_REWARDS and abs(float(reward_hierarchy)) >= float(HIER_TRACE_THRESHOLD):
                print(
                    f"[HIER-R] veh={vehicle.vehicle_id} act={action_index} loc={cur}->{next_node} "
                    f"rem={rem_units_before}->{rem_units_after} del={int(delivered_now)} st={delivery_status} "
                    f"prog={progress_delta:.3f} dur_inc={duration_inc:.2f} dist_km={distance_km:.3f} "
                    f"solve={int(solved_just_now)} ret={int(returned_after_solve_now)} allret={int(all_returned_done_now)} "
                    f"hR={reward_hierarchy:.2f}",
                    flush=True
                )

        # Reward component sums
        vehicle.sum_reward_fuel += float(reward_fuel)
        vehicle.sum_reward_duration += float(reward_duration)
        vehicle.sum_reward_location += float(reward_location)
        vehicle.sum_reward_unsecure += float(reward_unsecure)
        vehicle.sum_reward_timewindow += float(reward_timewindow)
        vehicle.sum_reward_distance += float(reward_distance)
        vehicle.sum_reward_hierarchy += float(reward_hierarchy)
        vehicle.sum_extra_penalty += float(extra_penalty)

        # REV13 unified soft objective. Every preference-sensitive term enters
        # the Q-learning reward exactly once through this normalized scalar.
        step_duration = max(0.0, float(vehicle.total_duration) - float(cur_time))
        step_distance_km = max(0.0, float(distance_traveled) / 1000.0)
        edge_risk_norm = max(0.0, -float(reward_unsecure)) / max(1e-6, float(getattr(self, "risk_scale", 1.0)))
        fleet_makespan_after = max([float(v.total_duration) for v in getattr(self, "vehicles_ref", [])] + [float(vehicle.total_duration)])
        loop_event = (
            int(bool(will_backtrack))
            + int(bool(recent_revisit and (next_node not in self.secure_zones)))
            + int(bool((not is_wait) and self.is_looping(vehicle.visited_locations)))
            + int(bool((not delivered_now) and (reward_distance <= 1e-6) and (not planned_wait)))
        )
        miss_unit = (1.0 + float(delivery_gap_units)) / max(1.0, float(TOTAL_REQUIRED_UNITS))
        step_soft_costs = {
            "undelivered": 0.0,
            "early": miss_unit if str(delivery_status) == "early" else 0.0,
            "late": miss_unit if str(delivery_status) == "late" else 0.0,
            "service_over": float(overtime_inc) / max(1.0, float(WINDOW_SIZE_MIN)),
            "return_over": float(return_over_inc) / max(1.0, float(WINDOW_SIZE_MIN)),
            "secure": (1.0 / SOFT_EXPECTED_EPISODE_STEPS) if ((not is_wait) and (next_node not in self.secure_zones)) else 0.0,
            "distance": step_distance_km / 100.0,
            "duration": step_duration / max(1.0, float(n_vehicles) * float(ABSOLUTE_MAX_ROUTE_DURATION_MIN)),
            "risk": edge_risk_norm / SOFT_EXPECTED_EPISODE_STEPS,
            "loop": float(loop_event) / SOFT_EXPECTED_EPISODE_STEPS,
            "reservation": 0.0,
            "makespan": max(0.0, fleet_makespan_after - fleet_makespan_before) / max(1.0, float(ABSOLUTE_MAX_ROUTE_DURATION_MIN)),
        }
        soft_scalar = float(scalarize_cost_terms(step_soft_costs, weights=objective_weight_dict()))
        soft_reward = -float(SOFT_REWARD_SCALE) * float(soft_scalar)
        vehicle.sum_reward_soft_objective = float(getattr(vehicle, "sum_reward_soft_objective", 0.0)) + float(soft_reward)

        raw_reward = reward_location + reward_hierarchy + extra_penalty + soft_reward

        reward = float(np.clip(raw_reward, -REWARD_CLIP, REWARD_CLIP))
        if reward != float(raw_reward):
            vehicle.reward_clipped_steps += 1

        vehicle.max_step_reward = float(max(vehicle.max_step_reward, raw_reward))
        vehicle.min_step_reward = float(min(vehicle.min_step_reward, raw_reward))

        # Normal path.
        # Some earlier branches return directly with a computed next_state.
        # For the standard flow we must always construct next_state here.
        next_state = self.get_state_from_external(vehicle)

        return next_state, float(reward), bool(done), bool(vehicle.done_vehicle)

    def reset(self):
        self.location = self.depot
        self.one_hot_location = self.one_hot_encode(self.location, self.n_locations)
        self.demands = {int(node): int(amount) for node, amount in self.demands_init}
        self.one_hot_demands = self.one_hot_encode_demands()
        self.all_delivered = False
        self.returned_vehicle_ids = set()


class Vehicle:
    def __init__(self, vehicle_id, capacity, environment: Environment):
        self.vehicle_id = int(vehicle_id)
        self.initial_capacity = int(capacity)
        self.capacity = int(capacity)
        self.environment = environment

        self.current_location = int(environment.depot)

        self.total_distance = 0.0
        self.total_duration = 0.0
        self.total_fuel = 0.0

        self.visited_time = [0.0]
        self.current_time_window = 0

        self.visited_locations = [int(environment.depot)]
        self.visited_time_window = [0]

        self.done_vehicle = False

        # Streaks
        self.steps_since_delivery = 0
        self.no_progress_streak = 0

        # Counters
        self.total_steps = 0
        self.deliveries_made = 0
        self.tw_misses = 0
        self.tw_misses_early = 0
        self.tw_misses_late = 0
        self.unreachable_steps = 0
        self.reward_clipped_steps = 0

        self.max_step_reward = -1e9
        self.min_step_reward = 1e9

        self.backtracks = 0
        self.revisits = 0
        self.illegal_moves = 0
        self.shield_moves = 0
        self.loop_flags = 0
        self.stall_terminations = 0
        self.end_of_day_terminations = 0

        # Service end. Return grace.
        self.service_end_triggered = False
        self.service_closed_steps = 0
        self.forced_return_steps = 0
        self.overtime_minutes = 0.0
        self.return_extension_minutes = 0.0

        # Secure wait counters
        self.secure_wait_steps = 0
        self.secure_travel_steps = 0
        self.early_redirects = 0

        # Action mask stats
        self.mask_calls = 0
        self.mask_early = 0
        self.mask_late = 0
        self.mask_all_blocked = 0
        self.no_feasible_steps = 0

        # Target lock ve early hold
        self.locked_target = -1
        self.lock_steps = 0
        self.target_switches = 0
        self.hold_active = False
        self.hold_target = -1

        # Target switch penalty (step bazlı, env.step içinde uygulanır)
        self.switch_penalty_due = 0.0

        # Loop penalty counter
        self.loop_penalty_steps = 0
        self.rogue_force_progress_steps = 0

        # Reward component sums
        self.sum_reward_fuel = 0.0
        self.sum_reward_duration = 0.0
        self.sum_reward_location = 0.0
        self.sum_reward_timewindow = 0.0
        self.sum_reward_unsecure = 0.0
        self.sum_reward_distance = 0.0
        self.sum_reward_hierarchy = 0.0
        self.sum_reward_soft_objective = 0.0
        self.sum_extra_penalty = 0.0

        # Shield burst / cooldown
        self.shield_burst_remaining = 0
        self.shield_cooldown_remaining = 0
        self.recovery_overrides = 0
        self.finish_overrides = 0

    @property
    def steps_taken(self) -> int:
        """Eski log kodları için uyumluluk alanı."""
        return int(self.total_steps)

    @property
    def eod_violations(self) -> int:
        """Eski log kodları için uyumluluk alanı."""
        return int(self.end_of_day_terminations)

    def reset(self):
        self.current_location = int(self.environment.depot)
        self.total_distance = 0.0
        self.total_duration = 0.0
        self.total_fuel = 0.0

        self.visited_time = [0.0]
        self.visited_locations = [int(self.environment.depot)]
        self.visited_time_window = [0]
        self.current_time_window = 0

        self.done_vehicle = False
        self.capacity = int(self.initial_capacity)

        self.steps_since_delivery = 0
        self.no_progress_streak = 0

        self.total_steps = 0
        self.deliveries_made = 0
        self.tw_misses = 0
        self.tw_misses_early = 0
        self.tw_misses_late = 0
        self.unreachable_steps = 0
        self.reward_clipped_steps = 0

        self.max_step_reward = -1e9
        self.min_step_reward = 1e9

        self.backtracks = 0
        self.revisits = 0
        self.illegal_moves = 0
        self.shield_moves = 0
        self.loop_flags = 0
        self.stall_terminations = 0
        self.end_of_day_terminations = 0

        # Service end. Return grace.
        self.service_end_triggered = False
        self.service_closed_steps = 0
        self.forced_return_steps = 0
        self.overtime_minutes = 0.0
        self.return_extension_minutes = 0.0

        self.secure_wait_steps = 0
        self.secure_travel_steps = 0
        self.early_redirects = 0

        # Action mask stats
        self.mask_calls = 0
        self.mask_early = 0
        self.mask_late = 0
        self.mask_all_blocked = 0
        self.no_feasible_steps = 0

        self.locked_target = -1
        self.lock_steps = 0
        self.target_switches = 0
        self.hold_active = False
        self.hold_target = -1

        self.switch_penalty_due = 0.0

        self.loop_penalty_steps = 0
        self.rogue_force_progress_steps = 0

        self.sum_reward_fuel = 0.0
        self.sum_reward_duration = 0.0
        self.sum_reward_location = 0.0
        self.sum_reward_timewindow = 0.0
        self.sum_reward_unsecure = 0.0
        self.sum_reward_distance = 0.0
        self.sum_reward_hierarchy = 0.0
        self.sum_reward_soft_objective = 0.0
        self.sum_extra_penalty = 0.0

        self.shield_burst_remaining = 0
        self.shield_cooldown_remaining = 0
        self.recovery_overrides = 0
        self.finish_overrides = 0


# ============================================================
# Data loading and alignment
# ============================================================
def _align_square_matrix(mat: np.ndarray, N: int, fill_value: float = 0.0) -> np.ndarray:
    mat = np.asarray(mat, dtype=np.float32)
    if mat.ndim != 2:
        raise ValueError(f"Square matrix bekleniyordu. ndims={mat.ndim} shape={mat.shape}")

    r, c = mat.shape
    if r != c:
        m = min(r, c)
        mat = mat[:m, :m]
        r = c = m

    if r == N:
        return mat

    out = np.full((N, N), float(fill_value), dtype=np.float32)
    m = min(N, r)
    out[:m, :m] = mat[:m, :m]
    return out


def _align_velocity_stack(vel: np.ndarray, N: int, dst_mat: np.ndarray) -> np.ndarray:
    vel = np.asarray(vel, dtype=np.float32)
    if vel.ndim == 2:
        vel = vel[None, :, :]
    if vel.ndim != 3:
        raise ValueError(f"Velocity 3D olmalı (TW,N,N). ndims={vel.ndim} shape={vel.shape}")

    TW = int(vel.shape[0])
    out = np.zeros((TW, N, N), dtype=np.float32)

    for t in range(TW):
        mat = vel[t]
        matA = _align_square_matrix(mat, N, fill_value=0.0)

        positive = mat[mat > 0]
        default_speed = float(np.mean(positive)) if positive.size > 0 else 30.0
        mask_missing_speed = (dst_mat > 0) & (matA <= 0)
        matA[mask_missing_speed] = default_speed

        out[t] = matA

    return out


t_data0 = time.perf_counter()

# ============================================================
# Data caching (NPY).
# Excel parse çok yavaş. İlk çalıştırmada .npy cache üretip sonraki çalıştırmalarda onu yükler.
#
# Not:
# - Cache dosyaları silinirse otomatik yeniden üretilir.
# - Cache yazımı (disk dolu / izin / kilit) hata verirse training DURMAZ, sadece cache yazılamaz.
# ============================================================
import shutil

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CACHE_DIR = os.environ.get("CIT_CACHE_DIR", os.path.join(SCRIPT_DIR, "cache_np"))
CACHE_DIR = os.path.abspath(DEFAULT_CACHE_DIR)
os.makedirs(CACHE_DIR, exist_ok=True)

CACHE_ENABLE = True  # İstersen False yapıp tamamen Excel'den okuyabilirsin.

def _disk_free_bytes(path: str) -> int:
    try:
        return int(shutil.disk_usage(path).free)
    except Exception:
        return 0

def _atomic_save_npy(npy_path: str, arr: np.ndarray) -> bool:
    # Atomik yazım: önce tmp'e kaydet, sonra replace.
    tmp_path = npy_path + f".tmp_{os.getpid()}.npy"
    try:
        arr_c = np.ascontiguousarray(arr)
        free_b = _disk_free_bytes(os.path.dirname(npy_path))
        # Basit güvenlik payı. arr.nbytes + 1MB
        if free_b and free_b < int(arr_c.nbytes + 1024 * 1024):
            print(f"[CACHE][WARN] Not enough disk to save '{os.path.basename(npy_path)}'. "
                  f"need~{arr_c.nbytes/1e6:.1f}MB free={free_b/1e6:.1f}MB. Skipping cache save.", flush=True)
            return False
        np.save(tmp_path, arr_c)
        os.replace(tmp_path, npy_path)
        return True
    except Exception as e:
        # cleanup tmp
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        print(f"[CACHE][WARN] np.save failed. path={npy_path} err={e}. Continuing without cache for this matrix.", flush=True)
        return False

def _looks_like_index(vec: np.ndarray) -> bool:
    # İlk 200 eleman üzerinden 0.. veya 1.. gibi index mi kontrol et.
    try:
        v = np.asarray(vec, dtype=np.float64)
    except Exception:
        return False
    if v.size < 10:
        return False
    if np.isnan(v).any():
        return False
    n = int(min(v.size, 200))
    v = v[:n]
    for start in (0.0, 1.0):
        target = np.arange(start, start + n, dtype=np.float64)
        if np.allclose(v, target, atol=1e-3, rtol=0.0):
            return True
    return False

def _sanitize_excel_matrix(arr: np.ndarray) -> np.ndarray:
    # object -> numeric
    if arr.dtype == object:
        arr = pd.DataFrame(arr).apply(pd.to_numeric, errors="coerce").values
    arr = arr.astype(np.float32, copy=False)

    # drop fully-NaN rows/cols (header=None rağmen bazı exportlarda olabiliyor)
    if np.isnan(arr).any():
        keep_r = ~np.all(np.isnan(arr), axis=1)
        keep_c = ~np.all(np.isnan(arr), axis=0)
        arr = arr[keep_r][:, keep_c]

    # index/header satır-sütun tespiti (pandas exportu gibi)
    if arr.ndim == 2 and arr.shape[0] >= 3 and arr.shape[1] >= 3:
        r0 = arr[0, 1:]
        c0 = arr[1:, 0]
        if _looks_like_index(r0) and _looks_like_index(c0):
            arr = arr[1:, 1:]
        else:
            # Sadece index kolonu varsa (N x (N+1) veya (N+1) x N)
            if _looks_like_index(c0) and (arr.shape[1] > arr.shape[0]):
                arr = arr[:, 1:]
            if _looks_like_index(r0) and (arr.shape[0] > arr.shape[1]):
                arr = arr[1:, :]

    arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
    return arr

def _read_excel_matrix(excel_path: str, sheet_candidates) -> np.ndarray:
    last_err = None
    for sh in sheet_candidates:
        try:
            df_local = pd.read_excel(excel_path, sheet_name=sh, header=None)
            return _sanitize_excel_matrix(df_local.values)
        except Exception as e:
            last_err = e
    raise last_err if last_err else RuntimeError(f"Failed to read excel: {excel_path}")

def _load_or_build_matrix(npy_name: str, excel_path: str, sheet_candidates):
    npy_path = os.path.join(CACHE_DIR, npy_name)
    if os.path.exists(npy_path):
        try:
            return np.load(npy_path), True
        except Exception as e:
            print(f"[CACHE][WARN] failed to load cache '{npy_path}'. err={e}. Rebuilding from Excel.", flush=True)

    arr_local = _read_excel_matrix(excel_path, sheet_candidates)
    cache_saved = False
    if CACHE_ENABLE:
        cache_saved = _atomic_save_npy(npy_path, arr_local)
    # cache_saved True olsa bile bu 'cache hit' değildir. hit sadece load durumudur.
    return arr_local, False

# ---- Load matrices (from cache if exists, else from Excel and try to cache) ----
dst, _c_dst = _load_or_build_matrix("distance.npy", "distance.xlsx", ["Sheet1", "Sayfa1", 0])

velocity = []
_c_vel_all = True
for fname in ["Saat8ort.xlsx", "Saat10ort.xlsx", "Saat12ort.xlsx", "Saat14ort.xlsx", "Saat16ort.xlsx", "Saat18ort.xlsx"]:
    arr_v, _c_v = _load_or_build_matrix(f"{os.path.splitext(fname)[0]}.npy", fname, ["Sayfa1", "Sheet1", 0])
    _c_vel_all = _c_vel_all and bool(_c_v)
    velocity.append(arr_v)
velocity = np.stack(velocity, axis=0)

velocity_noise, _c_noise = _load_or_build_matrix("velocity_std.npy", "velocity_std.xlsx", ["Sayfa1", "Sheet1", 0])
security_risc, _c_risk = _load_or_build_matrix("risk.npy", "risk.xlsx", ["Sayfa1", "Sheet1", 0])

_cache_hit = bool(_c_dst and _c_vel_all and _c_noise and _c_risk)
print(f"[DATA] load time={float(time.perf_counter()-t_data0):.2f}s cache={int(_cache_hit)} cache_dir={CACHE_DIR}", flush=True)

N = int(dst.shape[0])
dst = _align_square_matrix(dst, N, fill_value=0.0)
N = int(dst.shape[0])

velocity = _align_velocity_stack(velocity, N, dst)
velocity_noise = _align_square_matrix(velocity_noise, N, fill_value=0.0)
security_risc = _align_square_matrix(security_risc, N, fill_value=0.0)

# Ortalama hızları hesapla (time window bazlı).
AVG_SPEED_TW = []
for _t in range(int(velocity.shape[0])):
    _pos = velocity[_t][velocity[_t] > 0]
    AVG_SPEED_TW.append(float(np.mean(_pos)) if _pos.size else 30.0)

print("Matrix shapes. dst", dst.shape, "velocity", velocity.shape, "noise", velocity_noise.shape, "risk", security_risc.shape, flush=True)
if BOOT_LOG:
    print("[BOOT] matrices loaded and aligned", flush=True)

# ============================================================
# Time windows
# ============================================================
time_window_numbers = [0, 1, 2, 3, 4, 5]
time_windows = [0, 120, 240, 360, 480, 600]

# Problem
n_locations = int(dst.shape[0])
depot = 0

demands = [
    [9, 1], [16, 1], [37, 1], [75, 1], [93, 1], [294, 1], [314, 1], [455, 1], [674, 1], [681, 1],
    [683, 1], [880, 1], [1072, 1], [1319, 1], [1372, 1], [1376, 1], [1657, 1], [1678, 1], [1957, 1],
    [2096, 1], [2134, 1], [2207, 1], [2236, 1], [2252, 1], [2331, 1], [2346, 1], [2379, 1], [2387, 1],
    [2591, 1], [2682, 1], [2721, 1], [2726, 1], [2743, 1], [2810, 1]
]
TOTAL_DEMAND_UNITS_FULL = int(sum(int(a) for _, a in demands))

delivery_time_windows = [
    [0, 1], [3], [1], [5], [0], [4], [3, 4], [1, 2], [2, 3], [1],
    [0], [0, 2], [1], [3, 4], [4, 5], [3, 5], [2, 5], [1, 5], [0, 2], [2, 4],
    [2], [0], [2, 3], [4], [2], [1, 5], [3], [3, 4], [4], [2],
    [0, 1, 2, 3, 4], [0, 1, 2, 3], [0, 1, 4, 5], [0, 1, 2, 5]
]

delivery_windows_by_node = {}
for (node, _), tws in zip(demands, delivery_time_windows):
    node = int(node)
    delivery_windows_by_node[node] = sorted(set(int(x) for x in tws))

# Secure zones
secure_zones = set([
    7, 10, 15, 16, 17, 18, 19, 20, 24, 25, 26, 27, 28, 29, 30, 31, 39, 40,
    68, 83, 89, 90, 106, 107, 108, 109, 123, 168, 174, 175, 176, 177, 181, 182, 183, 188,
    212, 268, 269, 270, 272, 273, 274, 376, 377, 382, 383, 384, 386, 387, 388, 389, 390, 391, 392, 393,
    410, 411, 412, 442, 446, 451, 457, 524, 617, 618, 619, 620, 621, 622, 629, 630, 631, 633, 634, 636,
    637, 640, 641, 642, 643, 644, 645, 646, 647, 648, 654, 655, 656, 657, 660, 673, 680, 681, 682, 688,
    689, 711, 712, 713, 714, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 741, 742, 779, 785, 790,
    809, 816, 817, 818, 819, 820, 821, 822, 827, 829, 885, 886, 896, 912, 913, 934, 935, 936, 937, 938,
    993, 994, 998, 1001, 1004, 1005, 1006, 1007, 1008, 1009, 1124, 1125, 1126, 1129, 1131, 1134, 1135,
    1136, 1142, 1154, 1192, 1193, 1194, 1195, 1196, 1197, 1201, 1205, 1226, 1259, 1260, 1262, 1273, 1282,
    1284, 1286, 1287, 1288, 1289, 1290, 1297, 1301, 1302, 1304, 1305, 1306, 1307, 1308, 1309, 1322, 1323,
    1324, 1326, 1328, 1330, 1331, 1333, 1334, 1336, 1339, 1341, 1368, 1382, 1387, 1388, 1389, 1393, 1394,
    1398, 1403, 1406, 1411, 1449, 1450, 1465, 1466, 1467, 1468, 1502, 1503, 1504, 1505, 1506, 1507, 1511,
    1512, 1513, 1540, 1541, 1543, 1545, 1546, 1547, 1548, 1552, 1553, 1580, 1581, 1588, 1602, 1607, 1611,
    1630, 1632, 1633, 1635, 1636, 1637, 1729, 1737, 1738, 1739, 1741, 1743, 1744, 1745, 1746, 1747, 1751,
    1752, 1753, 1846, 1847, 1849, 1850, 1852, 1853, 1855, 1857, 1858, 1861, 1864, 1865, 1867, 1870, 1871,
    1875, 1912, 1917, 1922, 1925, 1926, 1927, 1929, 1934, 1938, 1940, 1941, 2019, 2020, 2024, 2026, 2028,
    2033, 2034, 2131, 2132, 2161, 2162, 2163, 2181, 2188, 2191, 2192, 2194, 2195, 2196, 2197, 2198, 2201,
    2202, 2203, 2204, 2205, 2206, 2207, 2228, 2229, 2231, 2232, 2235, 2236, 2238, 2239, 2240, 2280, 2281,
    2282, 2284, 2285, 2286, 2287, 2292, 2302, 2303, 2304, 2305, 2306, 2309, 2311, 2312, 2313, 2315, 2316,
    2317, 2318, 2319, 2320, 2337, 2339, 2340, 2343, 2344, 2346, 2347, 2348, 2370, 2371, 2378, 2391, 2412,
    2413, 2415, 2416, 2419, 2421, 2422, 2423, 2424, 2425, 2451, 2461, 2462, 2463, 2466, 2467, 2469, 2471,
    2507, 2513, 2546, 2547, 2574, 2587, 2615, 2631, 2633, 2680, 2681, 2688, 2690, 2705, 2719, 2731, 2732,
    2734, 2742, 2746, 2751, 2752, 2753, 2754, 2764, 2765, 2766, 2793, 2794, 2796, 2800, 2801, 2802, 2803,
    2814, 2822, 2842, 2843, 2844
])
secure_zones = set(int(z) for z in secure_zones if 0 <= int(z) < int(n_locations))
secure_time = 5.0

# ============================================================
# Environment and vehicles
# ============================================================
# Araç sayısını buradan kontrol et.
# Not. n_vehicles otomatik olarak vehicle_capacities uzunluğundan alınır.
vehicle_capacities = [7, 7, 7, 7, 6]
n_vehicles = int(len(vehicle_capacities))

print(f"[SANITY] n_vehicles={n_vehicles} vehicle_capacities={vehicle_capacities} total_capacity={sum(vehicle_capacities)}", flush=True)
print(f"[SANITY] service_end_min={SERVICE_END_MIN:.0f} return_grace_min={RETURN_GRACE_MIN:.0f} max_route_min={MAX_ROUTE_DURATION_MIN:.0f}", flush=True)
total_capacity = int(sum(vehicle_capacities))
# Objective weights (w1..w4) üst tarafta "REWARD / OBJECTIVE WEIGHTS" bölümünde tanımlı.
print(f"[CONFIG] w1={w1} w2={w2} w3={w3} w4={w4} W_TIMEWINDOW={W_TIMEWINDOW} | objectives: {objective_weights_log_string()}", flush=True)
print(f"[CONFIG] hierarchical_cit={int(HIER_CIT_ACTIVE)} hier_obs_dim={HIER_OBS_DIM} trace_thr={HIER_TRACE_THRESHOLD}", flush=True)

env = Environment(
    dst=dst,
    velocity=velocity,
    velocity_noise=velocity_noise,
    demands=demands,
    delivery_windows_by_node=delivery_windows_by_node,
    n_vehicles=n_vehicles,
    vehicle_capacities=vehicle_capacities,
    depot=depot,
    secure_zones=secure_zones
)

TOTAL_REQUIRED_UNITS = int(env.total_required_units)
# Capacity sanity check (after environment sets required units)
if total_capacity < TOTAL_REQUIRED_UNITS:
    raise ValueError(
        f"Total kapasite yetersiz. total_capacity={total_capacity} required_units={TOTAL_REQUIRED_UNITS}. "
        "vehicle_capacities veya demand setini kontrol et."
    )
if total_capacity == TOTAL_REQUIRED_UNITS:
    print(
        f"[SANITY][WARN] total_capacity == required_units ({total_capacity}). Slack yok. "
        "Bu ayarda politika neredeyse hatasız olmalı. Eğitim daha kırılgan olur.",
        flush=True
    )
else:
    print(
        f"[SANITY] total_capacity={total_capacity} required_units={TOTAL_REQUIRED_UNITS} slack={total_capacity - TOTAL_REQUIRED_UNITS}",
        flush=True
    )
TOTAL_DROPPED_UNITS = int(env.dropped_units)
TOTAL_DROPPED_NODES = int(len(env.dropped_demands_init))
if TOTAL_DROPPED_NODES > 0:
    print(
        f"[SANITY] required_units={TOTAL_REQUIRED_UNITS} full_units={TOTAL_DEMAND_UNITS_FULL} dropped_nodes={TOTAL_DROPPED_NODES} dropped_units={TOTAL_DROPPED_UNITS}",
        flush=True
    )
else:
    print(f"[SANITY] required_units={TOTAL_REQUIRED_UNITS} full_units={TOTAL_DEMAND_UNITS_FULL}", flush=True)

vehicles = [Vehicle(i, vehicle_capacities[i], env) for i in range(int(n_vehicles))]
env.register_vehicles(vehicles)

# ============================================================
# RL setup
# ============================================================
tf.random.set_seed(1234)

MEMORY_SIZE = 50_000
GAMMA = 0.995
ALPHA = float(os.environ.get("CIT_LEARNING_RATE", "1e-6"))
MIN_REPLAY_SIZE_FOR_LEARNING = 4096
NUM_STEPS_FOR_UPDATE = 4
EPS_START_FRESH = 1.0
EPS_START_RESUME = 0.08  # REV16 fine-tune: mature REV15 policy is preserved.
epsilon = EPS_START_FRESH
E_DECAY = 0.999
E_MIN = 0.01

save_models_period = 100
test_period = 20

# Deterministik mini test suite
# Eğitim hızını düşürmemesi için seyrek ve az sayıda seed ile çalışır.
SUITE_TEST_ACTIVE = bool(int(os.environ.get("CIT_SUITE_TEST_ACTIVE", "1")))
SUITE_TEST_PERIOD = 200
SUITE_TEST_N = 10
SUITE_TEST_SEED0 = 12345
SUITE_TEST_MAX_STEPS = 3500

# Resume
RESUME_IF_AVAILABLE = bool(int(os.environ.get("CIT_RESUME_IF_AVAILABLE", "1")))
AUTO_RESUME_LATEST = False
AUTO_RESUME_STRICT_VERSION = True
RESUME_WEIGHTS_PATH = f"cit_q_network_{VERSION}.h5"
_workspace_dir = Path(__file__).resolve().parent
_rev14_1_candidates = sorted(
    (_workspace_dir / "run_logs").glob(
        "run_*/best_checkpoints/best_balanced_v14_19_1_hierarchical_cit_rev14_1_loopsafe_hard_target.weights.h5"
    ),
    key=lambda p: p.stat().st_mtime,
    reverse=True,
)
_rev14_candidates = sorted(
    (_workspace_dir / "run_logs").glob(
        "run_*/best_checkpoints/best_balanced_v14_19_hierarchical_cit_rev14_baseline_hard_target.weights.h5"
    ),
    key=lambda p: p.stat().st_mtime,
    reverse=True,
)
_rev13_fallback = (
    _workspace_dir / "run_logs" / "run_20260815_012838" / "best_checkpoints"
    / "best_balanced_v14_18_hierarchical_cit_rev13_unified_mo.weights.h5"
)
_default_rev15_warm_start = (
    _workspace_dir / "cit_q_network_v14_20_hierarchical_cit_rev15_pareto_conditioned.h5"
)
_warm_start_value = os.environ.get(
    "CIT_WARM_START_WEIGHTS_PATH", str(_default_rev15_warm_start)
).strip()
WARM_START_WEIGHTS_PATH = Path(_warm_start_value).expanduser() if _warm_start_value else None

# Tam checkpoint / resume
# Amaç: elektrik kesilse bile sadece ağ ağırlığı değil; episode, epsilon, learn_step,
# replay buffer, optimizer state ve history listeleri de geri yüklenebilsin.
CHECKPOINT_ENABLE = bool(int(os.environ.get("CIT_CHECKPOINT_ENABLE", "1")))
CHECKPOINT_EVERY_EPISODE = int(os.environ.get("CIT_CHECKPOINT_EVERY_EPISODE", "20"))
# Replay buffer checkpoint çok büyük olabilir. Varsayılanı kapalı tutuyoruz.
# Tam replay resume istenirse ortam değişkeni ile açılabilir.
CHECKPOINT_SAVE_REPLAY = bool(int(os.environ.get("CIT_CHECKPOINT_SAVE_REPLAY", "0")))
CHECKPOINT_REPLAY_EVERY_EPISODE = int(os.environ.get("CIT_CHECKPOINT_REPLAY_EVERY_EPISODE", "25"))
CHECKPOINT_REPLAY_MAX_ITEMS = int(os.environ.get("CIT_CHECKPOINT_REPLAY_MAX_ITEMS", "10000"))
CHECKPOINT_MIN_FREE_MB_FOR_META = float(os.environ.get("CIT_CHECKPOINT_MIN_FREE_MB_FOR_META", "64"))
CHECKPOINT_MIN_FREE_MB_FOR_REPLAY = float(os.environ.get("CIT_CHECKPOINT_MIN_FREE_MB_FOR_REPLAY", "2048"))
CHECKPOINT_MAX_TO_KEEP = 1
CHECKPOINT_DIR = Path(os.environ.get("CIT_CHECKPOINT_DIR", f"resume_ckpt_{VERSION}")).expanduser()
CHECKPOINT_META_PATH = CHECKPOINT_DIR / "training_state.pkl"
CHECKPOINT_REPLAY_PATH = CHECKPOINT_DIR / "replay_buffer.npz"
CHECKPOINT_NOTE_PATH = CHECKPOINT_DIR / "README_resume.txt"

env.reset()

N_WEIGHTS = OBJECTIVE_WEIGHT_DIM + 5
IDX_LOC_START = N_WEIGHTS
IDX_LOC_END = IDX_LOC_START + n_locations

state_size = int(env.get_state_from_external(vehicles[0]).shape[0])
num_actions = int(MAX_ACTIONS)

print("State Shape:", state_size)
print("Number of actions:", num_actions)
print(f"[CKPT] enabled={int(CHECKPOINT_ENABLE)} dir={CHECKPOINT_DIR} every_ep={CHECKPOINT_EVERY_EPISODE} replay={int(CHECKPOINT_SAVE_REPLAY)} replay_every={CHECKPOINT_REPLAY_EVERY_EPISODE}", flush=True)

if BOOT_LOG:
    print("[LOGLEGEND] EP: del=delivered/required rem=remaining ret=returned/vehicles steps=dispatch_events sps=events_per_sec dist=km kpd=km_per_delivery miss=TW_violations sh=shield clip=reward_clip eod=hard_EOD sw=secure_wait st=secure_travel erd=early_redirects ot=overtime_min rte=return_ext mksp=max_route_time dur=sum_route_time eps=epsilon", flush=True)
    print("[LOGLEGEND] V : del miss(e,l) back=backtrack rev=revisit shield=shield_move loop=loop_flags stall=stall_term eod=hard_EOD unr=unreachable clip=clip sw/st/erd/ot/rte counters loc=node tw=time_window cap=capacity dist=km kpd=km_per_delivery", flush=True)

# Model size
HIDDEN_UNITS = 1024

q_network = Sequential([
    Input(state_size),
    Dense(units=HIDDEN_UNITS, activation="relu"),
    Dense(units=HIDDEN_UNITS, activation="relu"),
    Dense(units=num_actions, activation="linear")
])

target_q_network = Sequential([
    Input(state_size),
    Dense(units=HIDDEN_UNITS, activation="relu"),
    Dense(units=HIDDEN_UNITS, activation="relu"),
    Dense(units=num_actions, activation="linear")
])

# Resume weights (opsiyonel)
# Resume weights (opsiyonel). VERSION değişince dosya adı değişebilir.
# Bu yüzden weight dosyası yoksa otomatik olarak en güncel cit_q_network_*.h5 dosyasını deniyoruz.
resume_loaded = False
resume_loaded_path = None
prefer_full_checkpoint_resume = bool(RESUME_IF_AVAILABLE and CHECKPOINT_ENABLE and CHECKPOINT_META_PATH.exists())
if prefer_full_checkpoint_resume:
    print(f"[BOOT] full checkpoint metadata found; skipping legacy .h5 weight preload. path={CHECKPOINT_META_PATH}", flush=True)

if RESUME_IF_AVAILABLE and (not prefer_full_checkpoint_resume):
    resume_path = RESUME_WEIGHTS_PATH
    if resume_path and os.path.exists(resume_path):
        try:
            q_network.load_weights(resume_path)
            resume_loaded = True
            resume_loaded_path = resume_path
            print(f"[BOOT] resume weights loaded. path={resume_path}", flush=True)
        except Exception as e:
            print(f"[BOOT] resume failed. path={resume_path} err={e}", flush=True)
    else:
        print(f"[BOOT] resume weights not found. path={resume_path}", flush=True)
        if AUTO_RESUME_LATEST:
            try:
                candidates = [f for f in os.listdir('.') if f.startswith('cit_q_network_') and f.endswith('.h5')]
                candidates = sorted(candidates, key=lambda p: os.path.getmtime(p), reverse=True)
            except Exception:
                candidates = []
            if AUTO_RESUME_STRICT_VERSION:
                candidates = [c for c in candidates if (VERSION in c)]
            if candidates:
                cand = candidates[0]
                try:
                    q_network.load_weights(cand)
                    resume_loaded = True
                    resume_loaded_path = cand
                    print(f"[BOOT] auto-resume loaded latest weights. path={cand}", flush=True)
                except Exception as e:
                    print(f"[BOOT] auto-resume failed. path={cand} err={e}", flush=True)
            else:
                print("[BOOT] auto-resume: no matching cit_q_network_*.h5 found.", flush=True)

if RESUME_IF_AVAILABLE and (not prefer_full_checkpoint_resume) and (not resume_loaded) and WARM_START_WEIGHTS_PATH is not None and WARM_START_WEIGHTS_PATH.exists():
    try:
        q_network.load_weights(str(WARM_START_WEIGHTS_PATH))
        resume_loaded = True
        resume_loaded_path = str(WARM_START_WEIGHTS_PATH)
        print(f"[BOOT] warm-start weights loaded. path={WARM_START_WEIGHTS_PATH}", flush=True)
    except Exception as e:
        print(f"[BOOT] warm-start failed. path={WARM_START_WEIGHTS_PATH} err={e}", flush=True)

optimizer = Adam(ALPHA)

# Tam training checkpoint nesneleri
if CHECKPOINT_ENABLE:
    try:
        CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(f"[CKPT][WARN] checkpoint dir create failed. dir={CHECKPOINT_DIR} err={e}", flush=True)
checkpoint = tf.train.Checkpoint(q_network=q_network, target_q_network=target_q_network, optimizer=optimizer)
checkpoint_manager = tf.train.CheckpointManager(checkpoint, str(CHECKPOINT_DIR / "tf_ckpt"), max_to_keep=int(CHECKPOINT_MAX_TO_KEEP))

experience = namedtuple(
    "Experience",
    field_names=["state", "action", "reward", "next_state", "done", "next_action_mask"],
)
memory_buffer = deque(maxlen=MEMORY_SIZE)
target_q_network.set_weights(q_network.get_weights())

TARGET_UPDATE_PERIOD = 2000
learn_step = 0

# Eğitim sırasında nadiren de olsa batch bozulması / TF hatası vb. olursa tüm run'ın çökmesini
# engellemek için "güvenli" öğrenme modu.
SAFE_TRAINING_MODE = True
CLEAR_BUFFER_ON_TRAIN_ERROR = False


def sample_masked_experiences(replay_buffer, batch_size: int):
    """Sample replay rows including the REV6 next-state action mask."""
    rows = random.sample(replay_buffer, k=int(batch_size))
    return (
        np.vstack([e.state for e in rows]).astype(np.float32),
        np.asarray([e.action for e in rows], dtype=np.int32),
        np.asarray([e.reward for e in rows], dtype=np.float32),
        np.vstack([e.next_state for e in rows]).astype(np.float32),
        np.asarray([e.done for e in rows], dtype=np.float32),
        np.vstack([e.next_action_mask for e in rows]).astype(np.bool_),
    )


def normalize_experiences(experiences):
    """Replay buffer batch'ini numpy/tensor karışık tiplerden sağlam biçimde normalize et."""
    if experiences is None:
        raise ValueError("get_experiences returned None")
    if len(experiences) != 6:
        raise ValueError(f"Expected 6 tensors, got {len(experiences)}")

    states, actions, rewards, next_states, done_vals, next_action_masks = experiences

    states = np.asarray(states, dtype=np.float32)
    next_states = np.asarray(next_states, dtype=np.float32)
    actions = np.asarray(actions, dtype=np.int32).reshape(-1)
    rewards = np.asarray(rewards, dtype=np.float32).reshape(-1)
    done_vals = np.asarray(done_vals, dtype=np.float32).reshape(-1)
    next_action_masks = np.asarray(next_action_masks, dtype=np.bool_)

    if states.ndim == 1:
        states = states.reshape(1, -1)
    if next_states.ndim == 1:
        next_states = next_states.reshape(1, -1)

    if states.ndim != 2 or next_states.ndim != 2:
        raise ValueError(f"Bad batch dims: states={states.shape} next={next_states.shape}")

    batch_size = int(states.shape[0])
    if int(next_states.shape[0]) != batch_size:
        raise ValueError("Batch size mismatch (states vs next_states)")
    if actions.shape[0] != batch_size:
        raise ValueError("Batch size mismatch (states vs actions)")
    if rewards.shape[0] != batch_size:
        raise ValueError("Batch size mismatch (states vs rewards)")
    if done_vals.shape[0] != batch_size:
        raise ValueError("Batch size mismatch (states vs done)")
    if next_action_masks.shape != (batch_size, int(MAX_ACTIONS)):
        raise ValueError(
            f"Bad next action mask shape: {next_action_masks.shape}; expected {(batch_size, int(MAX_ACTIONS))}"
        )

    if not np.all(np.isfinite(states)) or not np.all(np.isfinite(next_states)):
        raise ValueError("NaN/Inf detected in batch states")
    if not np.all(np.isfinite(rewards)) or not np.all(np.isfinite(done_vals)):
        raise ValueError("NaN/Inf detected in batch rewards/done")

    # A non-terminal transition must always expose at least one valid action.
    invalid_rows = (~np.any(next_action_masks, axis=1)) & (done_vals < 0.5)
    if np.any(invalid_rows):
        next_action_masks[invalid_rows, int(A_SECURE_WAIT)] = True

    return (states, actions, rewards, next_states, done_vals, next_action_masks)


def _run_rev6_learning_self_test_if_requested() -> None:
    if os.environ.get("CIT_REV6_SELF_TEST", "0") != "1":
        return
    n = 8
    rng = np.random.default_rng(611)
    states = rng.normal(size=(n, int(state_size))).astype(np.float32)
    next_states = rng.normal(size=(n, int(state_size))).astype(np.float32)
    actions = rng.integers(0, int(MAX_ACTIONS), size=n, dtype=np.int32)
    rewards = rng.normal(size=n).astype(np.float32)
    dones = np.zeros(n, dtype=np.float32)
    masks = np.zeros((n, int(MAX_ACTIONS)), dtype=np.bool_)
    masks[np.arange(n), rng.integers(0, int(MAX_ACTIONS), size=n)] = True
    batch = normalize_experiences((states, actions, rewards, next_states, dones, masks))
    loss = float(np.asarray(agent_learn(batch, GAMMA)).reshape(()))
    if not np.isfinite(loss):
        raise RuntimeError(f"REV6 masked DDQN self-test produced non-finite loss: {loss}")
    print(f"[REV6-SELF-TEST] masked_ddqn=OK batch={n} loss={loss:.6f}", flush=True)
    raise SystemExit(0)


_run_rev6_learning_self_test_if_requested()



def _terminal_repair_ranked_actions(env_local, vehicle, mask=None):
    details = env_local.get_candidate_details(vehicle, topk=max(int(CANDIDATE_TOPK), 8))
    ranked = []
    for i, det in enumerate(details[:int(CANDIDATE_TOPK)]):
        if mask is not None and i < len(mask) and (not bool(mask[i])):
            continue
        score = float(det.get("scalar_cost", det.get("score", 0.0)))
        if bool(det.get("deliver_now", 0.0) > 0.5):
            score -= float(TERMINAL_REPAIR_DELIVER_NOW_BONUS)
        elif bool(det.get("deliver_rescue", 0.0) > 0.5):
            score -= float(TERMINAL_REPAIR_DELIVER_RESCUE_BONUS)
        else:
            score += 0.08
        score += 0.08 * float(det.get("service_over_min", 0.0)) / max(1.0, WINDOW_SIZE_MIN)
        score += 0.08 * float(det.get("return_over_min", 0.0)) / max(1.0, WINDOW_SIZE_MIN)
        score -= 0.05 * min(float(det.get("minutes_to_close", 0.0)), float(WINDOW_SIZE_MIN)) / max(1.0, WINDOW_SIZE_MIN)
        ranked.append((float(score), int(i), det))
    ranked.sort(key=lambda x: (x[0], x[1]))
    wait_cost = float(env_local.scalarize_cost_terms(env_local.wait_cost_terms(vehicle, details), vehicle=vehicle)) + float(TERMINAL_REPAIR_WAIT_PENALTY)
    return ranked, float(wait_cost)


def _clear_vehicle_lock_state(vehicle):
    if TARGET_HARD_CONSTRAINT and getattr(vehicle, "locked_target", -1) != -1:
        return
    try:
        vehicle.locked_target = -1
        vehicle.lock_steps = 0
        vehicle.hold_active = False
        vehicle.hold_target = -1
    except Exception:
        pass


def select_next_active_vehicle(env_local, vehicles_local):
    active = [i for i, vv in enumerate(vehicles_local) if not getattr(vv, "done_vehicle", False)]
    if not active:
        return None

    if TERMINAL_REPAIR_ACTIVE and int(env_local.remaining_units()) <= int(TERMINAL_REPAIR_REMAINING_UNITS):
        min_time = min(float(vehicles_local[i].total_duration) for i in active)
        eligible = [i for i in active if float(vehicles_local[i].total_duration) <= float(min_time) + float(TERMINAL_REPAIR_VEHICLE_TIME_BUCKET_MIN)]
        repair_choices = []
        for i in eligible:
            vv = vehicles_local[i]
            ranked, wait_cost = _terminal_repair_ranked_actions(env_local, vv, mask=None)
            if ranked:
                best_score, _best_idx, det = ranked[0]
                repair_choices.append((float(best_score), float(wait_cost), float(vv.total_duration), int(i), int(det.get('deliver_now', 0.0) > 0.5), int(det.get('deliver_rescue', 0.0) > 0.5)))
        if repair_choices:
            repair_choices.sort(key=lambda x: (x[0], -x[4], -x[5], x[2], x[3]))
            return int(repair_choices[0][3])

    if PARALLEL_DISPATCH_ACTIVE:
        min_time = min(float(vehicles_local[i].total_duration) for i in active)
        eligible = [i for i in active if float(vehicles_local[i].total_duration) <= float(min_time) + float(PARALLEL_DISPATCH_TIME_BUCKET_MIN)]
        return min(eligible, key=lambda i: (float(env_local.vehicle_dispatch_priority(vehicles_local[i])), float(vehicles_local[i].total_duration), int(vehicles_local[i].vehicle_id)))
    return active[0]


def recover_vehicle_when_no_active(env_local, vehicles_local):
    """Bounded recovery for stalled vehicles while feasible demand remains."""
    if (not REV5_COMPLETION_GUARDS) or (not REV5_NO_ACTIVE_RECOVERY):
        return None
    if int(env_local.remaining_units()) <= 0:
        return None

    candidates = []
    for i, vv in enumerate(vehicles_local):
        if not bool(getattr(vv, "done_vehicle", False)):
            continue
        if int(getattr(vv, "capacity", 0)) <= 0:
            continue
        if int(getattr(vv, "end_of_day_terminations", 0)) > 0:
            continue
        if float(getattr(vv, "total_duration", 0.0)) >= float(ABSOLUTE_MAX_ROUTE_DURATION_MIN):
            continue
        reactivations = int(getattr(vv, "no_active_reactivations", 0))
        if reactivations >= int(REV5_MAX_REACTIVATIONS_PER_VEHICLE):
            continue
        details = env_local.get_candidate_details(vv, topk=CANDIDATE_TOPK)
        if not details:
            continue
        best_cost = min(float(d.get("scalar_cost", d.get("score", 1e9))) for d in details)
        candidates.append((best_cost, float(vv.total_duration), -int(vv.capacity), int(i)))

    if not candidates:
        return None
    candidates.sort()
    idx = int(candidates[0][3])
    vehicle = vehicles_local[idx]
    vehicle.done_vehicle = False
    vehicle.no_progress_streak = 0
    vehicle.steps_since_delivery = 0
    vehicle.no_active_reactivations = int(getattr(vehicle, "no_active_reactivations", 0)) + 1
    _clear_vehicle_lock_state(vehicle)
    vehicle.recovery_overrides = int(getattr(vehicle, "recovery_overrides", 0)) + 1
    return idx


def choose_action_for_vehicle(env_local, vehicle, state, q_net, epsilon_local: float, training: bool, episode: int = 0, shield_prob: float = 0.0):
    mask = env_local.action_mask(vehicle) if ACTION_MASKING else np.ones(int(MAX_ACTIONS), dtype=np.bool_)
    bias = env_local.action_score_bias(vehicle)

    history = vehicle.visited_locations
    looping = env_local.is_looping(history)
    if looping:
        vehicle.loop_flags += 1

    def _masked_q_action() -> int:
        valid = np.flatnonzero(mask)
        if valid.size == 0:
            return int(A_SECURE_WAIT)
        q_raw = q_net(state.reshape(1, -1)).numpy()[0]
        masked_q = np.where(mask, q_raw, -1e9) if ACTION_MASKING else q_raw
        return int(np.argmax(masked_q))

    if (not training) and EVAL_POLICY_MODE == "q_only_masked":
        _record_decision_source("q_network")
        return _masked_q_action(), False, bool(looping), mask, bias

    if (not training) and EVAL_POLICY_MODE == "heuristic_only":
        valid = np.flatnonzero(mask)
        action_index = int(A_SECURE_WAIT) if valid.size == 0 else int(valid[int(np.argmax(bias[valid]))])
        _record_decision_source("heuristic")
        return action_index, False, bool(looping), mask, bias

    use_shield = False
    if training and SHIELD_ACTIVE:
        triggered = (
            vehicle.steps_since_delivery >= SHIELD_KICKIN_STEPS or
            vehicle.no_progress_streak >= NP_STREAK_THRESHOLD or
            looping
        )

        if vehicle.shield_cooldown_remaining > 0:
            vehicle.shield_cooldown_remaining -= 1

        if vehicle.shield_burst_remaining > 0:
            use_shield = True
            vehicle.shield_burst_remaining -= 1
            if vehicle.shield_burst_remaining == 0:
                vehicle.shield_cooldown_remaining = SHIELD_COOLDOWN_STEPS
        else:
            if (vehicle.shield_cooldown_remaining == 0) and triggered and (random.random() < shield_prob):
                use_shield = True
                vehicle.shield_burst_remaining = max(0, int(SHIELD_BURST_STEPS) - 1)
                if vehicle.shield_burst_remaining == 0:
                    vehicle.shield_cooldown_remaining = SHIELD_COOLDOWN_STEPS

    if use_shield:
        vehicle.shield_moves += 1

    if use_shield:
        valid = np.flatnonzero(mask)
        if valid.size == 0:
            action_index = int(A_SECURE_WAIT)
        else:
            best_local = int(np.argmax(bias[valid]))
            action_index = int(valid[best_local])
        _record_decision_source("shield_emergency")
        return int(action_index), bool(use_shield), bool(looping), mask, bias

    details_for_choice = env_local.get_candidate_details(vehicle, topk=CANDIDATE_TOPK)
    finish_mode = int(env_local.remaining_units()) <= int(FINISH_BIAS_REMAINING_UNITS)
    terminal_mode = TERMINAL_REPAIR_ACTIVE and int(env_local.remaining_units()) <= int(TERMINAL_REPAIR_REMAINING_UNITS)
    terminal_ranked, terminal_wait_cost = _terminal_repair_ranked_actions(env_local, vehicle, mask=mask)

    def _best_valid_candidate(prefer_finish: bool = False):
        choices = []
        for i, det in enumerate(details_for_choice[:int(CANDIDATE_TOPK)]):
            if i >= len(mask) or (not bool(mask[i])):
                continue
            if prefer_finish and (not (bool(det.get('deliver_now', 0.0) > 0.5) or bool(det.get('deliver_rescue', 0.0) > 0.5))):
                continue
            choices.append((float(bias[i]), int(i)))
        if not choices:
            return None
        choices.sort(key=lambda x: (x[0], -x[1]))
        return int(choices[-1][1])

    if terminal_mode and terminal_ranked:
        tr_score, tr_idx, tr_det = terminal_ranked[0]
        if bool(tr_det.get('deliver_now', 0.0) > 0.5) or bool(tr_det.get('deliver_rescue', 0.0) > 0.5) or (float(tr_score) <= float(terminal_wait_cost) + float(TERMINAL_REPAIR_SCALAR_MARGIN)):
            vehicle.finish_overrides += 1
            _record_decision_source("finish_protocol")
            return int(tr_idx), False, bool(looping), mask, bias

    if finish_mode:
        finish_idx = _best_valid_candidate(prefer_finish=True)
        if finish_idx is not None and (float(bias[finish_idx]) >= float(bias[int(A_SECURE_WAIT)]) - float(ROGUE_WAIT_OVERRIDE_MARGIN)):
            vehicle.finish_overrides += 1
            _record_decision_source("finish_protocol")
            return int(finish_idx), False, bool(looping), mask, bias

    if ROGUE_RECOVERY_ACTIVE:
        secure_drift = int(getattr(vehicle, 'secure_travel_steps', 0)) - 2 * int(getattr(vehicle, 'deliveries_made', 0))
        loop_drift = int(getattr(vehicle, 'loop_penalty_steps', 0)) + int(getattr(vehicle, 'revisits', 0)) + int(getattr(vehicle, 'backtracks', 0))
        hard_recover = (
            int(getattr(vehicle, 'no_progress_streak', 0)) >= int(ROGUE_HARD_NO_PROGRESS)
            or secure_drift >= int(ROGUE_HARD_SECURE_THRESHOLD)
            or loop_drift >= int(ROGUE_HARD_LOOP_THRESHOLD)
        )
        if hard_recover:
            if ROGUE_CLEAR_LOCK_ON_RECOVERY:
                _clear_vehicle_lock_state(vehicle)
            vehicle.rogue_force_progress_steps = max(int(getattr(vehicle, 'rogue_force_progress_steps', 0)), int(ROGUE_FORCE_PROGRESS_STEPS))

        if int(getattr(vehicle, 'rogue_force_progress_steps', 0)) > 0:
            force_idx = _best_valid_candidate(prefer_finish=True)
            if force_idx is None:
                force_idx = _best_valid_candidate(prefer_finish=False)
            vehicle.rogue_force_progress_steps = max(0, int(getattr(vehicle, 'rogue_force_progress_steps', 0)) - 1)
            if force_idx is not None and int(force_idx) != int(A_SECURE_WAIT):
                vehicle.recovery_overrides += 1
                _record_decision_source("recovery_emergency")
                return int(force_idx), False, bool(looping), mask, bias

        recover = (
            int(getattr(vehicle, 'no_progress_streak', 0)) >= int(ROGUE_NO_PROGRESS_THRESHOLD)
            or secure_drift >= int(ROGUE_SECURE_TRAVEL_THRESHOLD)
            or loop_drift >= int(ROGUE_LOOP_FLAG_THRESHOLD)
        )
        if recover:
            if ROGUE_CLEAR_LOCK_ON_RECOVERY:
                _clear_vehicle_lock_state(vehicle)
            recover_idx = _best_valid_candidate(prefer_finish=False)
            if recover_idx is not None and int(recover_idx) != int(A_SECURE_WAIT):
                if (float(bias[recover_idx]) >= float(bias[int(A_SECURE_WAIT)]) - float(ROGUE_WAIT_OVERRIDE_MARGIN)) or (int(getattr(vehicle, 'no_progress_streak', 0)) >= 2 * int(ROGUE_NO_PROGRESS_THRESHOLD)):
                    vehicle.recovery_overrides += 1
                    _record_decision_source("recovery_emergency")
                    return int(recover_idx), False, bool(looping), mask, bias

    def _mix_scales():
        ep = max(0, int(episode))
        learn_frac = float(np.clip(1.0 - float(epsilon_local), 0.0, 1.0))
        bias_base = float(ACTION_SCORE_BIAS_SCALE_START + learn_frac * (ACTION_SCORE_BIAS_SCALE_END - ACTION_SCORE_BIAS_SCALE_START))
        q_base = float(ACTION_SCORE_Q_SCALE_START + learn_frac * (ACTION_SCORE_Q_SCALE_END - ACTION_SCORE_Q_SCALE_START))
        if ep < int(ACTION_SCORE_HEURISTIC_ONLY_EPISODES):
            return float(ACTION_SCORE_BIAS_SCALE_WARMUP), float(ACTION_SCORE_Q_SCALE_WARMUP), True
        ramp = float(np.clip((ep - int(ACTION_SCORE_HEURISTIC_ONLY_EPISODES)) / max(1.0, float(ACTION_SCORE_RESIDUAL_RAMP_EPISODES)), 0.0, 1.0))
        bias_scale = float(ACTION_SCORE_BIAS_SCALE_WARMUP * (1.0 - ramp) + bias_base * ramp)
        q_scale = float(ACTION_SCORE_Q_SCALE_WARMUP * (1.0 - ramp) + q_base * ramp)
        return float(bias_scale), float(q_scale), False

    def _exploit_pick():
        valid = np.flatnonzero(mask)
        if valid.size == 0:
            return int(A_SECURE_WAIT), mask, bias

        if training and TRAIN_POLICY_MODE == "q_primary_emergency":
            return int(_masked_q_action()), mask, bias

        bias_best = int(valid[int(np.argmax(bias[valid]))])
        bias_scale, q_scale, heuristic_only = _mix_scales()
        if heuristic_only:
            return int(bias_best), mask, bias

        q_raw = q_net(state.reshape(1, -1)).numpy()[0]
        q_center = q_raw - float(np.mean(q_raw))
        combined = (q_scale * q_center) + (bias_scale * bias)
        if ACTION_MASKING:
            combined = np.where(mask, combined, -1e9)

        best_idx = int(np.argmax(combined))
        if HEURISTIC_FALLBACK_ACTIVE:
            ranked = np.sort(np.asarray(combined[valid], dtype=np.float64))
            margin = float(ranked[-1] - ranked[-2]) if ranked.size >= 2 else 1e9
            q_spread = float(np.max(q_center[valid]) - np.min(q_center[valid])) if valid.size >= 2 else 0.0
            fallback = False
            if best_idx != bias_best:
                if (margin < float(ACTION_SCORE_CONFIDENCE_MARGIN)) or (q_spread < float(ACTION_SCORE_CONFIDENCE_MARGIN)):
                    fallback = True
                if looping or (getattr(vehicle, "no_progress_streak", 0) >= max(2, int(NP_STREAK_THRESHOLD // 2))):
                    fallback = True
            if (best_idx == int(A_SECURE_WAIT)) and (bias[bias_best] >= (bias[int(A_SECURE_WAIT)] - float(ACTION_SCORE_HEURISTIC_OVERRIDE_MARGIN))):
                fallback = True
            if fallback:
                best_idx = int(bias_best)

        return int(best_idx), mask, bias

    def _deploy_pick():
        valid = np.flatnonzero(mask)
        if valid.size == 0:
            return int(A_SECURE_WAIT), mask, bias
        bias_best = int(valid[int(np.argmax(bias[valid]))])
        q_raw = q_net(state.reshape(1, -1)).numpy()[0]
        q_center = q_raw - float(np.mean(q_raw))
        combined = bias + float(DEPLOY_Q_SCALE) * q_center
        if ACTION_MASKING:
            combined = np.where(mask, combined, -1e9)
        best_idx = int(np.argmax(combined))
        if terminal_mode and terminal_ranked:
            tr_score, tr_idx, _tr_det = terminal_ranked[0]
            if float(tr_score) <= float(terminal_wait_cost) + float(DEPLOY_WAIT_DELIVERABLE_MARGIN):
                return int(tr_idx), mask, bias
        if best_idx != bias_best:
            if float(combined[best_idx]) <= float(combined[bias_best]) + float(DEPLOY_HEURISTIC_OVERRIDE_MARGIN):
                best_idx = int(bias_best)
        if (best_idx == int(A_SECURE_WAIT)) and (bias[bias_best] >= (bias[int(A_SECURE_WAIT)] - float(DEPLOY_HEURISTIC_OVERRIDE_MARGIN))):
            best_idx = int(bias_best)
        return int(best_idx), mask, bias

    if (not training) and EVAL_POLICY_MODE == "q_primary_emergency":
        _record_decision_source("q_network")
        return _masked_q_action(), False, bool(looping), mask, bias

    if (not training) and DEPLOY_HEURISTIC_DOMINANT:
        action_index, mask, bias = _deploy_pick()
        _record_decision_source("hybrid")
        return int(action_index), False, bool(looping), mask, bias

    do_explore = training and (random.random() <= float(epsilon_local))
    if not do_explore:
        action_index, mask, bias = _exploit_pick()
        _record_decision_source("hybrid" if not training else "q_network")
        return int(action_index), False, bool(looping), mask, bias

    valid = np.flatnonzero(mask)
    if valid.size == 0:
        _record_decision_source("exploration")
        return int(A_SECURE_WAIT), False, bool(looping), mask, bias

    if GUIDED_EXPLORATION:
        scores = np.asarray(bias[valid], dtype=np.float64)
        scores = scores - np.max(scores)
        probs = np.exp(scores)
        if not np.all(np.isfinite(probs)) or float(np.sum(probs)) <= 1e-12:
            probs = np.ones_like(probs, dtype=np.float64)
        probs = probs / np.sum(probs)
        probs = 0.78 * probs + 0.22 * (np.ones_like(probs) / float(len(probs)))
        probs = probs / np.sum(probs)
        action_index = int(np.random.choice(valid, p=probs))
    else:
        action_index = int(valid[int(np.random.randint(0, len(valid)))])

    _record_decision_source("exploration")
    return int(action_index), False, bool(looping), mask, bias

def run_episode_rollout(
    env_local: Environment,
    vehicles_local: list,
    q_net: tf.keras.Model,
    epsilon_local: float,
    max_steps: int,
    training: bool,
    episode: int = 0,
    shield_prob: float = 0.0,
):
    env_local.reset()
    for vv in vehicles_local:
        vv.reset()
        vv.no_active_reactivations = 0

    total_r = 0.0
    done_flag = False
    last_loss_local = None
    dispatch_events = 0
    stop_reason = "max_steps"

    while dispatch_events < int(max_steps):
        idx = select_next_active_vehicle(env_local, vehicles_local)
        if idx is None:
            idx = recover_vehicle_when_no_active(env_local, vehicles_local)
            if idx is None:
                stop_reason = "no_active"
                break

        vehicle = vehicles_local[int(idx)]
        state = env_local.get_state_from_external(vehicle)
        action_index, use_shield, looping, mask, bias = choose_action_for_vehicle(
            env_local, vehicle, state, q_net, epsilon_local=epsilon_local, training=training, episode=int(episode), shield_prob=shield_prob
        )

        next_state, reward, done_flag, done_vehicle = env_local.step(vehicle, int(action_index))
        total_r += float(reward)
        dispatch_events += 1

        if training:
            terminal = float(done_flag or done_vehicle)
            if terminal >= 0.5:
                next_action_mask = np.ones(int(MAX_ACTIONS), dtype=np.bool_)
            else:
                next_action_mask = np.asarray(env_local.action_mask(vehicle), dtype=np.bool_).copy()
                if not np.any(next_action_mask):
                    next_action_mask[int(A_SECURE_WAIT)] = True
            memory_buffer.append(
                experience(
                    state,
                    int(action_index),
                    float(reward),
                    next_state,
                    terminal,
                    next_action_mask,
                )
            )

            update = utils.check_update_conditions(dispatch_events, NUM_STEPS_FOR_UPDATE, memory_buffer)
            if update and (len(memory_buffer) >= int(MIN_REPLAY_SIZE_FOR_LEARNING)):
                try:
                    raw_experiences = sample_masked_experiences(memory_buffer, BATCH_SIZE)
                    experiences = normalize_experiences(raw_experiences)

                    _loss = agent_learn(experiences, GAMMA)
                    last_loss_local = float(np.asarray(_loss).reshape(()))
                    global learn_step
                    learn_step += 1
                    if learn_step % TARGET_UPDATE_PERIOD == 0:
                        target_q_network.set_weights(q_network.get_weights())
                except Exception as _e:
                    if SAFE_TRAINING_MODE:
                        print(f"[WARN] agent_learn() failed; update skipped. err={repr(_e)}")
                        if CLEAR_BUFFER_ON_TRAIN_ERROR:
                            print("[WARN] Clearing replay buffer due to training error")
                            memory_buffer.clear()
                        last_loss_local = None
                    else:
                        raise

        if LOG_LEVEL >= 2:
            if (episode < LOG_FIRST_N_EPISODES) or (episode % EP_LOG_EVERY == 0):
                if dispatch_events % STEP_LOG_EVERY == 0:
                    rem_units = int(sum(env_local.demands.values()))
                    uniq = len(set(vehicle.visited_locations[-LOOP_WINDOW:]))
                    kpd_v = (vehicle.total_distance / 1000.0) / vehicle.deliveries_made if vehicle.deliveries_made > 0 else None
                    kpd_v_str = f"{kpd_v:.2f}" if kpd_v is not None else "NA"
                    print(
                        f"[HB] ep={episode} evt={dispatch_events} veh={idx} "
                        f"loc={vehicle.current_location} tw={vehicle.current_time_window} cap={vehicle.capacity} "
                        f"dist={vehicle.total_distance/1000.0:.2f}km kpd={kpd_v_str} rem={rem_units} del={vehicle.deliveries_made} "
                        f"act={action_index} sh={int(use_shield)} loop={int(looping)} np={vehicle.no_progress_streak} uniq{LOOP_WINDOW}={uniq}",
                        flush=True
                    )

        if done_flag:
            stop_reason = "done"
            break

    return float(total_r), bool(done_flag), last_loss_local, int(dispatch_events), str(stop_reason)


def run_deterministic_suite(
    env_local: Environment,
    vehicles_local: list,
    q_net: tf.keras.Model,
    n_runs: int = 10,
    seed0: int = 12345,
    max_steps: int = 3500,
    episode_eval: int = 0,
):
    """Deterministik mini test suite (event-driven parallel dispatch uyumlu)."""
    for key in list(DECISION_SOURCE_COUNTS):
        DECISION_SOURCE_COUNTS[key] = 0
    np_state = np.random.get_state()
    py_state = random.getstate()

    rows = []
    for i in range(int(n_runs)):
        seed = int(seed0) + int(i)
        np.random.seed(seed)
        random.seed(seed)

        total_r, done_suite, _loss_suite, _steps_suite, _reason = run_episode_rollout(
            env_local=env_local,
            vehicles_local=vehicles_local,
            q_net=q_net,
            epsilon_local=0.0,
            max_steps=int(max_steps),
            training=False,
            episode=int(episode_eval),
            shield_prob=0.0,
        )

        rem_units = int(sum(env_local.demands.values()))
        delivered_units = int(TOTAL_REQUIRED_UNITS - rem_units)
        dist_km = float(sum(vv.total_distance for vv in vehicles_local) / 1000.0)
        makespan = float(max([vv.total_duration for vv in vehicles_local] + [0.0]))
        duration_total = float(sum(vv.total_duration for vv in vehicles_local))
        miss_total = int(sum(vv.tw_misses for vv in vehicles_local))
        miss_early = int(sum(getattr(vv, "tw_misses_early", 0) for vv in vehicles_local))
        miss_late = int(sum(getattr(vv, "tw_misses_late", 0) for vv in vehicles_local))
        secure_steps = float(sum(getattr(vv, "secure_travel_steps", 0.0) for vv in vehicles_local))
        risk_total = float(max(0.0, -sum(float(getattr(vv, "sum_reward_unsecure", 0.0)) for vv in vehicles_local)))
        kpd_val = (dist_km / delivered_units) if delivered_units > 0 else float("nan")
        delivered_solved = int(rem_units == 0)
        returned_count = int(len(env_local.returned_vehicle_ids))
        eod_violations = int(sum(getattr(vv, "end_of_day_terminations", 0) for vv in vehicles_local))
        # "done_suite" is intentionally part of operational feasibility: the
        # environment only sets done after every demand is served and every
        # vehicle has returned to the depot.  Merely emptying demand is not a
        # deployable solution.
        operational_feasible = int(
            delivered_solved
            and bool(done_suite)
            and returned_count >= int(env_local.n_vehicles)
            and eod_violations == 0
        )
        strict_feasible = int(operational_feasible and miss_total == 0)
        rows.append(
            (
                total_r, delivered_units, miss_total, dist_km, kpd_val,
                delivered_solved, makespan, returned_count, eod_violations,
                operational_feasible, strict_feasible,
                duration_total, miss_early, miss_late, secure_steps, risk_total,
            )
        )

    np.random.set_state(np_state)
    random.setstate(py_state)

    arr = np.asarray(rows, dtype=np.float64)
    out = {
        "policy_mode": str(EVAL_POLICY_MODE),
        "n": int(arr.shape[0]),
        # Backward-compatible "solved" now means deployable/operationally
        # feasible, not just that the demand dictionary happened to be empty.
        "solved": int(np.nansum(arr[:, 9])),
        "delivered_solved": int(np.nansum(arr[:, 5])),
        "operational_feasible": int(np.nansum(arr[:, 9])),
        "strict_feasible": int(np.nansum(arr[:, 10])),
        "mean_returned": float(np.nanmean(arr[:, 7])),
        "eod_clean": int(np.nansum(arr[:, 8] == 0)),
        "mean_R": float(np.nanmean(arr[:, 0])),
        "mean_del": float(np.nanmean(arr[:, 1])),
        "mean_miss": float(np.nanmean(arr[:, 2])),
        "mean_dist_km": float(np.nanmean(arr[:, 3])),
        "mean_kpd": float(np.nanmean(arr[:, 4])) if np.any(np.isfinite(arr[:, 4])) else float("nan"),
        "mean_makespan": float(np.nanmean(arr[:, 6])),
        "mean_duration_total": float(np.nanmean(arr[:, 11])),
        "mean_tw_early": float(np.nanmean(arr[:, 12])),
        "mean_tw_late": float(np.nanmean(arr[:, 13])),
        "mean_secure_steps": float(np.nanmean(arr[:, 14])),
        "mean_risk": float(np.nanmean(arr[:, 15])),
        "p50_del": float(np.nanpercentile(arr[:, 1], 50)),
        "p10_del": float(np.nanpercentile(arr[:, 1], 10)),
        "p90_del": float(np.nanpercentile(arr[:, 1], 90)),
    }
    decision_total = max(1, int(DECISION_SOURCE_COUNTS.get("total", 0)))
    for source in (
        "q_network", "heuristic", "hybrid", "emergency", "finish_protocol",
        "recovery_emergency", "shield_emergency", "exploration",
    ):
        count = int(DECISION_SOURCE_COUNTS.get(source, 0))
        out[f"decision_{source}"] = count
        out[f"decision_{source}_ratio"] = float(count / decision_total)
    out["decision_total"] = int(DECISION_SOURCE_COUNTS.get("total", 0))
    normal_denominator = max(1, decision_total - int(DECISION_SOURCE_COUNTS.get("finish_protocol", 0)))
    out["decision_q_normal_ratio"] = float(int(DECISION_SOURCE_COUNTS.get("q_network", 0)) / normal_denominator)
    out["last_seed"] = int(seed0) + int(n_runs) - 1
    out["last_routes"] = [[int(node) for node in vehicle.visited_locations] for vehicle in vehicles_local]
    return out


def _run_eval_only_if_requested() -> None:
    """Load one model and evaluate profiles/custom preference weights, then exit."""
    if os.environ.get("CIT_EVAL_ONLY", "0") != "1":
        return

    weights_path = Path(os.environ["CIT_EVAL_WEIGHTS"]).expanduser().resolve()
    n_runs = int(os.environ.get("CIT_EVAL_RUNS", "30"))
    seed0 = int(os.environ.get("CIT_EVAL_SEED", "12345"))
    max_steps = int(os.environ.get("CIT_EVAL_MAX_STEPS", "6000"))
    episode_eval = int(os.environ.get("CIT_EVAL_EPISODE", "1460"))
    output_path = Path(os.environ.get("CIT_EVAL_OUTPUT", f"eval_{VERSION}.json")).expanduser().resolve()

    if not weights_path.is_file():
        raise FileNotFoundError(f"Evaluation weights not found: {weights_path}")
    q_network.load_weights(str(weights_path))

    candidates_value = os.environ.get("CIT_EVAL_CANDIDATES_FILE", "").strip()
    if candidates_value:
        candidates_path = Path(candidates_value).expanduser().resolve()
        candidates = json.loads(candidates_path.read_text(encoding="utf-8"))
        if not isinstance(candidates, list) or not candidates:
            raise ValueError("CIT_EVAL_CANDIDATES_FILE must contain a non-empty JSON list")
    else:
        profile = os.environ.get("CIT_EVAL_PROFILE", "balanced").strip() or "balanced"
        candidates = [{"name": profile, "profile": profile}]

    results = []
    for index, candidate in enumerate(candidates):
        if not isinstance(candidate, dict):
            raise TypeError(f"Evaluation candidate #{index} must be a JSON object")
        name = str(candidate.get("name") or candidate.get("profile") or f"candidate_{index:04d}")
        custom_weights = candidate.get("weights")
        if custom_weights is not None:
            values = dict(PREFERENCE_PROFILE_WEIGHTS["balanced"])
            for key, value in dict(custom_weights).items():
                if key not in values:
                    raise KeyError(f"Unknown objective weight for {name}: {key}")
                values[key] = float(value)
            temp_profile = f"__eval_{index:04d}"
            PREFERENCE_PROFILE_WEIGHTS[temp_profile] = values
            applied = apply_preference_profile(temp_profile, jitter=False)
        else:
            profile = str(candidate.get("profile") or name)
            applied = apply_preference_profile(profile, jitter=False)

        summary = run_deterministic_suite(
            env_local=env,
            vehicles_local=vehicles,
            q_net=q_network,
            n_runs=n_runs,
            seed0=seed0,
            max_steps=max_steps,
            episode_eval=episode_eval,
        )
        results.append({
            "name": name,
            "preference_weights": {key: float(applied[key]) for key in OBJECTIVE_WEIGHT_ORDER},
            **summary,
        })
        print(
            f"[EVAL-ONLY] candidate={name} solved={summary['solved']}/{summary['n']} "
            f"miss={summary['mean_miss']:.3f} dist={summary['mean_dist_km']:.3f} "
            f"duration={summary['mean_duration_total']:.3f} risk={summary['mean_risk']:.6f}",
            flush=True,
        )

    apply_preference_profile("balanced", jitter=False)
    payload = {
        "version": VERSION,
        "weights_path": str(weights_path),
        "seed0": seed0,
        "n_runs": n_runs,
        "max_steps": max_steps,
        "episode_eval": episode_eval,
        "results": results,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[EVAL-ONLY] {json.dumps(payload, ensure_ascii=False)}", flush=True)
    raise SystemExit(0)


_run_eval_only_if_requested()


def _optimizer_current_lr(optimizer_obj) -> float:
    try:
        return float(tf.keras.backend.get_value(optimizer_obj.learning_rate))
    except Exception:
        try:
            return float(optimizer_obj.learning_rate.numpy())
        except Exception:
            try:
                return float(optimizer_obj.learning_rate)
            except Exception:
                return float(ALPHA)


def _optimizer_set_lr(optimizer_obj, value: float) -> float:
    val = float(value)
    try:
        optimizer_obj.learning_rate.assign(val)
        return float(tf.keras.backend.get_value(optimizer_obj.learning_rate))
    except Exception:
        try:
            tf.keras.backend.set_value(optimizer_obj.learning_rate, val)
            return float(tf.keras.backend.get_value(optimizer_obj.learning_rate))
        except Exception:
            try:
                optimizer_obj.learning_rate = val
                return float(val)
            except Exception:
                return _optimizer_current_lr(optimizer_obj)


def summarize_episode_objective_costs(env_local: Environment, vehicles_local: list, steps_total: int, makespan_value: float | None = None) -> dict:
    rem_units = int(sum(env_local.demands.values()))
    tw_early = int(sum(getattr(v, 'tw_misses_early', 0) for v in vehicles_local))
    tw_late = int(sum(getattr(v, 'tw_misses_late', 0) for v in vehicles_local))
    ot_total = float(sum(getattr(v, 'overtime_minutes', 0.0) for v in vehicles_local))
    rte_total = float(sum(getattr(v, 'return_extension_minutes', 0.0) for v in vehicles_local))
    secure_travel_total = float(sum(getattr(v, 'secure_travel_steps', 0.0) for v in vehicles_local))
    total_distance_km = float(sum(getattr(v, 'total_distance', 0.0) for v in vehicles_local) / 1000.0)
    total_duration = float(sum(getattr(v, 'total_duration', 0.0) for v in vehicles_local))
    if makespan_value is None:
        makespan_value = float(max([float(getattr(v, 'total_duration', 0.0)) for v in vehicles_local] + [0.0]))
    risk_mag = float(max(0.0, -sum(float(getattr(v, 'sum_reward_unsecure', 0.0)) for v in vehicles_local)))
    risk_scale = max(1e-6, float(getattr(env_local, 'risk_scale', 1.0)))
    backtracks = float(sum(getattr(v, 'backtracks', 0) for v in vehicles_local))
    revisits = float(sum(getattr(v, 'revisits', 0) for v in vehicles_local))
    loop_pen = float(sum(getattr(v, 'loop_penalty_steps', 0) for v in vehicles_local))
    switches = float(sum(getattr(v, 'target_switches', 0) for v in vehicles_local))
    steps_denom = max(1.0, float(steps_total))

    terms = {
        'undelivered': float(rem_units) / max(1.0, float(TOTAL_REQUIRED_UNITS)),
        'early': float(tw_early) / max(1.0, float(TOTAL_REQUIRED_UNITS)),
        'late': float(tw_late) / max(1.0, float(TOTAL_REQUIRED_UNITS)),
        'service_over': float(ot_total) / max(1.0, float(WINDOW_SIZE_MIN)),
        'return_over': float(rte_total) / max(1.0, float(WINDOW_SIZE_MIN)),
        'secure': float(secure_travel_total) / steps_denom,
        'distance': float(total_distance_km) / 100.0,
        'duration': float(total_duration) / max(1.0, float(len(vehicles_local)) * float(ABSOLUTE_MAX_ROUTE_DURATION_MIN)),
        'risk': float(risk_mag) / (steps_denom * risk_scale),
        'loop': float(backtracks + revisits + loop_pen) / steps_denom,
        'reservation': float(switches) / max(1.0, float(TOTAL_REQUIRED_UNITS)),
        'makespan': float(makespan_value) / max(1.0, float(ABSOLUTE_MAX_ROUTE_DURATION_MIN)),
    }
    norm_terms = normalize_cost_terms_dict(terms)
    contributions = weighted_objective_contributions(terms)
    out = {f'cost_{k}': float(norm_terms.get(k, 0.0)) for k in OBJECTIVE_WEIGHT_ORDER}
    out.update({f'contrib_{k}': float(contributions.get(k, 0.0)) for k in OBJECTIVE_WEIGHT_ORDER})
    out['scalarized_total_cost'] = float(sum(contributions.values()))
    return out



# REV15 Pareto archive compares normalized component costs only. Feasibility is
# a prerequisite and is intentionally not traded against a soft objective.
PARETO_COST_KEYS = tuple(f"cost_{k}" for k in OBJECTIVE_WEIGHT_ORDER if k != "undelivered")
_PARETO_PROFILE_BEST_COSTS = {}


def _pareto_dominates(left: dict, right: dict, tol: float = 1e-9) -> bool:
    le_all = all(float(left[k]) <= float(right[k]) + tol for k in PARETO_COST_KEYS)
    lt_any = any(float(left[k]) < float(right[k]) - tol for k in PARETO_COST_KEYS)
    return bool(le_all and lt_any)


def _pareto_archive_file() -> Path:
    base = Path(RUN_DIR) if RUN_DIR is not None else Path(f"pareto_{VERSION}")
    base.mkdir(parents=True, exist_ok=True)
    return base / "pareto_archive.json"


def _load_pareto_archive() -> list:
    path = _pareto_archive_file()
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return list(data) if isinstance(data, list) else []
    except Exception as exc:
        print(f"[PARETO][WARN] archive read failed: {exc}", flush=True)
        return []


def _update_pareto_archive(record: dict) -> tuple[bool, int]:
    if not bool(record.get("operational_feasible", False)):
        return False, len(_load_pareto_archive())
    archive = _load_pareto_archive()
    if any(_pareto_dominates(old, record) for old in archive):
        return False, len(archive)
    kept = [old for old in archive if not _pareto_dominates(record, old)]
    duplicate = any(
        all(abs(float(old[k]) - float(record[k])) <= 1e-9 for k in PARETO_COST_KEYS)
        and str(old.get("preference_profile")) == str(record.get("preference_profile"))
        for old in kept
    )
    if not duplicate:
        kept.append(dict(record))
    kept.sort(key=lambda row: (int(row.get("episode", -1)), str(row.get("preference_profile", ""))))
    _pareto_archive_file().write_text(json.dumps(kept, ensure_ascii=False, indent=2), encoding="utf-8")
    return (not duplicate), len(kept)


def _maybe_save_preference_checkpoint(profile: str, episode: int, record: dict, q_net: tf.keras.Model) -> bool:
    if not bool(record.get("operational_feasible", False)):
        return False
    score = float(record.get("scalarized_total_cost", float("inf")))
    old = _PARETO_PROFILE_BEST_COSTS.get(str(profile))
    if old is not None and score >= float(old) - 1e-9:
        return False
    _PARETO_PROFILE_BEST_COSTS[str(profile)] = score
    payload = dict(record)
    payload["score"] = score
    return _save_best_eval_checkpoint(f"preference_{profile}", int(episode), payload, q_net)


def run_preference_pareto_sweep(env_local, vehicles_local, q_net, episode_eval: int, max_steps: int) -> list:
    """Evaluate every discrete preference on the same seeded scenario."""
    records = []
    py_state = random.getstate()
    np_state = np.random.get_state()
    common_seed = int(GLOBAL_SEED + 1000003 + int(episode_eval))
    try:
        for profile in PREFERENCE_PROFILE_WEIGHTS:
            random.seed(common_seed)
            np.random.seed(common_seed)
            weights = apply_preference_profile(str(profile), jitter=False)
            total_r, done, _loss, steps, reason = run_episode_rollout(
                env_local=env_local, vehicles_local=vehicles_local, q_net=q_net,
                epsilon_local=0.0, max_steps=int(max_steps), training=False,
                episode=int(episode_eval), shield_prob=0.0,
            )
            rem = int(sum(env_local.demands.values()))
            delivered = int(TOTAL_REQUIRED_UNITS - rem)
            returned = int(len(env_local.returned_vehicle_ids))
            eod = int(sum(getattr(v, "end_of_day_terminations", 0) for v in vehicles_local))
            makespan = float(max([float(v.total_duration) for v in vehicles_local] + [0.0]))
            costs = summarize_episode_objective_costs(env_local, vehicles_local, int(steps), makespan)
            feasible = bool(done and rem <= 0 and delivered >= int(TOTAL_REQUIRED_UNITS) and returned >= int(env_local.n_vehicles) and eod <= 0 and str(reason) == "done")
            record = {
                "episode": int(episode_eval), "preference_profile": str(profile),
                "preference_weights": {k: float(weights[k]) for k in OBJECTIVE_WEIGHT_ORDER},
                "operational_feasible": feasible, "reason": str(reason), "reward": float(total_r),
                "delivered": delivered, "remaining": rem, "returned": returned,
                "eod_violations": eod, "steps": int(steps),
                "tw_miss": int(sum(getattr(v, "tw_misses", 0) for v in vehicles_local)),
                "distance_km": float(sum(float(v.total_distance) for v in vehicles_local) / 1000.0),
                "duration_total": float(sum(float(v.total_duration) for v in vehicles_local)),
                "makespan": makespan, **{k: float(v) for k, v in costs.items()},
            }
            added, front_size = _update_pareto_archive(record)
            saved = _maybe_save_preference_checkpoint(str(profile), int(episode_eval), record, q_net)
            print(f"[PARETO] ep={episode_eval} profile={profile} feasible={int(feasible)} miss={record['tw_miss']} dist={record['distance_km']:.2f} risk={record['cost_risk']:.3f} cost={record['scalarized_total_cost']:.3f} front={front_size} added={int(added)} ckpt={int(saved)}", flush=True)
            records.append(record)
    finally:
        random.setstate(py_state)
        np.random.set_state(np_state)
        apply_preference_profile("balanced", jitter=False)
    return records
def _best_models_dir() -> Path:
    if RUN_DIR is not None:
        base = Path(RUN_DIR)
    else:
        base = Path(f'best_checkpoints_{VERSION}')
    out = base / 'best_checkpoints'
    out.mkdir(parents=True, exist_ok=True)
    return out


def _save_best_eval_checkpoint(tag: str, episode: int, payload: dict, q_net: tf.keras.Model) -> bool:
    if not BEST_CHECKPOINTS_ACTIVE:
        return False
    out_dir = _best_models_dir()
    # A REV12 network is about 28 MB. Keep headroom for HDF5 temporary growth,
    # metadata, and the periodic TensorFlow checkpoint.
    if not _has_enough_free_mb(out_dir, 128.0):
        print(f'[BEST][WARN] skipped: insufficient disk space. tag={tag} ep={episode} need_free_mb=128', flush=True)
        return False
    weights_path = out_dir / f'{tag}_{VERSION}.weights.h5'
    meta_path = out_dir / f'{tag}_{VERSION}.json'
    try:
        q_net.save_weights(weights_path)
    except Exception as e:
        print(f'[BEST][WARN] weights save failed. tag={tag} ep={episode} err={e}', flush=True)
        return False
    try:
        with open(meta_path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f'[BEST][WARN] meta save failed. tag={tag} ep={episode} err={e}', flush=True)
    print(f'[BEST] saved tag={tag} ep={episode} -> {weights_path}', flush=True)
    return True


def _default_control_state() -> dict:
    return {
        'best_fullsolve_score': None,
        'best_balanced_score': None,
        'best_tw_score': None,
        'best_suite_score': None,
        'best_deploy_score': None,
        'best_fullsolve_episode': None,
        'best_balanced_episode': None,
        'best_tw_episode': None,
        'best_suite_episode': None,
        'best_deploy_episode': None,
        'eval_no_improve_count': 0,
        'lr_decay_count': 0,
        'last_suite_summary': None,
        'stop_training_requested': False,
        'current_lr': float(ALPHA),
        'curriculum_phase': 'feasibility' if GATED_CURRICULUM_ACTIVE else 'optimization',
        'curriculum_gate_streak': 0,
        'early_stop_phase': 'feasibility' if GATED_CURRICULUM_ACTIVE else 'optimization',
    }


def _update_curriculum_gate(control_state: dict, suite_summary: dict | None) -> None:
    if not GATED_CURRICULUM_ACTIVE or suite_summary is None:
        return
    n_suite = max(1, int(suite_summary.get("n", 0)))
    feasible_ratio = float(suite_summary.get("operational_feasible", suite_summary.get("solved", 0))) / n_suite
    phase = str(control_state.get("curriculum_phase", "feasibility"))
    gate_ok = feasible_ratio >= float(CURRICULUM_FEASIBLE_RATIO)
    if phase == "time_window":
        gate_ok = gate_ok and float(suite_summary.get("mean_miss", float("inf"))) <= float(CURRICULUM_TW_MEAN_MAX)
    if phase == "optimization":
        return
    streak = int(control_state.get("curriculum_gate_streak", 0))
    streak = streak + 1 if gate_ok else 0
    control_state["curriculum_gate_streak"] = streak
    if streak < int(CURRICULUM_GATE_STREAK):
        return
    next_phase = "time_window" if phase == "feasibility" else "optimization"
    control_state["curriculum_phase"] = next_phase
    control_state["curriculum_gate_streak"] = 0
    # Scores from a previous objective phase must not consume the patience of
    # the next phase.  Checkpoint records are retained; only control patience
    # is reset.
    control_state["eval_no_improve_count"] = 0
    control_state["early_stop_phase"] = next_phase
    print(
        f"[CURRICULUM] gate passed: {phase} -> {next_phase}; "
        f"operational={feasible_ratio:.3f} mean_tw={float(suite_summary.get('mean_miss', float('nan'))):.3f}",
        flush=True,
    )


def _balanced_eval_score(test_metrics: dict, suite_summary: dict | None = None) -> float:
    """Select only operationally feasible models, then compare shaped reward.

    TW, distance, overtime and return-over preferences already contribute through
    the configured reward/objective weights; they are not extra hard gates here.
    """
    if not _operational_test_feasible(test_metrics):
        return float("-inf")
    return float(test_metrics.get("avg_reward", float("-inf")))


def _operational_test_feasible(test_metrics: dict) -> bool:
    """The only model-selection hard gate: 34/34 delivery and 5/5 return."""
    return bool(
        int(test_metrics.get('avg_delivered', 0)) >= int(TOTAL_REQUIRED_UNITS)
        and int(test_metrics.get('avg_remaining', 0)) <= 0
        and int(test_metrics.get('avg_returned', 0)) >= int(n_vehicles)
        and int(test_metrics.get('avg_eod_violations', 0)) <= 0
        and str(test_metrics.get('reason', '')) == 'done'
    )


def _fullsolve_eval_score(test_metrics: dict) -> float | None:
    if not _operational_test_feasible(test_metrics):
        return None
    return float(test_metrics.get("avg_reward", float("-inf")))


def _tw_eval_score(test_metrics: dict) -> float | None:
    # Kept as a compatibility checkpoint tag; selection uses the same shaped
    # reward instead of imposing TW as another lexicographic hard constraint.
    if not _operational_test_feasible(test_metrics):
        return None
    return float(test_metrics.get("avg_reward", float("-inf")))


def _suite_eval_score(test_metrics: dict, suite_summary: dict | None) -> float | None:
    if suite_summary is None or float(suite_summary.get('n', 0)) <= 0:
        return None
    if not _operational_test_feasible(test_metrics):
        return None
    if suite_summary is not None and float(suite_summary.get('n', 0)) > 0:
        n_suite = int(suite_summary.get('n', 0))
        if int(suite_summary.get('operational_feasible', 0)) < n_suite:
            return None
    return float(test_metrics.get("avg_reward", float("-inf")))


def _deploy_eval_score(test_metrics: dict, suite_summary: dict | None) -> float:
    if not _operational_test_feasible(test_metrics):
        return float("-inf")
    if suite_summary is not None and float(suite_summary.get('n', 0)) > 0:
        n_suite = int(suite_summary.get('n', 0))
        if int(suite_summary.get('operational_feasible', 0)) < n_suite:
            return float("-inf")
    return float(test_metrics.get("avg_reward", float("-inf")))
def _maybe_update_best_checkpoints(control_state: dict, episode: int, test_metrics: dict, suite_summary: dict | None, q_net: tf.keras.Model) -> tuple[bool, float]:
    improved = False
    balanced_score = float(_balanced_eval_score(test_metrics, suite_summary))
    payload = dict(test_metrics)
    if suite_summary is not None:
        payload['suite'] = dict(suite_summary)

    # Never save/rank an infeasible policy as a best model. Soft objectives
    # and reward are compared only after 34/34 delivery and 5/5 return.
    if not _operational_test_feasible(test_metrics):
        return False, float("-inf")

    fullsolve_score = _fullsolve_eval_score(test_metrics)
    if fullsolve_score is not None and (control_state.get('best_fullsolve_score') is None or fullsolve_score > float(control_state['best_fullsolve_score'])):
        control_state['best_fullsolve_score'] = float(fullsolve_score)
        control_state['best_fullsolve_episode'] = int(episode)
        payload_full = dict(payload)
        payload_full['score'] = float(fullsolve_score)
        payload_full['tag'] = 'best_fullsolve'
        # Metadata/state is tracked, but the canonical weight file is best_balanced.
        improved = True

    if control_state.get('best_balanced_score') is None or balanced_score > float(control_state['best_balanced_score']):
        control_state['best_balanced_score'] = float(balanced_score)
        control_state['best_balanced_episode'] = int(episode)
        payload_bal = dict(payload)
        payload_bal['score'] = float(balanced_score)
        payload_bal['tag'] = 'best_balanced'
        _save_best_eval_checkpoint('best_balanced', int(episode), payload_bal, q_net)
        improved = True

    tw_score = _tw_eval_score(test_metrics)
    if tw_score is not None and (control_state.get('best_tw_score') is None or tw_score > float(control_state['best_tw_score'])):
        control_state['best_tw_score'] = float(tw_score)
        control_state['best_tw_episode'] = int(episode)
        payload_tw = dict(payload)
        payload_tw['score'] = float(tw_score)
        payload_tw['tag'] = 'best_tw'
        # TW is a soft objective in the shaped reward; avoid duplicate weights.
        improved = True

    suite_score = _suite_eval_score(test_metrics, suite_summary)
    if suite_score is not None and suite_summary is not None:
        control_state['last_suite_summary'] = dict(suite_summary)
        if control_state.get('best_suite_score') is None or suite_score > float(control_state['best_suite_score']):
            control_state['best_suite_score'] = float(suite_score)
            control_state['best_suite_episode'] = int(episode)
            payload_suite = dict(payload)
            payload_suite['score'] = float(suite_score)
            payload_suite['tag'] = 'best_suite'
            # Suite quality participates in selection without duplicating weights.
            improved = True

    deploy_score = float(_deploy_eval_score(test_metrics, suite_summary))
    if control_state.get('best_deploy_score') is None or deploy_score > float(control_state['best_deploy_score']):
        control_state['best_deploy_score'] = float(deploy_score)
        control_state['best_deploy_episode'] = int(episode)
        payload_dep = dict(payload)
        payload_dep['score'] = float(deploy_score)
        payload_dep['tag'] = 'best_deploy'
        # Deployment score is tracked; best_balanced is the canonical weight file.
        improved = True

    return bool(improved), float(balanced_score)


def _maybe_apply_lr_decay_and_early_stop(control_state: dict, episode: int, balanced_score: float, improved: bool, optimizer_obj) -> tuple[bool, float]:
    curriculum_phase = str(control_state.get("curriculum_phase", "optimization"))
    tracked_phase = str(control_state.get("early_stop_phase", ""))
    if tracked_phase != curriculum_phase:
        control_state["eval_no_improve_count"] = 0
        control_state["early_stop_phase"] = curriculum_phase
        print(
            f"[CTRL] patience reset for curriculum phase={curriculum_phase} at ep={episode}",
            flush=True,
        )

    # Feasibility and TW are mandatory constraint-learning phases.  Lack of
    # improvement here may lower LR, but must never terminate training before
    # the optimisation gate has been reached.
    allow_early_stop = (not GATED_CURRICULUM_ACTIVE) or curriculum_phase == "optimization"

    if improved:
        control_state['eval_no_improve_count'] = 0
        return False, _optimizer_current_lr(optimizer_obj)

    control_state['eval_no_improve_count'] = int(control_state.get('eval_no_improve_count', 0)) + 1
    n_bad = int(control_state['eval_no_improve_count'])
    cur_lr = _optimizer_current_lr(optimizer_obj)

    if LR_DECAY_ACTIVE and (n_bad % int(LR_DECAY_PATIENCE_EVALS) == 0):
        new_lr = max(float(LR_MIN), float(cur_lr) * float(LR_DECAY_FACTOR))
        if new_lr < cur_lr - 1e-12:
            applied = _optimizer_set_lr(optimizer_obj, new_lr)
            control_state['lr_decay_count'] = int(control_state.get('lr_decay_count', 0)) + 1
            control_state['current_lr'] = float(applied)
            print(f'[CTRL] lr decayed at ep={episode} no_improve_evals={n_bad} lr={applied:.6g}', flush=True)
            cur_lr = float(applied)

    stop_now = False
    if (
        EARLY_STOP_ACTIVE
        and allow_early_stop
        and int(episode) >= int(EARLY_STOP_MIN_EPISODE)
        and n_bad >= int(EARLY_STOP_PATIENCE_EVALS)
    ):
        control_state['stop_training_requested'] = True
        stop_now = True
        print(f'[CTRL] early stop triggered at ep={episode} no_improve_evals={n_bad} best_balanced_ep={control_state.get("best_balanced_episode")}', flush=True)

    return bool(stop_now), float(cur_lr)


def _disk_free_mb(path: Path) -> float:
    try:
        return float(shutil.disk_usage(str(Path(path).expanduser().resolve())).free) / (1024.0 * 1024.0)
    except Exception:
        return -1.0


def _has_enough_free_mb(path: Path, min_free_mb: float) -> bool:
    free_mb = _disk_free_mb(path)
    if free_mb < 0.0:
        return True
    return bool(free_mb >= float(min_free_mb))


def _atomic_pickle_dump(obj, path: Path) -> bool:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not _has_enough_free_mb(path.parent, CHECKPOINT_MIN_FREE_MB_FOR_META):
        free_mb = _disk_free_mb(path.parent)
        print(f"[CKPT][WARN] meta save skipped. low disk free={free_mb:.1f}MB need>={CHECKPOINT_MIN_FREE_MB_FOR_META:.1f}MB path={path}", flush=True)
        return False
    tmp_path = None
    try:
        tmp_fd, tmp_path = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        os.close(tmp_fd)
        with open(tmp_path, "wb") as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
        os.replace(tmp_path, path)
        return True
    except Exception as e:
        try:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        print(f"[CKPT][WARN] pickle save failed. path={path} err={e}", flush=True)
        return False


def _atomic_npz_dump(path: Path, **arrays) -> bool:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not _has_enough_free_mb(path.parent, CHECKPOINT_MIN_FREE_MB_FOR_REPLAY):
        free_mb = _disk_free_mb(path.parent)
        print(f"[CKPT][WARN] replay save skipped. low disk free={free_mb:.1f}MB need>={CHECKPOINT_MIN_FREE_MB_FOR_REPLAY:.1f}MB path={path}", flush=True)
        return False
    tmp_path = None
    try:
        tmp_fd, tmp_path = tempfile.mkstemp(prefix=path.stem + ".", suffix=".tmp.npz", dir=str(path.parent))
        os.close(tmp_fd)
        np.savez_compressed(tmp_path, **arrays)
        os.replace(tmp_path, path)
        return True
    except Exception as e:
        try:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        print(f"[CKPT][WARN] replay save failed. path={path} err={e}", flush=True)
        return False


def _optimizer_variables_list(opt):
    try:
        vars_attr = getattr(opt, "variables", None)
        if callable(vars_attr):
            return list(vars_attr())
        if vars_attr is not None:
            return list(vars_attr)
    except Exception:
        pass
    return []


def _get_optimizer_state_arrays(opt):
    out = []
    for var in _optimizer_variables_list(opt):
        try:
            out.append(np.array(var.numpy()))
        except Exception:
            return []
    return out


def _restore_optimizer_state_arrays(opt, state_arrays, model_vars) -> bool:
    if not state_arrays:
        return False
    try:
        build_fn = getattr(opt, "build", None)
        if callable(build_fn):
            try:
                build_fn(model_vars)
            except Exception:
                pass
        vars_list = _optimizer_variables_list(opt)
        if len(vars_list) != len(state_arrays):
            return False
        for var, arr in zip(vars_list, state_arrays):
            var.assign(arr)
        return True
    except Exception as e:
        print(f"[CKPT][WARN] optimizer state restore failed. err={e}", flush=True)
        return False


def _save_replay_buffer_npz(path: Path, replay_buffer) -> bool:
    n_full = int(len(replay_buffer))
    if int(CHECKPOINT_REPLAY_MAX_ITEMS) > 0 and n_full > int(CHECKPOINT_REPLAY_MAX_ITEMS):
        replay_items = list(replay_buffer)[-int(CHECKPOINT_REPLAY_MAX_ITEMS):]
    else:
        replay_items = list(replay_buffer)
    n = int(len(replay_items))
    if n <= 0:
        return _atomic_npz_dump(path,
                                size=np.asarray(0, dtype=np.int64),
                                size_full=np.asarray(int(n_full), dtype=np.int64),
                                maxlen=np.asarray(int(replay_buffer.maxlen or 0), dtype=np.int64),
                                states=np.empty((0, 0), dtype=np.float32),
                                actions=np.empty((0,), dtype=np.int32),
                                rewards=np.empty((0,), dtype=np.float32),
                                next_states=np.empty((0, 0), dtype=np.float32),
                                dones=np.empty((0,), dtype=np.float32),
                                next_action_masks=np.empty((0, int(MAX_ACTIONS)), dtype=np.bool_))

    first_state = np.asarray(replay_items[0].state, dtype=np.float32).reshape(-1)
    state_dim = int(first_state.shape[0])
    states = np.empty((n, state_dim), dtype=np.float32)
    next_states = np.empty((n, state_dim), dtype=np.float32)
    actions = np.empty((n,), dtype=np.int32)
    rewards = np.empty((n,), dtype=np.float32)
    dones = np.empty((n,), dtype=np.float32)
    next_action_masks = np.empty((n, int(MAX_ACTIONS)), dtype=np.bool_)

    for i, e in enumerate(replay_items):
        states[i] = np.asarray(e.state, dtype=np.float32).reshape(-1)
        next_states[i] = np.asarray(e.next_state, dtype=np.float32).reshape(-1)
        actions[i] = int(e.action)
        rewards[i] = float(e.reward)
        dones[i] = float(e.done)
        next_action_masks[i] = np.asarray(e.next_action_mask, dtype=np.bool_).reshape(int(MAX_ACTIONS))

    return _atomic_npz_dump(path,
                            size=np.asarray(n, dtype=np.int64),
                            size_full=np.asarray(int(n_full), dtype=np.int64),
                            maxlen=np.asarray(int(replay_buffer.maxlen or 0), dtype=np.int64),
                            states=states,
                            actions=actions,
                            rewards=rewards,
                            next_states=next_states,
                            dones=dones,
                            next_action_masks=next_action_masks)


def _load_replay_buffer_npz(path: Path, maxlen_default: int):
    path = Path(path)
    if not path.exists():
        return deque(maxlen=int(maxlen_default))

    data = np.load(path, allow_pickle=False)
    size = int(np.asarray(data["size"]).item())
    maxlen = int(np.asarray(data["maxlen"]).item()) if "maxlen" in data else int(maxlen_default)
    replay = deque(maxlen=int(maxlen) if int(maxlen) > 0 else int(maxlen_default))

    if size <= 0:
        return replay

    states = np.asarray(data["states"], dtype=np.float32)
    next_states = np.asarray(data["next_states"], dtype=np.float32)
    actions = np.asarray(data["actions"], dtype=np.int32).reshape(-1)
    rewards = np.asarray(data["rewards"], dtype=np.float32).reshape(-1)
    dones = np.asarray(data["dones"], dtype=np.float32).reshape(-1)
    if "next_action_masks" in data:
        next_action_masks = np.asarray(data["next_action_masks"], dtype=np.bool_)
    else:
        # Backward-compatible fallback; REV6 normally starts with a fresh replay.
        next_action_masks = np.ones((int(size), int(MAX_ACTIONS)), dtype=np.bool_)

    for i in range(int(size)):
        replay.append(
            experience(
                states[i].copy(),
                int(actions[i]),
                float(rewards[i]),
                next_states[i].copy(),
                float(dones[i]),
                next_action_masks[i].copy(),
            )
        )
    return replay


def _write_checkpoint_note() -> None:
    try:
        CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
        note = (
            "Bu klasör tam training checkpoint için kullanılır.\n"
            "İçerik: model + target model + optimizer + episode + epsilon + learn_step + replay buffer + history.\n"
            "Script yeniden çalıştığında RESUME_IF_AVAILABLE=True ise buradan devam eder.\n"
            "Not: Tam olarak son save noktasından devam eder; elektrik kesilmesi save arasında olduysa son checkpoint'e döner.\n"
        )
        CHECKPOINT_NOTE_PATH.write_text(note, encoding="utf-8")
    except Exception:
        pass


def _save_training_checkpoint(episode_done: int, epsilon_value: float, learn_step_value: int,
                              total_rewards_hist, total_rewards_test_hist,
                              total_point_history_hist, total_point_test_hist,
                              replay_buffer, checkpoint, checkpoint_manager, control_state=None) -> None:
    if not CHECKPOINT_ENABLE:
        return
    if int(CHECKPOINT_EVERY_EPISODE) <= 0:
        return
    if ((int(episode_done) + 1) % int(CHECKPOINT_EVERY_EPISODE)) != 0:
        return

    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    _write_checkpoint_note()

    ckpt_path = None
    try:
        ckpt_path = checkpoint_manager.save(checkpoint_number=int(episode_done))
    except Exception as e:
        print(f"[CKPT][WARN] tf checkpoint save failed. ep={episode_done} err={e}", flush=True)

    replay_saved = False
    if CHECKPOINT_SAVE_REPLAY and int(CHECKPOINT_REPLAY_EVERY_EPISODE) > 0:
        if ((int(episode_done) + 1) % int(CHECKPOINT_REPLAY_EVERY_EPISODE)) == 0:
            replay_saved = _save_replay_buffer_npz(CHECKPOINT_REPLAY_PATH, replay_buffer)

    meta = {
        "version": VERSION,
        "saved_at": datetime.datetime.now().isoformat(timespec='seconds'),
        "episode_completed": int(episode_done),
        "next_episode": int(episode_done) + 1,
        "epsilon": float(epsilon_value),
        "learn_step": int(learn_step_value),
        "checkpoint_path": ckpt_path,
        "replay_saved": bool(replay_saved),
        "replay_path": str(CHECKPOINT_REPLAY_PATH) if replay_saved else None,
        "replay_len": int(len(replay_buffer)),
        "total_rewards": list(total_rewards_hist),
        "total_rewards_test": list(total_rewards_test_hist),
        "total_point_history": list(total_point_history_hist),
        "total_point_test": list(total_point_test_hist),
        "random_state": random.getstate(),
        "np_random_state": np.random.get_state(),
        "optimizer_state_arrays": _get_optimizer_state_arrays(optimizer),
        "control_state": dict(control_state or {}),
    }
    ok = _atomic_pickle_dump(meta, CHECKPOINT_META_PATH)
    if ok:
        print(f"[CKPT] saved ep={episode_done} next_ep={int(episode_done)+1} replay={int(len(replay_buffer))} tf={ckpt_path}", flush=True)


def _try_resume_from_full_checkpoint(checkpoint, checkpoint_manager):
    meta = None
    latest_ckpt = None
    try:
        latest_ckpt = checkpoint_manager.latest_checkpoint
    except Exception:
        latest_ckpt = None

    if CHECKPOINT_META_PATH.exists():
        try:
            with open(CHECKPOINT_META_PATH, "rb") as f:
                meta = pickle.load(f)
        except Exception as e:
            print(f"[CKPT][WARN] meta load failed. path={CHECKPOINT_META_PATH} err={e}", flush=True)
            meta = None

    if (meta is None) and (latest_ckpt is None):
        return False, None

    if latest_ckpt is not None:
        try:
            checkpoint.restore(latest_ckpt).expect_partial()
            print(f"[CKPT] tf checkpoint restored. path={latest_ckpt}", flush=True)
        except Exception as e:
            print(f"[CKPT][WARN] tf checkpoint restore failed. path={latest_ckpt} err={e}", flush=True)

    return True, meta


# ============================================================
# Training loop
# ============================================================
start = time.time()

num_episodes = int(os.environ.get("CIT_NUM_EPISODES", "801"))
max_num_timesteps = 6000

total_rewards = []
total_rewards_test = []
total_point_history = []
total_point_test = []
start_episode = 0
training_control_state = _default_control_state()
training_control_state['current_lr'] = _optimizer_current_lr(optimizer)

# Önce tam checkpoint'i dene. Bulunamazsa eski ağırlık-resume mantığı fallback olur.
full_resume_loaded = False
full_resume_meta = None
if RESUME_IF_AVAILABLE and CHECKPOINT_ENABLE:
    full_resume_loaded, full_resume_meta = _try_resume_from_full_checkpoint(checkpoint, checkpoint_manager)
    if full_resume_loaded and full_resume_meta is not None:
        start_episode = int(full_resume_meta.get("next_episode", 0))
        epsilon = float(full_resume_meta.get("epsilon", epsilon))
        learn_step = int(full_resume_meta.get("learn_step", 0))
        total_rewards = list(full_resume_meta.get("total_rewards", []))
        total_rewards_test = list(full_resume_meta.get("total_rewards_test", []))
        total_point_history = list(full_resume_meta.get("total_point_history", []))
        total_point_test = list(full_resume_meta.get("total_point_test", []))

        if full_resume_meta.get("replay_saved", False) and CHECKPOINT_REPLAY_PATH.exists():
            try:
                memory_buffer = _load_replay_buffer_npz(CHECKPOINT_REPLAY_PATH, MEMORY_SIZE)
                print(f"[CKPT] replay buffer restored. size={len(memory_buffer)} path={CHECKPOINT_REPLAY_PATH}", flush=True)
            except Exception as e:
                print(f"[CKPT][WARN] replay buffer restore failed. err={e}", flush=True)
                memory_buffer = deque(maxlen=MEMORY_SIZE)

        try:
            random.setstate(full_resume_meta["random_state"])
        except Exception:
            pass
        try:
            np.random.set_state(full_resume_meta["np_random_state"])
        except Exception:
            pass

        ctrl_meta = full_resume_meta.get("control_state", None)
        if isinstance(ctrl_meta, dict):
            training_control_state.update(ctrl_meta)
        training_control_state['stop_training_requested'] = False
        if GATED_CURRICULUM_ACTIVE:
            resume_phase = str(training_control_state.get("curriculum_phase", "feasibility"))
            tracked_phase = str(training_control_state.get("early_stop_phase", ""))
            if tracked_phase != resume_phase:
                old_bad = int(training_control_state.get("eval_no_improve_count", 0))
                training_control_state["eval_no_improve_count"] = 0
                training_control_state["early_stop_phase"] = resume_phase
                print(
                    f"[CKPT] curriculum patience normalized on resume. "
                    f"phase={resume_phase} old_no_improve={old_bad}",
                    flush=True,
                )
        if training_control_state.get('current_lr', None) is not None:
            applied_lr = _optimizer_set_lr(optimizer, float(training_control_state.get('current_lr', ALPHA)))
            training_control_state['current_lr'] = float(applied_lr)
        opt_restored = _restore_optimizer_state_arrays(optimizer, full_resume_meta.get("optimizer_state_arrays", []), q_network.trainable_variables)
        print(
            f"[CKPT] full resume loaded. start_episode={start_episode} epsilon={epsilon:.6f} learn_step={learn_step} opt_restored={int(opt_restored)} lr={training_control_state['current_lr']:.6g}",
            flush=True
        )
    elif full_resume_loaded:
        print("[CKPT] weights restored from tf checkpoint but meta bulunamadı; histories taze başlayacak.", flush=True)

if (not full_resume_loaded) and resume_loaded:
    if float(epsilon) > float(EPS_START_RESUME):
        epsilon = float(EPS_START_RESUME)
    if resume_loaded_path and (VERSION not in str(resume_loaded_path)):
        print(f"[BOOT][WARN] resumed from different version weights. loaded={resume_loaded_path} expected_contains={VERSION}", flush=True)
    print(f"[BOOT] epsilon start adjusted for resume. epsilon={epsilon}", flush=True)


# ---------------------------
# Run artifacts (opsiyonel)
# ---------------------------
train_csv_logger = None
test_csv_logger = None

if RUN_DIR is not None:
    try:
        run_cfg = {
            "version": VERSION,
            "created_at": datetime.datetime.now().isoformat(),
            "seed": GLOBAL_SEED,
            "weights": {"w1": w1, "w2": w2, "w3": w3, "w4": w4, "w_tw": W_TIMEWINDOW},
            "objective_weights": objective_weight_dict(),
            "reward_design": "rev15_hard_target_discrete_stochastic_pareto",
            "target_hard_constraint": bool(TARGET_HARD_CONSTRAINT),
            "hierarchical_cit": {
                "active": bool(HIER_CIT_ACTIVE),
                "obs_dim": int(HIER_OBS_DIM),
                "solved_reward": float(HIER_SOLVED_REWARD),
                "delivery_subgoal_reward": float(HIER_DELIVERY_SUBGOAL_REWARD),
                "ontime_delivery_reward": float(HIER_ONTIME_DELIVERY_REWARD),
                "trace_threshold": float(HIER_TRACE_THRESHOLD),
            },
            "preference_conditioned": {
                "active": bool(PREFERENCE_CONDITIONED_ACTIVE),
                "hier_operational_only": bool(HIER_OPERATIONAL_ONLY),
                "profiles": PREFERENCE_PROFILE_WEIGHTS,
                "training_schedule": list(PREFERENCE_TRAINING_SCHEDULE),
                "jitter_active": bool(PREFERENCE_JITTER_ACTIVE),
                "jitter_fraction": float(PREFERENCE_JITTER_FRACTION),
                "pareto_eval_period": int(PARETO_EVAL_PERIOD),
                "balanced_eval": True,
            },
            "sync_legacy_reward_weights": bool(SYNC_LEGACY_REWARD_WEIGHTS_FROM_OBJECTIVES),
            "service_end_min": SERVICE_END_MIN,
            "return_grace_min": RETURN_GRACE_MIN,
            "max_route_duration_min": MAX_ROUTE_DURATION_MIN,
            "absolute_max_route_duration_min": ABSOLUTE_MAX_ROUTE_DURATION_MIN,
            "episodes": int(num_episodes),
            "max_num_timesteps": int(max_num_timesteps),
            "n_locations": int(n_locations),
            "n_vehicles": int(n_vehicles),
            "total_required_units": float(TOTAL_REQUIRED_UNITS),
            "total_capacity": float(total_capacity),
            "dropped_units": float(TOTAL_DROPPED_UNITS),
            "memory_size": int(MEMORY_SIZE),
            "batch_size": int(getattr(utils, "BATCH_SIZE", 128)),
            "gamma": float(GAMMA),
            "lr": float(ALPHA),
            "reward_clip": float(REWARD_CLIP),
            "resume_weights_path": str(RESUME_WEIGHTS_PATH),
            "warm_start_weights_path": str(WARM_START_WEIGHTS_PATH),
            "resume_loaded_path": str(resume_loaded_path) if resume_loaded_path else None,
            "checkpoint_enable": bool(CHECKPOINT_ENABLE),
            "checkpoint_every_episode": int(CHECKPOINT_EVERY_EPISODE),
            "checkpoint_save_replay": bool(CHECKPOINT_SAVE_REPLAY),
            "checkpoint_replay_every_episode": int(CHECKPOINT_REPLAY_EVERY_EPISODE),
            "checkpoint_max_to_keep": int(CHECKPOINT_MAX_TO_KEEP),
            "checkpoint_dir": str(CHECKPOINT_DIR),
            "save_models_period": int(save_models_period),
            "best_checkpoints_active": bool(BEST_CHECKPOINTS_ACTIVE),
            "lr_decay_patience_evals": int(LR_DECAY_PATIENCE_EVALS),
            "early_stop_active": bool(EARLY_STOP_ACTIVE),
            "early_stop_patience_evals": int(EARLY_STOP_PATIENCE_EVALS),
            "early_stop_min_episode": int(EARLY_STOP_MIN_EPISODE),
        }
        with open(Path(RUN_DIR) / "run_config.json", "w", encoding="utf-8") as f:
            json.dump(run_cfg, f, ensure_ascii=False, indent=2)
        print(f"[RUN] run_config.json -> {Path(RUN_DIR) / 'run_config.json'}", flush=True)
    except Exception as e:
        print(f"[RUN][WARN] run_config yazılamadı: {e}", flush=True)

if RUN_DIR is not None and CSV_LOG_EVERY > 0:
    try:
        train_fields = [
            "episode", "preference_profile", "pref_undelivered", "pref_early", "pref_late", "pref_service_over", "pref_return_over", "pref_secure", "pref_distance", "pref_duration", "pref_risk", "pref_loop", "pref_reservation", "pref_makespan", "status", "reason", "reward", "hier_reward", "soft_objective_reward", "r50",
            "delivered", "total_required", "remaining",
            "steps", "sps", "dist_km", "kpd", "mksp", "ot_min", "rte_min",
            "tw_miss", "tw_early", "tw_late",
            "returned", "eod_violations", "service_end_trig",
            "backtracks", "revisits", "illegal", "shield", "loops",
            "recoveries", "finish_overrides",
            "epsilon", "loss",
            "cost_undelivered", "cost_early", "cost_late", "cost_service_over", "cost_return_over",
            "cost_secure", "cost_distance", "cost_duration", "cost_risk", "cost_loop", "cost_reservation", "cost_makespan", "scalarized_total_cost",
            "contrib_undelivered", "contrib_early", "contrib_late", "contrib_service_over", "contrib_return_over",
            "contrib_secure", "contrib_distance", "contrib_duration", "contrib_risk", "contrib_loop", "contrib_reservation", "contrib_makespan"
        ]
        test_fields = [
            "test_at_episode", "reason",
            "avg_reward", "avg_duration",
            "avg_delivered", "avg_remaining",
            "avg_steps", "avg_dist_km", "avg_kpd",
            "avg_tw_miss", "avg_returned", "avg_eod_violations",
            "suite_solved", "suite_n", "suite_mean_del", "suite_mean_miss", "suite_mean_dist_km", "suite_mean_makespan",
            "cost_undelivered", "cost_early", "cost_late", "cost_service_over", "cost_return_over",
            "cost_secure", "cost_distance", "cost_duration", "cost_risk", "cost_loop", "cost_reservation", "cost_makespan", "scalarized_total_cost",
            "contrib_undelivered", "contrib_early", "contrib_late", "contrib_service_over", "contrib_return_over",
            "contrib_secure", "contrib_distance", "contrib_duration", "contrib_risk", "contrib_loop", "contrib_reservation", "contrib_makespan"
        ]
        train_csv_logger = EpisodeCSVLogger(Path(RUN_DIR) / "train_episode_log.csv", train_fields)
        test_csv_logger = EpisodeCSVLogger(Path(RUN_DIR) / "test_eval_log.csv", test_fields)
        print(f"[RUN] CSV logs -> {RUN_DIR} (csv_log_every={CSV_LOG_EVERY})", flush=True)
    except Exception as e:
        print(f"[RUN][WARN] CSV logger açılamadı: {e}", flush=True)
        train_csv_logger = None
        test_csv_logger = None

BEST_MODELS_DIR = _best_models_dir() if BEST_CHECKPOINTS_ACTIVE else None

for episode in range(int(start_episode), int(num_episodes)):
    if PREFERENCE_CONDITIONED_ACTIVE and int(episode) < int(BASELINE_ONLY_EPISODES):
        episode_preference_profile = "balanced"
        episode_preference_weights = apply_preference_profile("balanced", jitter=False)
    elif PREFERENCE_CONDITIONED_ACTIVE:
        episode_preference_profile, episode_preference_weights = sample_training_preference()
    else:
        episode_preference_profile = "fixed"
        episode_preference_weights = objective_weight_dict()
    env.curriculum_phase = str(training_control_state.get(
        "curriculum_phase",
        "feasibility" if GATED_CURRICULUM_ACTIVE else "optimization",
    ))
    shield_prob = max(SHIELD_PROB_END, SHIELD_PROB_START * (SHIELD_PROB_DECAY ** episode))
    ep_t0 = time.perf_counter()

    total_points, done, last_loss, steps_total, stop_reason = run_episode_rollout(
        env_local=env,
        vehicles_local=vehicles,
        q_net=q_network,
        epsilon_local=float(epsilon),
        max_steps=int(max_num_timesteps),
        training=True,
        episode=int(episode),
        shield_prob=float(shield_prob),
    )

    total_rewards.append(float(total_points))

    total_duration = float(sum(v.total_duration for v in vehicles))
    makespan = float(max([v.total_duration for v in vehicles] + [0.0]))
    total_point_history.append(total_duration)

    epsilon = max(E_MIN, E_DECAY * epsilon)

    ep_time = float(time.perf_counter() - ep_t0)
    rem_units = int(sum(env.demands.values()))
    delivered_units = int(TOTAL_REQUIRED_UNITS - rem_units)
    if rem_units == 0:
        status = "DONE" if done else "RETURNING"
    else:
        status = "FAILED" if stop_reason == "no_active" else "RUNNING"
    r50 = float(np.mean(total_rewards[-50:])) if len(total_rewards) >= 50 else float(np.mean(total_rewards))
    sps = float(steps_total / ep_time) if ep_time > 1e-9 else 0.0

    total_distance_km = float(sum(v.total_distance for v in vehicles) / 1000.0)
    kpd = (total_distance_km / delivered_units) if delivered_units > 0 else None
    kpd_str = f"{kpd:.2f}" if kpd is not None else "NA"

    shield_total = int(sum(v.shield_moves for v in vehicles))
    shield_ratio = float(shield_total / max(1, steps_total))
    miss_total = int(sum(v.tw_misses for v in vehicles))
    clip_total = int(sum(v.reward_clipped_steps for v in vehicles))
    secure_wait_total = int(sum(v.secure_wait_steps for v in vehicles))
    secure_travel_total = int(sum(v.secure_travel_steps for v in vehicles))
    early_redirect_total = int(sum(v.early_redirects for v in vehicles))
    maskE_total = int(sum(getattr(v, 'mask_early', 0) for v in vehicles))
    maskL_total = int(sum(getattr(v, 'mask_late', 0) for v in vehicles))
    maskAll_total = int(sum(getattr(v, 'mask_all_blocked', 0) for v in vehicles))
    noFeas_total = int(sum(getattr(v, 'no_feasible_steps', 0) for v in vehicles))
    tsw_total = int(sum(v.target_switches for v in vehicles))
    lp_total = int(sum(v.loop_penalty_steps for v in vehicles))
    eod_total = int(sum(v.end_of_day_terminations for v in vehicles))
    ot_total = float(sum(getattr(v, 'overtime_minutes', 0.0) for v in vehicles))
    rte_total = float(sum(getattr(v, 'return_extension_minutes', 0.0) for v in vehicles))
    hier_reward_total = float(sum(getattr(v, 'sum_reward_hierarchy', 0.0) for v in vehicles))
    soft_reward_total = float(sum(getattr(v, 'sum_reward_soft_objective', 0.0) for v in vehicles))
    train_cost_summary = summarize_episode_objective_costs(env, vehicles, steps_total=int(steps_total), makespan_value=float(makespan))
    cur_lr = _optimizer_current_lr(optimizer)
    training_control_state['current_lr'] = float(cur_lr)

    do_log = (LOG_LEVEL >= 1) and (
        episode < LOG_FIRST_N_EPISODES or
        episode % EP_LOG_EVERY == 0 or
        done or
        rem_units == 0
    )

    if do_log:
        print(
            f"[EP] {episode} pref={episode_preference_profile} status={status} reason={stop_reason} R={total_points:.1f} R50={r50:.1f} "
            f"hR={hier_reward_total:.1f} softR={soft_reward_total:.1f} "
            f"del={delivered_units}/{TOTAL_REQUIRED_UNITS} rem={rem_units} "
            f"steps={steps_total} sps={sps:.1f} dist={total_distance_km:.2f}km kpd={kpd_str} "
            f"miss={miss_total} ret={len(env.returned_vehicle_ids)}/{env.n_vehicles} sh={shield_ratio:.2f} clip={clip_total} eod={eod_total} "
            f"sw={secure_wait_total} st={secure_travel_total} erd={early_redirect_total} mE={maskE_total} mL={maskL_total} mAll={maskAll_total} nF={noFeas_total} tsw={tsw_total} lp={lp_total} "
            f"ot={ot_total:.1f} rte={rte_total:.1f} mksp={makespan:.1f} dur={total_duration:.1f} eps={epsilon:.3f} lr={cur_lr:.6g}",
            flush=True
        )
        for vi, v in enumerate(vehicles):
            v_kpd = (v.total_distance / 1000.0) / v.deliveries_made if v.deliveries_made > 0 else None
            v_kpd_str = f"{v_kpd:.2f}" if v_kpd is not None else "NA"
            print(
                f"  [V{vi}] del={v.deliveries_made} miss={v.tw_misses}(e={v.tw_misses_early},l={v.tw_misses_late}) "
                f"back={v.backtracks} rev={v.revisits} shield={v.shield_moves} loop={v.loop_flags} "
                f"stall={v.stall_terminations} eod={v.end_of_day_terminations} unr={v.unreachable_steps} clip={v.reward_clipped_steps} "
                f"sw={v.secure_wait_steps} st={v.secure_travel_steps} erd={v.early_redirects} ot={getattr(v,'overtime_minutes',0.0):.1f} rte={getattr(v,'return_extension_minutes',0.0):.1f} "
                f"mE={getattr(v,'mask_early',0)} mL={getattr(v,'mask_late',0)} mAll={getattr(v,'mask_all_blocked',0)} nF={getattr(v,'no_feasible_steps',0)} lt={getattr(v,'locked_target',-1)} tsw={v.target_switches} lp={v.loop_penalty_steps} "
                f"hR={getattr(v,'sum_reward_hierarchy',0.0):.1f} loc={v.current_location} tw={v.current_time_window} cap={v.capacity} dist={v.total_distance/1000.0:.2f}km kpd={v_kpd_str}",
                flush=True
            )

        if LOG_REMAINING_DEMANDS and rem_units > 0:
            rem_nodes = [int(n) for n, a in env.demands.items() if int(a) > 0]
            rem_nodes.sort()
            sample = rem_nodes[:int(LOG_REMAINING_DEMAND_TOPK)]
            info = " ".join(f"{n}:{env.delivery_windows_by_node.get(int(n), [])}" for n in sample)
            print(f"  [REM] {info}", flush=True)

    if train_csv_logger is not None and CSV_LOG_EVERY > 0 and (episode % CSV_LOG_EVERY == 0):
        try:
            tw_early_total = int(sum(v.tw_misses_early for v in vehicles))
            tw_late_total = int(sum(v.tw_misses_late for v in vehicles))
            ret_count_csv = int(len(env.returned_vehicle_ids))
            back_total_csv = int(sum(v.backtracks for v in vehicles))
            rev_total_csv = int(sum(v.revisits for v in vehicles))
            illegal_total_csv = int(sum(v.illegal_moves for v in vehicles))
            loop_total_csv = int(sum(v.loop_flags for v in vehicles))
            se_trig_total_csv = int(sum(1 for v in vehicles if getattr(v, "service_end_triggered", False)))

            train_csv_logger.log({
                "episode": int(episode),
                "preference_profile": str(episode_preference_profile),
                **{f"pref_{k}": float(episode_preference_weights[k]) for k in OBJECTIVE_WEIGHT_ORDER},
                "status": str(status),
                "reason": str(stop_reason),
                "reward": float(total_points),
                "hier_reward": float(hier_reward_total),
                "soft_objective_reward": float(soft_reward_total),
                "r50": float(r50),
                "delivered": int(delivered_units),
                "total_required": float(TOTAL_REQUIRED_UNITS),
                "remaining": int(rem_units),
                "steps": int(steps_total),
                "sps": float(sps),
                "dist_km": float(total_distance_km),
                "kpd": float(kpd) if kpd is not None else "",
                "mksp": float(makespan),
                "ot_min": float(ot_total),
                "rte_min": float(rte_total),
                "tw_miss": int(miss_total),
                "tw_early": int(tw_early_total),
                "tw_late": int(tw_late_total),
                "returned": int(ret_count_csv),
                "eod_violations": int(eod_total),
                "service_end_trig": int(se_trig_total_csv),
                "backtracks": int(back_total_csv),
                "revisits": int(rev_total_csv),
                "illegal": int(illegal_total_csv),
                "shield": int(shield_total),
                "loops": int(loop_total_csv),
                "recoveries": int(sum(getattr(v, 'recovery_overrides', 0) for v in vehicles)),
                "finish_overrides": int(sum(getattr(v, 'finish_overrides', 0) for v in vehicles)),
                "epsilon": float(epsilon),
                "loss": float(last_loss) if last_loss is not None else "",
                **{k: float(v) for k, v in train_cost_summary.items()},
            })
        except Exception:
            pass

    if episode % test_period == 0:
        # Standard comparisons/checkpoints always use the balanced profile.
        if PREFERENCE_CONDITIONED_ACTIVE:
            apply_preference_profile("balanced", jitter=False)
        total_points_test, done_t, _loss_t, steps_total_test, stop_reason_test = run_episode_rollout(
            env_local=env,
            vehicles_local=vehicles,
            q_net=q_network,
            epsilon_local=0.0,
            max_steps=int(max_num_timesteps),
            training=False,
            episode=int(episode),
            shield_prob=0.0,
        )

        total_rewards_test.append(float(total_points_test))
        total_duration_test = float(sum(v.total_duration for v in vehicles))
        makespan_test = float(max([v.total_duration for v in vehicles] + [0.0]))
        total_distance_test = float(sum(v.total_distance for v in vehicles) / 1000.0)
        rem_units_test = int(sum(env.demands.values()))
        delivered_units_test = int(TOTAL_REQUIRED_UNITS - rem_units_test)
        kpd_test = (total_distance_test / delivered_units_test) if delivered_units_test > 0 else None
        kpd_test_str = f"{kpd_test:.2f}" if kpd_test is not None else "NA"
        total_point_test.append(total_duration_test)
        test_cost_summary = summarize_episode_objective_costs(env, vehicles, steps_total=int(steps_total_test), makespan_value=float(makespan_test))

        print("TEST RESULT", flush=True)
        print(
            f"Episode {episode} | Test R={total_points_test:.3f} | del={delivered_units_test}/{TOTAL_REQUIRED_UNITS} | "
            f"dist={total_distance_test:.2f}km | kpd={kpd_test_str} | mksp={makespan_test:.2f} | dur={total_duration_test:.2f} | reason={stop_reason_test} | cost={test_cost_summary['scalarized_total_cost']:.3f}",
            flush=True
        )

        suite = None
        if SUITE_TEST_ACTIVE and (episode % int(SUITE_TEST_PERIOD) == 0):
            suite = run_deterministic_suite(
                env_local=env,
                vehicles_local=vehicles,
                q_net=q_network,
                n_runs=int(SUITE_TEST_N),
                seed0=int(SUITE_TEST_SEED0),
                max_steps=int(SUITE_TEST_MAX_STEPS),
                episode_eval=int(episode),
            )
            print(
                f"[SUITE] ep={episode} n={suite['n']} solved={suite['solved']}/{suite['n']} "
                f"mean_del={suite['mean_del']:.2f} p10={suite['p10_del']:.0f} p50={suite['p50_del']:.0f} p90={suite['p90_del']:.0f} "
                f"mean_miss={suite['mean_miss']:.2f} mean_dist={suite['mean_dist_km']:.2f}km mean_kpd={suite['mean_kpd']:.2f} "
                f"mean_mksp={suite['mean_makespan']:.2f} mean_R={suite['mean_R']:.1f}",
                flush=True
            )

        test_metrics = {
            'test_at_episode': int(episode),
            'reason': str(stop_reason_test),
            'avg_reward': float(total_points_test),
            'avg_duration': float(makespan_test),
            'avg_delivered': int(delivered_units_test),
            'avg_remaining': int(rem_units_test),
            'avg_steps': int(steps_total_test),
            'avg_dist_km': float(total_distance_test),
            'avg_kpd': float(kpd_test) if kpd_test is not None else '',
            'avg_tw_miss': int(sum(v.tw_misses for v in vehicles)),
            'avg_returned': int(len(env.returned_vehicle_ids)),
            'avg_eod_violations': int(sum(getattr(v, 'end_of_day_terminations', 0) for v in vehicles)),
            'suite_solved': int(suite['solved']) if suite is not None else '',
            'suite_n': int(suite['n']) if suite is not None else '',
            'suite_mean_del': float(suite['mean_del']) if suite is not None else '',
            'suite_mean_miss': float(suite['mean_miss']) if suite is not None else '',
            'suite_mean_dist_km': float(suite['mean_dist_km']) if suite is not None else '',
            'suite_mean_makespan': float(suite['mean_makespan']) if suite is not None else '',
            **{k: float(v) for k, v in test_cost_summary.items()},
        }

        _update_curriculum_gate(training_control_state, suite)
        improved, balanced_score = _maybe_update_best_checkpoints(training_control_state, int(episode), test_metrics, suite, q_network)

        if (PREFERENCE_CONDITIONED_ACTIVE and int(episode) >= int(BASELINE_ONLY_EPISODES) and
                PARETO_EVAL_PERIOD > 0 and episode % int(PARETO_EVAL_PERIOD) == 0):
            run_preference_pareto_sweep(
                env_local=env, vehicles_local=vehicles, q_net=q_network,
                episode_eval=int(episode), max_steps=int(max_num_timesteps),
            )

        stop_now, cur_lr_after = _maybe_apply_lr_decay_and_early_stop(training_control_state, int(episode), float(balanced_score), bool(improved), optimizer)
        training_control_state['current_lr'] = float(cur_lr_after)

        if test_csv_logger is not None and CSV_LOG_EVERY > 0:
            try:
                test_csv_logger.log(test_metrics)
            except Exception:
                pass

    if training_control_state.get('stop_training_requested', False):
        _save_training_checkpoint(
            episode_done=int(episode),
            epsilon_value=float(epsilon),
            learn_step_value=int(learn_step),
            total_rewards_hist=total_rewards,
            total_rewards_test_hist=total_rewards_test,
            total_point_history_hist=total_point_history,
            total_point_test_hist=total_point_test,
            replay_buffer=memory_buffer,
            checkpoint=checkpoint,
            checkpoint_manager=checkpoint_manager,
            control_state=training_control_state,
        )
        print(f"[TRAIN] early stop break at ep={episode}", flush=True)
        break

    _save_training_checkpoint(
        episode_done=int(episode),
        epsilon_value=float(epsilon),
        learn_step_value=int(learn_step),
        total_rewards_hist=total_rewards,
        total_rewards_test_hist=total_rewards_test,
        total_point_history_hist=total_point_history,
        total_point_test_hist=total_point_test,
        replay_buffer=memory_buffer,
        checkpoint=checkpoint,
        checkpoint_manager=checkpoint_manager,
        control_state=training_control_state,
    )

    if episode % save_models_period == 0 and episode > 0:
        q_network.save(f"cit_q_network_{VERSION}.h5")
        with open(f"cash_in_transit_duration_train_{VERSION}.txt", "w", encoding="utf-8") as fp:
            fp.write("\n".join(str(x) for x in total_point_history))
        with open(f"cash_in_transit_rewards_train_{VERSION}.txt", "w", encoding="utf-8") as fp:
            fp.write("\n".join(str(x) for x in total_rewards))
        with open(f"cash_in_transit_duration_test_{VERSION}.txt", "w", encoding="utf-8") as fp:
            fp.write("\n".join(str(x) for x in total_point_test))
        with open(f"cash_in_transit_rewards_test_{VERSION}.txt", "w", encoding="utf-8") as fp:
            fp.write("\n".join(str(x) for x in total_rewards_test))

tot_time = time.time() - start
print(f"Total Runtime: {tot_time:.2f} s ({(tot_time / 60):.2f} min)", flush=True)
#cd C:\CIT_KUBRA 
# python plot_hierarchical_metrics.py --combine-runs
